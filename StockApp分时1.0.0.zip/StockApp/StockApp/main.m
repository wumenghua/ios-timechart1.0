//
//  main.m
//  StockApp
//
//  Created by 伍孟华 on 2018/11/2.
//  Copyright © 2018 分时K线. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
