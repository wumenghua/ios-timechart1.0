//
//  LJKLineViewController.m
//  StockApp
//
//  Created by 伍孟华 on 2018/11/2.
//  Copyright © 2018 分时K线. All rights reserved.
//


#import "LJKLineViewController.h"
#import "LJKLineChartView.h"
#import "LJKLineChartView+Basics.h"

#import "NSString+JKDictionaryValue.h"
#import "LJTimeChartUtil.h"
#import "LJGCDTimerManager.h"

@interface LJKLineViewController ()<LJKLineChartViewDelegate>

@property (nonatomic,strong) LJKLineChartView *kLineChartView;

@end

@implementation LJKLineViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    [self.kLineChartView initialize];
    [self.kLineChartView setupLayerScale];
    [self.kLineChartView reloadView:nil];
    
    //加载数据
    [self setupKLineView:YES];
    //开启定时器
    [self openGcdTime];
    // Do any additional setup after loading the view.
}

- (void)setupKLineView:(BOOL)isFirstRequest
{
    NSDictionary *responseObject = [[self getJsonFromFile:@"kline"] jk_dictionaryValue];
    
    //计算K线数组
    NSMutableArray *kLineChartArray = [LJTimeChartUtil getKLineChartModelArray:[responseObject objectForKey:@"Content"]];
    
    if (isFirstRequest) {
        self.kLineChartView.kLineChartArray = [[NSMutableArray alloc] init];
        self.kLineChartView.drawChartArray = [[NSMutableArray alloc] init];
    }
    //追加数据
    [self.kLineChartView addKLineChartArray:kLineChartArray];
    
    self.kLineChartView.decimal = 2;
    self.kLineChartView.instrumentId = @"HSIK8";
    //刷新数据
    [self.kLineChartView reloadView:nil];
}


#pragma mark - 定时器
- (void)openGcdTime {
    //重新开启计时器，倒计时清空
    [self setupLastBarRequest];
    __weak typeof(self) weakself = self;
    [[LJGCDTimerManager sharedInstance] scheduledDispatchTimerWithName:NSStringFromClass([self class]) timeInterval:1 queue:nil repeats:YES actionOption:AbandonPreviousAction action:^{
        //网络请求
        [weakself setupLastBarRequest];
    }];
}

- (void)setupLastBarRequest
{
    NSDictionary *responseObject = [[self getJsonFromFile:@"kline"] jk_dictionaryValue];
    //计算K线数组
    NSMutableArray *kLineChartArray = [LJTimeChartUtil getKLineChartModelArray:[responseObject objectForKey:@"Content"]];
    int idx = arc4random() % kLineChartArray.count;
    LJKLineModel *lastKLine = [kLineChartArray objectAtIndex:idx];
    
    LJKLineModel *kLineModel = [[LJKLineModel alloc] init];
    kLineModel.op = lastKLine.op;;
    kLineModel.clp = lastKLine.clp;
    kLineModel.hip = lastKLine.hip;
    kLineModel.lop = lastKLine.lop;
    kLineModel.vol = lastKLine.vol;
    kLineModel.opi = lastKLine.opi;
    kLineModel.dateChar = lastKLine.dateChar;
    
    //蜡烛、趋势、量仓、摆动
    kLineModel.candleModel = [[LJKLineCandleModel alloc] init];
    kLineModel.qsModel = [[LJKLineBaseModel alloc] init];
    kLineModel.lcModel = [[LJKLineBaseModel alloc] init];
    kLineModel.bdModel = [[LJKLineBaseModel alloc] init];
    
    /*
     更新K线数据
     1.对比最后一条数据事件是否一致，一致则覆盖，否则重新添加
     */
    if (self.kLineChartView.kLineChartArray) {
        LJKLineModel *lastModel = self.kLineChartView.kLineChartArray.lastObject;
        
        BOOL dateBlg = [lastModel.dateChar isEqualToString:kLineModel.dateChar];
        if (dateBlg) {
            //日期相同
            lastModel.op = kLineModel.op;
            lastModel.clp = kLineModel.clp;
            lastModel.hip = kLineModel.hip;
            lastModel.lop = kLineModel.lop;
            lastModel.vol = kLineModel.vol;
            lastModel.opi = kLineModel.opi;
        }else if(!dateBlg) {
            //日期不同
            [self.kLineChartView.kLineChartArray addObject:kLineModel];
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.kLineChartView updateDraw];
        });
    }
}

//右滑分页delegate
- (void)lj_kLineRightMovePage {
    [self setupKLineView:NO];
}

-(void)lj_kLineZoomMin {
    //[LJProgressHUD showInfoStatus:@"已经到最小了!" delay:1];
}

- (void)lj_kLineNotMoreData {
    //[LJProgressHUD showInfoStatus:@"暂无更多数据!" delay:1];
}

- (LJKLineChartView *)kLineChartView
{
    if (!_kLineChartView) {
        _kLineChartView = [[LJKLineChartView alloc] init];
        _kLineChartView.delegate = self;
        _kLineChartView.backgroundColor = [UIColor blackColor];
        _kLineChartView.frame = CGRectMake(0, 100, self.view.bounds.size.width, self.view.bounds.size.height-300);
        [self.view addSubview:_kLineChartView];
    }
    return _kLineChartView;
}

- (NSString *)getJsonFromFile:(NSString *)fileName
{
    NSString *pathForJsonFile = [[NSBundle mainBundle] pathForResource:fileName ofType:@"json"];
    NSString *jsonStr = [NSString stringWithContentsOfFile:pathForJsonFile encoding:NSUTF8StringEncoding error:nil];
    return jsonStr;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
