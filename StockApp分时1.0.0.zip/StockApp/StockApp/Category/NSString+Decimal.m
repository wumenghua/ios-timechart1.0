//
//  NSString+Decimal.m
//  YiFu
//
//  Created by 伍孟华 on 2018/6/13.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "NSString+Decimal.h"

@implementation NSString (Decimal)


///**
// *  @brief  反转字符串
// *
// *  @param strSrc 被反转字符串
// *
// *  @return 反转后字符串
// */
//+ (NSString *)jk_reverseString:(NSString *)strSrc
//{
//    NSMutableString* reverseString = [[NSMutableString alloc] init];
//    NSInteger charIndex = [strSrc length];
//    while (charIndex > 0) {
//        charIndex --;
//        NSRange subStrRange = NSMakeRange(charIndex, 1);
//        [reverseString appendString:[strSrc substringWithRange:subStrRange]];
//    }
//    return reverseString;
//}

/**
 float to NSString 防止丢失精度
 
 @param value foat
 @return NSString
 */
+(NSString *)jk_reviseString:(float)value
{
    //直接传入精度丢失有问题的Double类型
//    NSString *doubleString = [NSString stringWithFormat:@"%lf", value];
//    NSDecimalNumber *decNumber = [NSDecimalNumber decimalNumberWithString:doubleString];
//    return [decNumber stringValue];
    return @(value).stringValue;
}


/**
 保留小数点

 @param value 值
 @param decimal 小数位
 @return 返回值
 */
+(NSString *)jk_formatDec:(NSString *)value decimal:(NSInteger)decimal
{
   return [NSString jk_formatDecFloat:[value floatValue] decimal:decimal];
}
+(NSString *)jk_formatDecFloat:(float)value decimal:(NSInteger)decimal
{
    if (isnan(value) || isinf(value)) {
        value = 0;
    }
    NSString *formatStr = @"%0.";
    NSString *stringInt = [NSString stringWithFormat:@"%ldf",decimal];
    formatStr = [formatStr stringByAppendingString:stringInt];
    return [NSString stringWithFormat:formatStr, value];
}

-(NSString *)jk_formatDec:(NSInteger)decimal {
    return [NSString jk_formatDec:self decimal:decimal];
}
@end
