//
//  NSString+JKColor.m
//  YiFu
//
//  Created by 伍孟华 on 2018/6/25.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "NSString+JKColor.h"
#import "UIColor+JKHEX.h"

@implementation NSString (JKColor)

- (UIColor *)jk_compareColor
{
    return [NSString jk_compareColor:self];
}

+ (UIColor *)jk_compareColor:(NSString *)value
{
    return [NSString jk_compareColorFloat:[value floatValue]];
}

+ (UIColor *)jk_compareColorFloat:(float )value
{
    if (value == 0) {
        //白色
        return [UIColor whiteColor];
    }else if(value < 0){
        //绿色
        return [UIColor jk_colorWithHexString:@"#3bff00"];
    }else{
        //红色
        return [UIColor jk_colorWithHexString:@"#ff1400"];
    }
}

+ (UIColor *)jk_compareGreyColorFloat:(float )value
{
    if (value == 0) {
        //浅灰
        return [UIColor jk_colorWithHexString:@"#a7a7a7"];
    }else if(value < 0){
        //绿色
        return [UIColor jk_colorWithHexString:@"#3bff00"];
    }else{
        //红色
        return [UIColor jk_colorWithHexString:@"#ff1400"];
    }
}


- (NSString *)jk_compareColorStr
{
    return [NSString jk_compareColorStr:self];
}

+ (NSString *)jk_compareColorStr:(NSString *)value
{
    return [NSString jk_compareColorFloatStr:[value floatValue]];
}

+ (NSString *)jk_compareColorFloatStr:(float )value
{
    if (value == 0) {
        //白色
        return @"#FFFFFF";
    }else if(value < 0){
        //绿色
        return @"#67de42";
    }else{
        //红色
        return @"#d32d1e";
    }
}



@end
