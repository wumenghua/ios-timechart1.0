//
//  NSString+Decimal.h
//  YiFu
//
//  Created by 伍孟华 on 2018/6/13.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Decimal)


///**
// *  @brief  反转字符串
// *
// *  @param strSrc 被反转字符串
// *
// *  @return 反转后字符串
// */
//+ (NSString *)jk_reverseString:(NSString *)strSrc;

/**
 float to NSString 防止丢失精度
 
 @param value foat
 @return NSString
 */
+(NSString *)jk_reviseString:(float)value;


/**
 保留小数点
 */
+(NSString *)jk_formatDec:(NSString *)value decimal:(NSInteger)decimal;
+(NSString *)jk_formatDecFloat:(float)value decimal:(NSInteger)decimal;


-(NSString *)jk_formatDec:(NSInteger)decimal;

@end
