//
//  NSString+JKColor.h
//  YiFu
//
//  Created by 伍孟华 on 2018/6/25.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface NSString (JKColor)


/**
 程序String | float 类型数据转换为颜色

 @return 颜色值 （红色|绿色）
 */
- (UIColor *)jk_compareColor;
+ (UIColor *)jk_compareColor:(NSString *)value;
+ (UIColor *)jk_compareColorFloat:(float )value;
+ (UIColor *)jk_compareGreyColorFloat:(float )value;

- (NSString *)jk_compareColorStr;
+ (NSString *)jk_compareColorStr:(NSString *)value;
+ (NSString *)jk_compareColorFloatStr:(float )value;

@end
