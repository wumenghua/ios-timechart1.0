//
//  LJTime2ViewController.m
//  StockApp
//
//  Created by 伍孟华 on 2018/11/2.
//  Copyright © 2018 分时K线. All rights reserved.
//

#import "LJTime2ViewController.h"
#import "LJTimeChartView.h"
#import "NSString+JKDictionaryValue.h"
#import "NSDate+JKUtilities.h"
#import "LJGCDTimerManager.h"

@interface LJTime2ViewController ()<LJTimeChartViewDelegate>

//分时图
@property (nonatomic ,strong) LJTimeChartView *timeChartView;

//分时图最后一个bar的时间
@property (nonatomic,assign) NSInteger lastBarInterval;

@end

@implementation LJTime2ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    self.lastBarInterval = -1;
    self.timeChartView.pageIndex = 1;
    self.timeChartView.timeChartTotalArray = [[NSMutableArray alloc] init];
    //初始化分时图
    [self.timeChartView initTimeChart];
    
    //加载分时数据
    [self setupTimeLine];
    //开启定时器
    [self openGcdTime];
}

- (void)setupTimeLine
{
    NSDictionary *responseObject = [[self getJsonFromFile:@"time"] jk_dictionaryValue];
    //当前数据交易日期
    NSString *tradingDay = [responseObject objectForKey:@"TradingDay"];
    //交易数据赋值
    if (self.timeChartView.zrclp == 0) {
        self.timeChartView.zrclp = [[responseObject objectForKey:@"YSett"] floatValue];
    }
    if (self.lastBarInterval < 0) {
        self.lastBarInterval = [LJTimeChartUtil getLastBarInterval:[responseObject objectForKey:@"Content"]];
    }
    /*
     填充绘制：当天交易时间内未交易的时间点是空白的，不参与画线
     计算分时图Key-Value模式
     */
    
    //交易时间范围
    NSString *timesStr = [responseObject objectForKey:@"Times"];
    self.timeChartView.treatyTimes = timesStr;
    //交易数据 转 集合
    NSMutableDictionary *timeModelDic = [LJTimeChartUtil getTimeChartModelDictionary:[responseObject objectForKey:@"Content"]];
    //计算分时图空白数据模型数组
    NSMutableArray *casualArray = [LJTimeChartUtil chartTimeArray:[timesStr componentsSeparatedByString:@","] isTimestamp:false];
    for (int i = 0; i < casualArray.count; i++) {
        @autoreleasepool {
            LJTimeChartModel *chartModel = [casualArray objectAtIndex:i];
            chartModel.isOffLine = NO;
            chartModel.tradingDay = tradingDay;
            //遍历 timeChartArray分钟列表，根据timeModelDic实体数据集合的key来索引value并进行赋值;
            LJTimeChartModel *chartModelDic = [timeModelDic objectForKey:chartModel.dateCharHm];
            if (chartModelDic) {
                chartModel.op = chartModelDic.op;
                chartModel.clp = chartModelDic.clp;
                chartModel.avp = chartModelDic.avp;
                chartModel.vol = chartModelDic.vol;
                chartModel.opi = chartModelDic.opi;
                chartModel.bar = chartModelDic.bar;
            }
        }
    }
    //当前分时总数据添加
    [self.timeChartView.timeChartTotalArray addObject:casualArray];
    
    /*
     基础绘制：只绘制有交易时间的数据，未参与交易时间不会出现
     */
//    NSMutableArray *timeModelArray = [LJTimeChartUtil getTimeChartModelArray:[responseObject objectForKey:@"Content"]];
//    //充值新的一天分时画线数据 isOffLine:不断开画线  tradingDay:当前分时的日期
//    for (int i = 0; i < timeModelArray.count; i++) {
//        LJTimeChartModel *chartModel = [timeModelArray objectAtIndex:i];
//        chartModel.isOffLine = NO;
//        chartModel.tradingDay = tradingDay;
//    }
//    //当前分时总数据添加
//    [self.timeChartView.timeChartTotalArray addObject:timeModelArray];
    
    
    //重置分时图数据源，重新添加
    NSMutableArray *timeChartArray = [[NSMutableArray alloc] init];
    if (self.timeChartView.timeChartTotalArray.count > 0 && (self.timeChartView.pageIndex-1) < self.timeChartView.timeChartTotalArray.count) {
        for (int i = 0; i < self.timeChartView.pageIndex; i++) {
            NSArray *insertArray = (NSArray *)[self.timeChartView.timeChartTotalArray objectAtIndex:i];
            //每个数组的第一个数据需要 断开重绘
            if (i > 1) {
                LJTimeChartModel *chartModel = (LJTimeChartModel *)insertArray.lastObject;
                chartModel.isOffLine = YES;
            }
            [timeChartArray insertObjects:insertArray atIndexes:[NSIndexSet indexSetWithIndexesInRange:NSMakeRange(0, insertArray.count)]];
        }
        if (self.timeChartView.timeChartTotalArray.count > 1) {
            //判断日期是否重复,此段代码可忽略，每个公司数据不同，处理方式也不相同
            LJTimeChartModel *lastArray_FirstModel = self.timeChartView.timeChartTotalArray[self.timeChartView.timeChartTotalArray.count-1][0];
            LJTimeChartModel *backArray_FirstModel = self.timeChartView.timeChartTotalArray[self.timeChartView.timeChartTotalArray.count-2][0];
            if ([lastArray_FirstModel.tradingDay isEqualToString:backArray_FirstModel.tradingDay]) {
                //最后两个数组的日期重复,将最后一个数组的第0条数据加2天
                NSDate *tradingDate = [NSDate jk_timeStringToNSDateWith:@"yyyyMMdd" strValue:lastArray_FirstModel.tradingDay];
                tradingDate = [tradingDate jk_dateByAddingDays:1];
                backArray_FirstModel.tradingDay = [NSDate jk_dateWithFormat:@"yyyyMMdd" date:tradingDate];
            }
        }
    }
    self.timeChartView.timeChartArr = timeChartArray;
    self.timeChartView.decimal = 0;
    self.timeChartView.delegate = self;
    //每一次刷新 + 分页都需要重新刷新
    [self.timeChartView draw];
    
    //需要设置周期并加载本地画线分析的数据
    //    BOOL isUpdateAnalysis = NO;
    //    if ([[NSUserDefaults jk_stringForKey:LJ_IsUpdateAnalysis] boolValue]) {
    //        isUpdateAnalysis = YES;
    //        [NSUserDefaults jk_setObject:@"0" forKey:LJ_IsUpdateAnalysis];
    //    }
    //    if (weakself.timeChartView.pageIndex == 1 || ![weakself.timeChartView.instrumentId isEqualToString:self.treatyDetail.treatyInstrument.Id] || isUpdateAnalysis) {
    //        weakself.timeChartView.instrumentId = weakself.treatyDetail.treatyInstrument.Id;
    //        //加载当前分时图所有画线分析
    //        [weakself.timeChartView timeChartLoadAllSeedModel];
    //    }
    //    weakself.timeChartView.instrumentId = weakself.treatyDetail.treatyInstrument.Id;
    //    //分时图外部整体数据结构发生改变
    //    [weakself.timeChartView timeChartUpdateAllSeedModel];
    //    //画线下单改变
    //    [weakself calculateCloundConditionLineOrder];
    
}

#pragma mark - 分时放大缩小手势
//isEnLarge true：放大  false：缩小
- (void)lj_PinchNumberOfTouches:(BOOL)isEnLarge
{
    if (isEnLarge) {
        //放大
        if (self.timeChartView.pageIndex > 1) {
            --self.timeChartView.pageIndex;
            
            NSMutableArray *timeChartArray = [[NSMutableArray alloc] init];
            for (int i = 0; i < self.timeChartView.pageIndex; i++) {
                NSArray *insertArray = (NSArray *)[self.timeChartView.timeChartTotalArray objectAtIndex:i];
                [timeChartArray insertObjects:insertArray atIndexes:[NSIndexSet indexSetWithIndexesInRange:NSMakeRange(0, insertArray.count)]];
            }
            self.timeChartView.timeChartArr = timeChartArray;
            [self.timeChartView draw];
            //分时图外部整体数据结构发生改变
            //[self.timeChartView timeChartUpdateAllSeedModel];
            //通知分时图分页时外部变化
            //if (self.timeViewPageCountUpdate) {
            //    self.timeViewPageCountUpdate();
            //}
        }
    }else{
        //缩小
        if (self.timeChartView.pageIndex < self.timeChartView.maxPageCount) {
            ++self.timeChartView.pageIndex;
            if (self.timeChartView.pageIndex < self.timeChartView.timeChartTotalArray.count) {
                
                NSMutableArray *timeChartArray = [[NSMutableArray alloc] init];
                for (int i = 0; i < self.timeChartView.pageIndex; i++) {
                    NSArray *insertArray = (NSArray *)[self.timeChartView.timeChartTotalArray objectAtIndex:i];
                    [timeChartArray insertObjects:insertArray atIndexes:[NSIndexSet indexSetWithIndexesInRange:NSMakeRange(0, insertArray.count)]];
                }
                self.timeChartView.timeChartArr = timeChartArray;
                [self.timeChartView draw];
                //分时图外部整体数据结构发生改变
                //[self.timeChartView timeChartUpdateAllSeedModel];
            }else{
                //请求数据
                [self setupTimeLine];
            }
            //通知分时图分页时外部变化
            //if (self.timeViewPageCountUpdate) {
            //    self.timeViewPageCountUpdate();
            //}
        }else{
            //[LJProgressHUD showInfoStatus:LJ_LocalizedSystem(@"been_scaled_minimum") delay:1];
            //开启缩放手势
            self.timeChartView.pinchGesture.enabled = YES;
        }
    }
}

#pragma mark - 开启定时器
- (void)openGcdTime
{
    __weak typeof(self) weakSelf = self;
    [[LJGCDTimerManager sharedInstance] scheduledDispatchTimerWithName:NSStringFromClass([self class]) timeInterval:1 queue:nil repeats:YES actionOption:AbandonPreviousAction action:^{
        //网络请求
        [weakSelf setupLastBarRequest];
    }];
}

- (void)setupLastBarRequest
{
    //添加1分钟
    self.lastBarInterval+=60;
    
    NSDictionary *responseObject = [[self getJsonFromFile:@"time"] jk_dictionaryValue];
    NSArray *tradeTime = [[responseObject objectForKey:@"Content"] componentsSeparatedByString:@";"];
    
    int idx = arc4random() % tradeTime.count;
    NSArray *cutArr = [tradeTime[idx] componentsSeparatedByString:@","] ;
    LJTimeChartModel *chartModel = [[LJTimeChartModel alloc] init];
    chartModel.op = cutArr[0];
    chartModel.clp = cutArr[1];
    chartModel.avp = cutArr[2];
    chartModel.vol = cutArr[3];
    chartModel.opi = cutArr[4];
    chartModel.bar =  self.lastBarInterval;
    //LJ_YYYY_MM_DD_HH_MM
    chartModel.dateChar = [NSDate jk_timeIntervalWithFormat:@"yyyy-MM-dd HH:mm" timeInterval:self.lastBarInterval];
    chartModel.dateCharHm = [NSDate jk_timeIntervalWithFormat:@"HH:mm" timeInterval:self.lastBarInterval];
    
    
    if (self.timeChartView.timeChartTotalArray && self.timeChartView.timeChartTotalArray.count > 0)
    {
        BOOL isExist = NO;
        NSMutableArray *firstArray = [self.timeChartView.timeChartTotalArray firstObject];
        for (NSInteger i = firstArray.count-1; i >= 0; i--)
        {
            LJTimeChartModel *chartModelEnumer = [firstArray objectAtIndex:i];
            if ([chartModelEnumer.dateCharHm isEqual:chartModel.dateCharHm])
            {
                chartModelEnumer.op = chartModel.op;
                chartModelEnumer.clp = chartModel.clp;
                chartModelEnumer.avp = chartModel.avp;
                chartModelEnumer.vol = chartModel.vol;
                chartModelEnumer.opi = chartModel.opi;
                isExist = YES;
                dispatch_async(dispatch_get_main_queue(), ^{
                    [self.timeChartView updateDraw];
                });
                //画线下单改变
                //[weakself calculateCloundConditionLineOrder];
                //图表显示持仓线
                //[weakself calculatePositionLine];
                break;
            }
        }
        if (!isExist) {
            [firstArray addObject:chartModel];
            
            NSMutableArray *timeChartArray = [[NSMutableArray alloc] init];
            for (int i = 0; i < self.timeChartView.pageIndex; i++) {
                NSArray *insertArray = (NSArray *)[self.timeChartView.timeChartTotalArray objectAtIndex:i];
                [timeChartArray insertObjects:insertArray atIndexes:[NSIndexSet indexSetWithIndexesInRange:NSMakeRange(0, insertArray.count)]];
            }
            self.timeChartView.timeChartArr = timeChartArray;
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.timeChartView draw];
            });
        }
    }
    
//    self.requestLastDate = NSDate.date;
//    LJ_WeakSelf(self);
//    LJLastBarRequest *request = [[LJLastBarRequest alloc] initReq:self.treatyDetail.treatyInstrument.GId Period:@"60"];
//    [request setCompletionBlockWithSuccess:^(id responseObject) {
//
//        NSString *DTDateString = [responseObject objectForKey:@"DT"];
//        if (LJ_StringIsEmpty(DTDateString)) {
//            //如果DT等于Null
//            weakself.lastBarVerView.sellLabel.textColor = weakself.lastBarVerView.buyLabel.textColor = weakself.lastBarVerView.makePrice.textColor = weakself.lastBarVerView.upsAndDowns.textColor = LJ_White_Color;
//            weakself.lastBarView.sellLabel.textColor = weakself.lastBarView.buyLabel.textColor = weakself.lastBarView.makePrice.textColor = weakself.lastBarView.ups.textColor = weakself.lastBarView.downs.textColor = LJ_White_Color;
//            return;
//        }
//        DTDateString = [NSDate jk_timeStringWithFormat:LJ_YYYY_MM_DD_HH_MM_SS targetFormat:LJ_HM strValue:DTDateString];
//        /*
//         1.更新分时图数据
//         2.更新底部UI数据
//         */
//        if (weakself.timeChartView.timeChartTotalArray && weakself.timeChartView.timeChartTotalArray.count > 0) {
//            @autoreleasepool {
//                LJTimeChartModel *chartModelEnumer = nil;
//                NSMutableArray *reverseChartArray = (NSMutableArray *)[[weakself.timeChartArray reverseObjectEnumerator] allObjects];
//                for (int i = 0; i < reverseChartArray.count; i++) {
//                    chartModelEnumer = [reverseChartArray objectAtIndex:i];
//                    if ([chartModelEnumer.dateCharHm isEqual:DTDateString]) {
//                        chartModelEnumer.op = LJ_NSSTRING_FORMAT([responseObject objectForKey:@"OP"]);
//                        chartModelEnumer.clp = LJ_NSSTRING_FORMAT([responseObject objectForKey:@"CP"]);
//                        chartModelEnumer.avp = LJ_NSSTRING_FORMAT([responseObject objectForKey:@"AV"]);
//                        chartModelEnumer.vol = LJ_NSSTRING_FORMAT([responseObject objectForKey:@"V"]);
//                        chartModelEnumer.opi = LJ_NSSTRING_FORMAT([responseObject objectForKey:@"OI"]);
//                        [weakself.timeChartView updateDraw];
//                        //画线下单改变
//                        [weakself calculateCloundConditionLineOrder];
//                        //图表显示持仓线
//                        [weakself calculatePositionLine];
//                        break;
//                    }
//                }
//            }
//        }
//    } failure:^(NSError *error) {
//
//    }];
}


- (LJTimeChartView *)timeChartView{
    if (!_timeChartView) {
        _timeChartView = [[LJTimeChartView alloc] init];
        _timeChartView.backgroundColor = [UIColor blackColor];
        _timeChartView.frame = CGRectMake(0, 100, self.view.bounds.size.width, self.view.bounds.size.height-300);
        [self.view addSubview:_timeChartView];
    } return _timeChartView;
}

- (NSString *)getJsonFromFile:(NSString *)fileName
{
    NSString *pathForJsonFile = [[NSBundle mainBundle] pathForResource:fileName ofType:@"json"];
    NSString *jsonStr = [NSString stringWithContentsOfFile:pathForJsonFile encoding:NSUTF8StringEncoding error:nil];
    return jsonStr;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
