//
//  LJTime2ViewController.h
//  StockApp
//
//  Created by 伍孟华 on 2018/11/2.
//  Copyright © 2018 分时K线. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LJTime2ViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
