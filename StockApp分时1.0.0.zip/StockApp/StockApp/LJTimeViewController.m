//
//  LJTimeViewController.m
//  StockApp
//
//  Created by 伍孟华 on 2018/11/2.
//  Copyright © 2018 分时K线. All rights reserved.
//

#import "LJTimeViewController.h"
#import "LJTimeChartView.h"
#import "NSString+JKDictionaryValue.h"
#import "NSDate+JKUtilities.h"

@interface LJTimeViewController ()<LJTimeChartViewDelegate>

//分时图
@property (nonatomic ,strong) LJTimeChartView *timeChartView;

@end

@implementation LJTimeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.timeChartView.pageIndex = 1;
    self.timeChartView.timeChartTotalArray = [[NSMutableArray alloc] init];
    //初始化分时图
    [self.timeChartView initTimeChart];
    
    NSDictionary *responseObject = [[self getJsonFromFile:@"time"] jk_dictionaryValue];
    //当前数据交易日期
    NSString *tradingDay = [responseObject objectForKey:@"TradingDay"];
    //交易数据赋值
    if (self.timeChartView.zrclp == 0) {
        self.timeChartView.zrclp = [[responseObject objectForKey:@"YSett"] floatValue];
    }
    
    
    /*
     填充绘制：当天交易时间内未交易的时间点是空白的，不参与画线
     计算分时图Key-Value模式
     */
    //交易时间范围
    NSString *timesStr = [responseObject objectForKey:@"Times"];
    self.timeChartView.treatyTimes = timesStr;
    //交易数据 转 集合
    NSMutableDictionary *timeModelDic = [LJTimeChartUtil getTimeChartModelDictionary:[responseObject objectForKey:@"Content"]];
    //计算分时图空白数据模型数组
    NSMutableArray *casualArray = [LJTimeChartUtil chartTimeArray:[timesStr componentsSeparatedByString:@","] isTimestamp:false];
    for (int i = 0; i < casualArray.count; i++) {
        @autoreleasepool {
            LJTimeChartModel *chartModel = [casualArray objectAtIndex:i];
            chartModel.isOffLine = NO;
            chartModel.tradingDay = tradingDay;
            //遍历 timeChartArray分钟列表，根据timeModelDic实体数据集合的key来索引value并进行赋值;
            LJTimeChartModel *chartModelDic = [timeModelDic objectForKey:chartModel.dateCharHm];
            if (chartModelDic) {
                chartModel.op = chartModelDic.op;
                chartModel.clp = chartModelDic.clp;
                chartModel.avp = chartModelDic.avp;
                chartModel.vol = chartModelDic.vol;
                chartModel.opi = chartModelDic.opi;
                chartModel.bar = chartModelDic.bar;
            }
        }
    }
    //当前分时总数据添加
    [self.timeChartView.timeChartTotalArray addObject:casualArray];
    
    
    /*
     基础绘制：只绘制有交易时间的数据，未参与交易时间不会出现
     */
//    NSMutableArray *timeModelArray = [LJTimeChartUtil getTimeChartModelArray:[responseObject objectForKey:@"Content"]];
//    //充值新的一天分时画线数据 isOffLine:不断开画线  tradingDay:当前分时的日期
//    for (int i = 0; i < timeModelArray.count; i++) {
//        LJTimeChartModel *chartModel = [timeModelArray objectAtIndex:i];
//        chartModel.isOffLine = NO;
//        chartModel.tradingDay = tradingDay;
//    }
//    //当前分时总数据添加
//    [self.timeChartView.timeChartTotalArray addObject:timeModelArray];
    
    
    //重置分时图数据源，重新添加
    NSMutableArray *timeChartArray = [[NSMutableArray alloc] init];
    if (self.timeChartView.timeChartTotalArray.count > 0 && (self.timeChartView.pageIndex-1) < self.timeChartView.timeChartTotalArray.count) {
        for (int i = 0; i < self.timeChartView.pageIndex; i++) {
            NSArray *insertArray = (NSArray *)[self.timeChartView.timeChartTotalArray objectAtIndex:i];
            //每个数组的第一个数据需要 断开重绘
            if (i > 1) {
                LJTimeChartModel *chartModel = (LJTimeChartModel *)insertArray.lastObject;
                chartModel.isOffLine = YES;
            }
            [timeChartArray insertObjects:insertArray atIndexes:[NSIndexSet indexSetWithIndexesInRange:NSMakeRange(0, insertArray.count)]];
        }
        if (self.timeChartView.timeChartTotalArray.count > 1) {
            //判断日期是否重复,此段代码可忽略，每个公司数据不同，处理方式也不相同
            LJTimeChartModel *lastArray_FirstModel = self.timeChartView.timeChartTotalArray[self.timeChartView.timeChartTotalArray.count-1][0];
            LJTimeChartModel *backArray_FirstModel = self.timeChartView.timeChartTotalArray[self.timeChartView.timeChartTotalArray.count-2][0];
            if ([lastArray_FirstModel.tradingDay isEqualToString:backArray_FirstModel.tradingDay]) {
                //最后两个数组的日期重复,将最后一个数组的第0条数据加2天
                NSDate *tradingDate = [NSDate jk_timeStringToNSDateWith:@"yyyyMMdd" strValue:lastArray_FirstModel.tradingDay];
                tradingDate = [tradingDate jk_dateByAddingDays:1];
                backArray_FirstModel.tradingDay = [NSDate jk_dateWithFormat:@"yyyyMMdd" date:tradingDate];
            }
        }
    }
    self.timeChartView.timeChartArr = timeChartArray;
    self.timeChartView.decimal = 0;
    self.timeChartView.delegate = self;
    //每一次刷新 + 分页都需要重新刷新
    [self.timeChartView draw];
    
    //需要设置周期并加载本地画线分析的数据
//    BOOL isUpdateAnalysis = NO;
//    if ([[NSUserDefaults jk_stringForKey:LJ_IsUpdateAnalysis] boolValue]) {
//        isUpdateAnalysis = YES;
//        [NSUserDefaults jk_setObject:@"0" forKey:LJ_IsUpdateAnalysis];
//    }
//    if (weakself.timeChartView.pageIndex == 1 || ![weakself.timeChartView.instrumentId isEqualToString:self.treatyDetail.treatyInstrument.Id] || isUpdateAnalysis) {
//        weakself.timeChartView.instrumentId = weakself.treatyDetail.treatyInstrument.Id;
//        //加载当前分时图所有画线分析
//        [weakself.timeChartView timeChartLoadAllSeedModel];
//    }
//    weakself.timeChartView.instrumentId = weakself.treatyDetail.treatyInstrument.Id;
//    //分时图外部整体数据结构发生改变
//    [weakself.timeChartView timeChartUpdateAllSeedModel];
//    //画线下单改变
//    [weakself calculateCloundConditionLineOrder];
    
    
    
}

- (LJTimeChartView *)timeChartView{
    if (!_timeChartView) {
        _timeChartView = [[LJTimeChartView alloc] init];
        _timeChartView.backgroundColor = [UIColor blackColor];
        _timeChartView.frame = CGRectMake(0, 100, self.view.bounds.size.width, self.view.bounds.size.height-300);
        [self.view addSubview:_timeChartView];
    } return _timeChartView;
}

- (NSString *)getJsonFromFile:(NSString *)fileName
{
    NSString *pathForJsonFile = [[NSBundle mainBundle] pathForResource:fileName ofType:@"json"];
    NSString *jsonStr = [NSString stringWithContentsOfFile:pathForJsonFile encoding:NSUTF8StringEncoding error:nil];
    return jsonStr;
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
