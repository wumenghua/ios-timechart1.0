//
//  LJTimeChartView.h
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/5/14.
//  Copyright © 2018年 伍孟华. All rights reserved.
//
#define LJ_FONTSYS(size) ([UIFont systemFontOfSize:(size)])


#import <UIKit/UIKit.h>
#import "NSMutableArray+TimeMaxMin.h"
#import "LJChartLineModel.h"
#import "LJTimeChartModel.h"
#import "LJTimeChartUtil.h"
#import "LJTimeColourPH.pch"

@protocol LJTimeChartViewDelegate <NSObject>

//开始移动、移动中 回调
@optional
- (void)lj_MoveTimeTicksChanged:(LJTimeChartModel *)chartModel idx:(int)idx x:(CGFloat)x y:(CGFloat)y;

//结束移动 回调
@optional
- (void)lj_MoveTimeTicksEnd;

/**
 分时放大缩小手势
 @param isEnLarge true：放大  false：缩小
 */
@optional
- (void)lj_PinchNumberOfTouches:(BOOL)isEnLarge;

@end
@interface LJTimeChartView : UIView

//长按事件
@property (nonatomic ,retain) UILongPressGestureRecognizer *longGesture;
//单击事件
@property (nonatomic ,retain) UITapGestureRecognizer *tapGesture;
//平移事件
@property (nonatomic ,retain) UIPanGestureRecognizer *panGesture;
//缩放
@property (nonatomic ,retain) UIPinchGestureRecognizer *pinchGesture;

//分时图分页总数据
@property (strong ,nonatomic) NSMutableArray *timeChartTotalArray;
//分时图根据分页拼接的数据
@property (strong ,nonatomic) NSMutableArray *timeChartArr;
//绘制的坐标数据
@property (strong ,nonatomic) NSMutableArray *timeDrawChartArr;
//持仓量
@property (nonatomic,strong) NSMutableArray *volDrawCharArr;
////持仓量 幅图红色方形数据
//@property (nonatomic,strong) NSMutableArray *timeDrawRedVol;
////持仓量 幅图绿色形数据
//@property (nonatomic,strong) NSMutableArray *timeDrawGreenVol;

//分时图分页当前所在索引位置
@property (nonatomic,assign) NSInteger pageIndex;
//分时图最大显示分页数量
@property (nonatomic,assign) NSInteger maxPageCount;
//是否允许分页
@property (nonatomic,assign) BOOL isAllowPage;
//最后一个有数据的bar，用于浮层数据计算
@property (nonatomic,strong) LJTimeChartModel *lastExistChattModel;

//十字架当前选中的索引bar
@property (assign ,nonatomic) int selectIdx;
@property (nonatomic,strong) LJTimeChartModel *selectPointModel;

//昨日成交价
@property (assign ,nonatomic) float zrclp;
//交易范围内每个多少分钟画一条竖线
@property (assign ,nonatomic) int minute;
//合约小数位
@property (assign ,nonatomic) int decimal;
//横竖屏切换时十字架控制
@property (nonatomic,assign) BOOL isLandscapeUpdate;
//合约ID
@property (nonatomic,strong) NSString *instrumentId;
//合约周期
@property (nonatomic,strong) NSString *instrumentPeriod;
//到计时数量
@property (nonatomic,assign) NSInteger intervalCount;

//delegate
@property (weak ,nonatomic) id<LJTimeChartViewDelegate> delegate;


//初始化分时图，用户画出表格线
- (void)initTimeChart;
//绘制
- (void)draw;
//重置数据
-(void)updateDraw;
//主动清空数据
- (void)releaseView;
//隐藏十字架
- (void)hideTicks;

/**
 根据索引获取Point
 */
-(CGPoint)getIdxLinePoint:(int)idx;

/**
 根据索引获取model，并移动十字架
 */
-(LJTimeChartModel *)getIdxLineModelAndMoveTicks:(int)idx;



#pragma -mark 类别扩展
//格式化
@property (nonatomic,strong) NSString *format;;
@property (nonatomic,strong) NSDictionary *attribute;
@property (nonatomic,assign) NSInteger attfontSize;

/**设置显示区间大小，总多少分钟*/
@property (nonatomic, assign) int sumMinute;
//x轴时间点高
@property (nonatomic,assign) float timePointH;


/**最高收盘价*/
@property (nonatomic, assign) double maxClpValue;
/**最低收盘价*/
@property (nonatomic, assign) double minClpValue;

/**最高成交量*/
@property (nonatomic, assign) double maxVolValue;
/**最低成交量*/
@property (nonatomic, assign) double minVolValue;

/**最高持仓量*/
@property (nonatomic, assign) double maxOpiValue;
/**最低持仓量*/
@property (nonatomic, assign) double minOpiValue;


/*竖虚线 数量 、 位置 、 时间*/
@property (nonatomic ,strong) NSMutableArray *verLineArray;
/*横虚线 数量 、 位置 、 时间*/
@property (nonatomic ,strong) NSMutableArray *horLineArray;
/*成交量/持仓量 横虚线*/
@property (nonatomic ,strong) NSMutableArray *horVolLineArray;

//分时最新一条的时分位置
@property (nonatomic,strong) NSMutableDictionary *firstTimeHmDictionary;

//分时图交易时间
@property (nonatomic,strong) NSString *treatyTimes;

//主图 竖线 数量
@property (nonatomic, assign) int verLineCount;
//主图 横线 数量
@property (nonatomic, assign) int horLineCount;

@property (nonatomic,assign) CGFloat viewHeight;
@property (nonatomic, assign) float frameX;
@property (nonatomic, assign) float frameY;
@property (nonatomic, assign) float frameW;
@property (nonatomic, assign) float frameH;

@property (nonatomic, assign) float unitH; //单位高

//点位宽度高度
@property (nonatomic, assign) float dotWidth;
//主图 点位高度
@property (nonatomic, assign) float dotHeight;
//幅图 成交量 点位高度
@property (nonatomic, assign) float dotVolHeight;
//幅图 持仓量 点位高度
@property (nonatomic, assign) float dotOpiHeight;

//分时 主图 部分虚拟层高
@property (nonatomic, assign) float lineHeight;
//实际层高
@property (nonatomic, assign) float lineHeightReality;
//主图层绘线部分 （上 下） 空隙高度
@property (nonatomic, assign) float lineRealityGapHeight;

//分时 幅图 部分虚拟层高
@property (nonatomic, assign) float volHeight;
//实际层高
@property (nonatomic, assign) float volHeightReality;
//幅图层绘线部分（上 下）空隙高度
@property (nonatomic, assign) float volRealityGapHeight;



@end
