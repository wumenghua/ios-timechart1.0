//
//  LJTimeLayerView.h
//  YiFu
//
//  Created by 伍孟华 on 2018/6/28.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LJTimeChartModel.h"

@interface LJTimeLayerView : UIView

//最后一个有数据的bar
@property (nonatomic,strong) LJTimeChartModel *lastExistChattModel;
//合约小数位
@property (assign ,nonatomic) int decimal;
//昨日收盘价
@property (assign ,nonatomic) float zrclp;

//分时图画线Y轴值
@property (nonatomic,strong) NSString *timeY;

//显示浮层
- (void)showLayer:(CGPoint)point chartModel:(LJTimeChartModel *)chartModel upChartModel:(LJTimeChartModel *)upChartModel;

//关闭浮层
- (void)hideLayer;

//更新图层位置
- (void)updateLayerFrame;

@end
