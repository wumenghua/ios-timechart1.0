//
//  LJTimeLayerView.m
//  YiFu
//
//  Created by 伍孟华 on 2018/6/28.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "LJTimeLayerView.h"
#import "NSString+Decimal.h"
#import "NSString+JKColor.h"
#import "UIViewAdditions.h"
#import "NSDate+JKUtilities.h"
#import "UIColor+JKHEX.h"

@interface LJTimeLayerView()

//浮层 左/右 控制  YES:不在 NO:在，用户控制动画
@property (nonatomic,assign) BOOL leftDirection;
@property (nonatomic,assign) BOOL rightDirection;

//浮层所在位置，用于K线横竖屏切换时位置错误
@property (nonatomic,assign) BOOL isLeftDir;
@property (nonatomic,assign) BOOL isRightDir;

//父层
@property (nonatomic,strong) UIView *superView;

@property (weak, nonatomic) IBOutlet UILabel *timeYLab;
@property (weak, nonatomic) IBOutlet UILabel *dateLab;

//价格
@property (weak, nonatomic) IBOutlet UILabel *priceLab;

//均价
@property (weak, nonatomic) IBOutlet UILabel *avgLab;

//涨跌
@property (weak, nonatomic) IBOutlet UILabel *up1Lab;
@property (weak, nonatomic) IBOutlet UILabel *up2Lab;

//成交量
@property (weak, nonatomic) IBOutlet UILabel *vol1Lab;
@property (weak, nonatomic) IBOutlet UILabel *vol2Lab;

@end

@implementation LJTimeLayerView

- (instancetype)init
{
    self = [super init];
    if (self) {
        self = [[[NSBundle mainBundle] loadNibNamed:NSStringFromClass(self.class) owner:self options:nil] lastObject];
    }
    self.backgroundColor = [UIColor blackColor];
    
    [self setupUI];
    
    return self;
}

- (void)setupUI
{
    self.hidden = YES;
    
    self.leftDirection = NO;
    self.rightDirection = NO;
    
    self.timeYLab.adjustsFontSizeToFitWidth = YES;
    self.dateLab.adjustsFontSizeToFitWidth = YES;
    
    self.priceLab.adjustsFontSizeToFitWidth = YES;
    self.avgLab.adjustsFontSizeToFitWidth = YES;
    
    self.up1Lab.adjustsFontSizeToFitWidth = YES;
    self.up2Lab.adjustsFontSizeToFitWidth = YES;
    
    self.vol1Lab.adjustsFontSizeToFitWidth = YES;
    self.vol2Lab.adjustsFontSizeToFitWidth = YES;
    
}

- (void)showLayer:(CGPoint)point chartModel:(LJTimeChartModel *)chartModel upChartModel:(LJTimeChartModel *)upChartModel
{
    self.superView = self.superview;
    
    if (self.hidden) {
        
        if (point.x > (self.superView.width - self.width)) {
            //左边显示
            self.left = -self.width;
            [UIView animateWithDuration:0.25 delay:0 options:UIViewAnimationOptionCurveLinear animations:^{
                self.left = 0;
            } completion:^(BOOL finished) {
                self.leftDirection = NO;
                self.isLeftDir = YES;
            }];
        }else{
            //右边显示
            self.left = self.superView.width;
            [UIView animateWithDuration:0.25 delay:0 options:UIViewAnimationOptionCurveLinear animations:^{
                self.left = self.superView.width - self.width;
            } completion:^(BOOL finished) {
                self.rightDirection = NO;
                self.isRightDir = YES;
            }];
        }
    }
    
    self.hidden = NO;
//    LJRZLogRect(self.frame);
    if (point.x < self.width) {
        //右边出来
        if (self.left != (self.superView.width-self.width) && !self.rightDirection) {
            self.rightDirection = YES;
            self.isRightDir = YES;
            
            //切换
            if (self.left == 0) {
                //先左隐藏，再右显示
                [UIView animateWithDuration:0.25 delay:0 options:UIViewAnimationOptionCurveLinear animations:^{
                    self.left = -self.width;
                } completion:^(BOOL finished) {
                    self.left = self.superView.width;
                    [UIView animateWithDuration:0.25 delay:0 options:UIViewAnimationOptionCurveLinear animations:^{
                        self.left = self.superView.width - self.width;
                    } completion:^(BOOL finished) {
                        self.rightDirection = NO;
                    }];
                }];
            }else{
                self.left = self.superView.width;
                [UIView animateWithDuration:0.25 delay:0 options:UIViewAnimationOptionCurveLinear animations:^{
                    self.left = self.superView.width - self.width;
                } completion:^(BOOL finished) {
                    self.rightDirection = NO;
                }];
            }
        }
        
    }else if (point.x > (self.superView.width - self.width)) {
        //左边出来
        if (self.left != 0 && !self.leftDirection) {
            self.leftDirection = YES;
            self.isLeftDir = YES;
            //切换
            if (self.left == (self.superView.width-self.width)) {
                //先右隐藏，再左显示
                [UIView animateWithDuration:0.25 delay:0 options:UIViewAnimationOptionCurveLinear animations:^{
                    self.left = self.superView.width;
                } completion:^(BOOL finished) {
                    self.left = -self.width;
                    [UIView animateWithDuration:0.25 delay:0 options:UIViewAnimationOptionCurveLinear animations:^{
                        self.left = 0;
                    } completion:^(BOOL finished) {
                         self.leftDirection = NO;
                    }];
                }];
            }else{
                self.left = -self.width;
                [UIView animateWithDuration:0.25 delay:0 options:UIViewAnimationOptionCurveLinear animations:^{
                    self.left = 0;
                } completion:^(BOOL finished) {
                    self.leftDirection = NO;
                }];
            }
        }
    }
    
    //设置数据
    [self setupLayerData:chartModel upChartModel:upChartModel];
}

- (void)hideLayer
{
    self.superView = self.superview;
    if (self.left == 0) {
        //左隐藏
        [UIView animateWithDuration:0.25 delay:0 options:UIViewAnimationOptionCurveEaseIn animations:^{
            self.left = -self.width;
        } completion:^(BOOL finished) {
            self.hidden = YES;
        }];
    }else {
        //右隐藏
        [UIView animateWithDuration:0.25 delay:0 options:UIViewAnimationOptionCurveEaseIn animations:^{
            self.left = self.superView.width;
        } completion:^(BOOL finished) {
            self.hidden = YES;
        }];
    }
}


//更新图层位置
- (void)updateLayerFrame
{
    if (!self.hidden) {
        if (self.isLeftDir) {
            //原来在左边显示
            self.left = 0;
        }
        if (self.isRightDir) {
            //原来在右边显示
            self.left = self.superView.width - self.width;
        }
    }
}

- (void)setIsLeftDir:(BOOL)isLeftDir {
    _isLeftDir = isLeftDir;
    _isRightDir = !isLeftDir;
}

- (void)setIsRightDir:(BOOL)isRightDir {
    _isRightDir = isRightDir;
    _isLeftDir = !isRightDir;
}


- (void)setupLayerData:(LJTimeChartModel *)chartModel upChartModel:(LJTimeChartModel *)upChartModel
{
    self.timeYLab.text = [NSString jk_formatDecFloat:self.timeY.floatValue decimal:self.decimal];
    
    NSString *dateChart = chartModel.dateChar;//LJ_MMDD_HH_MM  LJ_HM
    self.dateLab.text = [NSDate jk_timeStringWithFormat:@"yyyy-MM-dd HH:mm" targetFormat:@"HH:mm" strValue:dateChart];
    self.timeYLab.textColor = self.dateLab.textColor = [UIColor jk_colorWithHexString:@"#f3f94c"];
    
    if ([chartModel.clp length] < 1) {
        chartModel = self.lastExistChattModel;
    }
    self.priceLab.text = [NSString jk_formatDecFloat:chartModel.clp.floatValue decimal:self.decimal];
    self.avgLab.text = [NSString jk_formatDecFloat:chartModel.avp.floatValue decimal:self.decimal];
    
    //涨跌值
    float udp = [chartModel.clp floatValue] - [upChartModel.clp floatValue];
    self.up1Lab.text = [NSString jk_formatDecFloat:udp decimal:self.decimal];
    //涨跌幅
    float udpPer = (udp / [upChartModel.clp floatValue]) * 100;
    self.up2Lab.text = [NSString stringWithFormat:@"%@%%",[NSString jk_formatDecFloat:udpPer decimal:self.decimal]];

    //成交量
    self.vol1Lab.text = [NSString jk_formatDecFloat:chartModel.vol.floatValue decimal:0];
    self.vol2Lab.text = [NSString jk_formatDecFloat:(chartModel.vol.floatValue - upChartModel.vol.floatValue) decimal:0];
    
}

@end
