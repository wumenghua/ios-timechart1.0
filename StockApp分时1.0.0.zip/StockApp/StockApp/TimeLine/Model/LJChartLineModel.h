//
//  LJChartLineModel.h
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/5/16.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import <Foundation/Foundation.h>

#import <CoreGraphics/CGGeometry.h>
#import <UIKit/UIKit.h>

@interface LJChartLineModel : NSObject

//字符类型时间字段
@property (nonatomic ,strong) NSString *dateChar;

//时间字体坐标点
@property (nonatomic ,assign) CGRect dateChartRect;

//当前坐标是否有重叠,yes=隐藏 no=显示
@property (nonatomic ,assign) BOOL isIntersects;

//是否实线 yes=实线 no=虚线
@property (nonatomic ,assign) BOOL isRealityLinel;

//线起始坐标点
@property (nonatomic ,assign) CGPoint lineStartPoint;
//线结束坐标点
@property (nonatomic ,assign) CGPoint lineEndPoint;

//分钟
@property (nonatomic ,assign) double clp;
@property (nonatomic ,assign) CGRect clpRect;

//百分率
@property (nonatomic ,assign) double percentage;
@property (nonatomic ,assign) CGRect percentageRect;

//横线左右字体颜色
@property (nonatomic ,retain) UIColor *horFontColor;

//成交量
@property (nonatomic ,assign) double vol;
@property (nonatomic ,assign) CGRect volRect;

//持仓量
@property (nonatomic ,assign) double opi;
@property (nonatomic ,assign) CGRect opiRect;



@end
