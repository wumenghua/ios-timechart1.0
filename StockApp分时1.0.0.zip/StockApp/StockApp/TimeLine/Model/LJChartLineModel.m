//
//  LJChartLineModel.m
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/5/16.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "LJChartLineModel.h"

@implementation LJChartLineModel

- (id)init
{
    if(self = [super init])
    {
        self.isRealityLinel = NO;
        self.isIntersects = NO;
    }
    return self;
}

@end
