//
//  LJTimeChartModel.h
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/5/15.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreGraphics/CGGeometry.h>

@interface LJTimeChartModel : NSObject

//double OpenPrice(开盘价),double ClosePrice(收盘价)，double    AveragePrice(均价)，int Volume(成交量)，int OpenInterest(持仓量)，int bar时间(时间戳精确到秒)

//字符类型时间字段
@property (nonatomic ,strong) NSString * dateChar;
//字符类型时间字段  HH:mm
@property (nonatomic ,strong) NSString * dateCharHm;
//当前数据所属交易日
@property (nonatomic,strong) NSString *tradingDay;

//时间戳
@property (nonatomic ,assign) NSInteger bar;

//开盘价
@property (nonatomic ,strong) NSString *op;

//收盘价
@property (nonatomic ,strong) NSString *clp;

//平均价
@property (nonatomic ,strong) NSString *avp;

//分时线坐标点
@property (nonatomic, assign) CGPoint linePoint;

//均线坐标点
@property (nonatomic, assign) CGPoint avgPoint;

//------------------------

//线颜色
//@property (nonatomic ,retain) NSString *lineColor;

//成交量
@property (nonatomic ,strong) NSString *vol;

//持仓量
@property (nonatomic ,strong) NSString *opi;

//成交量坐标点
@property (nonatomic, assign) CGPoint startVolPoint;
@property (nonatomic, assign) CGPoint endVolPoint;

//持仓量坐标点
@property (nonatomic, assign) CGPoint opiPoint;

//是否断开线条重绘
@property (nonatomic,assign) BOOL isOffLine;


@end
