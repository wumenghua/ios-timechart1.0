//
//  LJTimeChartView.m
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/5/14.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "LJTimeChartView.h"
#import "UIViewAdditions.h"

#import "LJTimeChartView+BorderLayer.h"
#import "LJTimeChartView+Clp.h"
#import "LJTimeChartView+Vol.h"
#import "LJTimeLayerView.h"
#import "UIView+JKVisuals.h"


@interface LJTimeChartView(){
    //是否显示十字架
    BOOL _isTicks;
    CGPoint _isTicksPoint;
}

/**十字叉图层*/
@property (nonatomic, strong) CAShapeLayer *ticksLayer;

//左右浮层
@property (nonatomic,strong) LJTimeLayerView *layerView;




@end

@implementation LJTimeChartView


- (id)init
{
    if(self = [super init])
    {
        //默认120分钟显示一个竖线
        self.minute = 180;
        self.horLineCount = 6;
        
        self.lineRealityGapHeight = 4;
        self.volRealityGapHeight = 2;
        
        self.attribute = @{NSFontAttributeName:[UIFont systemFontOfSize:14.f]};
        self.attfontSize = 14.f;
        
        self.timePointH = 30;
        
        self.pageIndex = 1;
        self.maxPageCount = 5;
        
        self.intervalCount = -1;
        
        _isTicks = NO;
        self.timeDrawChartArr = [[NSMutableArray alloc] init];
        self.timeChartTotalArray = [[NSMutableArray alloc] init];
        
        self.isAllowPage = YES;
        self.isLandscapeUpdate = NO;
        
        [self longGesture];
        [self tapGesture];
        [self panGesture];
        [self pinchGesture];
        
        
    }
    return self;
}

/**
 初始化分时图，用户画出表格线
 */
- (void)initTimeChart
{
    //交易时间范围
    NSString *timesStr = @"05:00,06:00";
    //交易数据赋值
    self.zrclp = 0;
    //计算分时图空白数据模型数组
    NSMutableArray *casualArray = [LJTimeChartUtil chartTimeArray:[timesStr componentsSeparatedByString:@","] isTimestamp:false];
    self.timeChartArr = casualArray;
    self.decimal = 0;
    self.firstTimeHmDictionary = nil;
    //每一次刷新 + 分页都需要重新刷新
    [self draw];
}

/**
 绘制
 */
- (void)draw {
    //开启缩放手势
    self.pinchGesture.enabled = YES;
    //初始化最高价|最低价 or Frame or 单位高度
    [self findDrawLineArray];
    //获取最新一天分时的时分位置
    if (self.pageIndex == 1) {
        [self getTimeFirstHmIndexDictionary];
    }
    //计算收盘价、均价 成交量、持仓量 线的位置
    [self findClpAvpDrawLineArray];
    
    //计算 主图 横线位置 + 价格
    [self findClpAVGHorLinePointArray];
    //计算 主图 竖线 位置+时间
    [self findClpAVGVerLinePointArray];
    
    //计算 幅图 横虚线 + 成交量|持仓量文字 坐标
    [self findVolOpiVerLinePointArray];
    //重绘
    [self setNeedsDisplay];
    
    if (_isTicks) {
        //是否为横屏产品更改
        if (self.isLandscapeUpdate) {
            self.isLandscapeUpdate = NO;
            //更新Y轴位置
            _isTicksPoint = CGPointMake(_isTicksPoint.x, self.selectPointModel.linePoint.y);
            [self getIdxLineModelAndMoveTicks:self.selectIdx];
            //更新浮层位置
            [self.layerView updateLayerFrame];
        }else{
            //重新加载数据时，判断是否需要显示十字线，如果需要就重绘；
            [self chartMovedDrawLine:_isTicksPoint status:UIGestureRecognizerStateBegan];
            //隐藏浮层
            [self.layerView hideLayer];
        }
    }
    self.layerView.lastExistChattModel = self.lastExistChattModel;
    self.layerView.zrclp = self.zrclp;
    self.layerView.decimal = self.decimal;
    [self bringSubviewToFront:self.layerView];
}

/**
 重置数据
 */
-(void)updateDraw {

//    CFAbsoluteTime startTime =CFAbsoluteTimeGetCurrent();
    
    BOOL blg = false;
    //极限值最新 最高价、最低价
    NSDictionary *clpMaxMinDic = [self.timeChartArr calculateClpMaxMin];
    float nMaxClpValue = [[clpMaxMinDic objectForKey:LJ_Max] floatValue];
    float nMinClpValue = [[clpMaxMinDic objectForKey:LJ_Min] floatValue];

    //极限值最新 成交量、持仓量
    NSDictionary *volMaxMinDic = [self.timeChartArr calculateVolMaxMin];
    float nMaxVolValue = [[volMaxMinDic objectForKey:LJ_Max] floatValue];
    float nMinVolValue = [[volMaxMinDic objectForKey:LJ_Min] floatValue];

    NSDictionary *opiMaxMinDic = [self.timeChartArr calculateOpIMaxMin];
    float nMaxOpiValue = [[opiMaxMinDic objectForKey:LJ_Max] floatValue];
    float nMinOpiValue = [[opiMaxMinDic objectForKey:LJ_Min] floatValue];

    blg = nMaxClpValue > self.maxClpValue ? true : false;
    blg = nMinClpValue < self.minClpValue ? true : false;

    blg = nMaxVolValue > self.maxVolValue ? true : false;
    blg = nMinVolValue < self.minVolValue ? true : false;

    blg = nMaxOpiValue > self.maxOpiValue ? true : false;
    blg = nMinOpiValue < self.minOpiValue ? true : false;

//    CFAbsoluteTime linkTime = (CFAbsoluteTimeGetCurrent() - startTime);
//    NSLog(@"Linked in %f ms date", linkTime *1000.0);
    
    //根据之前记录的最高价、最低价、成交量、持仓量 对比，如果价格有变动则重新计算，无变动则聚不会值
    if (!blg) {
        //极限值最新 收盘价 最高价、最低价   （防止重复计算极限值）
        self.maxClpValue = nMaxClpValue;
        self.minClpValue = nMinClpValue;
        //极限值最新 成交量、持仓量
        self.maxVolValue = nMaxVolValue;
        self.minVolValue = nMinVolValue;
        //极限值最新 持仓量
        self.maxOpiValue = nMaxOpiValue;
        self.minOpiValue = nMinOpiValue;
        
        //计算Clp真实层高
        [self findClpRealLayerHeight];
        //计算收盘价、均价 线的位置
        [self findClpAvpDrawLineArray];
        //开启缩放手势
        self.pinchGesture.enabled = YES;
        //重绘
        [self setNeedsDisplay];
    }else{
        [self draw];
    }
    self.layerView.lastExistChattModel = self.lastExistChattModel;
    [self bringSubviewToFront:self.layerView];
}

//主动清空数据
- (void)releaseView
{
    [self.layerView removeAllSubViews];
    [self.layerView removeFromSuperview];
    self.layerView = nil;
    
    self.timeChartTotalArray = nil;
    self.lastExistChattModel = nil;
    self.timeDrawChartArr= nil;
    self.volDrawCharArr = nil;
    
}

//获取最新一天分时的时分位置
- (void)getTimeFirstHmIndexDictionary
{
    if (!self.firstTimeHmDictionary || self.firstTimeHmDictionary.count == 0) {
        self.firstTimeHmDictionary = [[NSMutableDictionary alloc] init];
        if (self.timeChartTotalArray && self.timeChartTotalArray.count > 0) {
            NSArray *timeChartArray = self.timeChartTotalArray[0];
            for (int i = 0; i < timeChartArray.count; i++) {
                @autoreleasepool {
                    LJTimeChartModel *chartModel = timeChartArray[i];
                    [self.firstTimeHmDictionary setObject:@(i).stringValue forKey:chartModel.dateCharHm];
                }
            }
        }
    }
}

/**
    初始化最高价|最低价 or Frame or 单位高度
 */
- (void)findDrawLineArray {
    
    self.format = [@"%." stringByAppendingFormat:@"%df",self.decimal];
    
    self.viewHeight = self.height;
    //划分上下绘制层高度
    self.lineHeight = (self.height - self.timePointH) * (2.0 / 3);
    self.volHeight = (self.height - self.timePointH) * (1.0 / 3);
    
    self.lineHeightReality = self.lineHeight - self.lineRealityGapHeight;
    self.volHeightReality = self.volHeight - self.volRealityGapHeight;
    
    //极限值最新 收盘价   （防止重复计算极限值）
    NSDictionary *maxMinDic = [self.timeChartArr calculateClpMaxMin];
    self.maxClpValue = [[maxMinDic objectForKey:LJ_Max] floatValue];
    self.minClpValue = [[maxMinDic objectForKey:LJ_Min] floatValue];
    //极限值最新 成交量、持仓量
    NSDictionary *volMaxMinDic = [self.timeChartArr calculateVolMaxMin];
    self.maxVolValue = [[volMaxMinDic objectForKey:LJ_Max] floatValue];
    self.minVolValue = [[volMaxMinDic objectForKey:LJ_Min] floatValue];
    //极限值最新 持仓量
    NSDictionary *opiMaxMinDic = [self.timeChartArr calculateOpIMaxMin];
    self.maxOpiValue = [[opiMaxMinDic objectForKey:LJ_Max] floatValue];
    self.minOpiValue = [[opiMaxMinDic objectForKey:LJ_Min] floatValue];
    
    //总分钟
    self.sumMinute = (int)self.timeChartArr.count;
    
    //计算Clp真实层高
    [self findClpRealLayerHeight];
    
    //可显示多少个竖线
    self.verLineCount = self.sumMinute / self.minute;
    
    //提前计算 主图 高度，用于后续坐标计算
    self.frameX = 0.f;
    self.frameY = self.timePointH / 2;
    self.frameW = CGRectGetWidth(self.frame);
    self.frameH = self.lineHeight;
    
    //单位高
    self.unitH = self.frameH / self.horLineCount;
}

#pragma -mark 计算Clp层真实层高
- (void)findClpRealLayerHeight
{
    //重新计算最高价 与 最低价
    double maxClpSub = self.maxClpValue - self.zrclp;
    double minClpSub = self.zrclp - self.minClpValue;
    BOOL blg = maxClpSub > minClpSub ? YES : NO;
    if (blg) {
        self.minClpValue = self.zrclp - maxClpSub;
    }else{
        self.maxClpValue = self.zrclp + minClpSub;
    }
    //计算每个点位的宽度 与 高度 位置
    self.dotWidth = self.width / _sumMinute;
    
    //主图 Bar每一个点的高度
    self.dotHeight = self.lineHeightReality / (self.maxClpValue - self.minClpValue);
    
    //幅图 Bar成交量每一个点高度
    self.dotVolHeight = self.volHeightReality / (self.maxVolValue - self.minVolValue);
    if (isinf(self.dotVolHeight)) {
        self.dotVolHeight = 0;
    }
    //幅图 Bar持仓量每一个点高度
    self.dotOpiHeight = self.volHeightReality / (self.maxOpiValue - self.minOpiValue);
    if (isinf(self.dotOpiHeight)) {
        self.dotOpiHeight = 0;
    }
}

- (void)drawRect:(CGRect)rect
{
    [super drawRect:rect];
    
    if (!self.timeChartArr) {
        return;
    }
    CGContextRef contextRef = UIGraphicsGetCurrentContext();
    
    //CFAbsoluteTime startTime =CFAbsoluteTimeGetCurrent();
    
    //设置分页时需要填充的边框
    [self drawPageFillColor:contextRef];
    //绘制边框
    [self drawBorderLayer:contextRef];
    
    //绘制 主图 竖线 位置+时间
    [self drawVerTimePointLayer:contextRef];
    //绘制 主图 横线位置 + 价格
    [self drawHorTimePointLayer:contextRef];
    
    //绘制 幅图 横虚线 + 成交量|持仓量文字 坐标
    [self drawVolOpiRange:contextRef];
    //绘制收盘价、均价 成交量、持仓量 线的位置
    [self drawClpTimeLinePointCG:contextRef];
    
    
    //CFAbsoluteTime linkTime = (CFAbsoluteTimeGetCurrent() - startTime);
    //NSLog(@"Linked in %f ms - rect ", linkTime *1000.0);
    
}

#pragma -mark 缩放手势
- (void)timePinchGestureAction:(UIPinchGestureRecognizer *)pinchGesture
{
    //初始化scale值
    static CGFloat oldScale = 1.0f;
    //缩放区间值
    static CGFloat difValue = 0.10f;
    if(pinchGesture.numberOfTouches == 2 ) {
        if (pinchGesture.state == UIGestureRecognizerStateChanged)
        {
            BOOL isEnLerge = true;
            if (pinchGesture.scale - oldScale > difValue) {
                pinchGesture.enabled = NO;
                
                if (self.delegate && [self.delegate respondsToSelector:@selector(lj_PinchNumberOfTouches:)] && pinchGesture.enabled == NO) {
                    [self.delegate lj_PinchNumberOfTouches:isEnLerge];
                }
            }else if (pinchGesture.scale - oldScale < -difValue){
                isEnLerge = false;
                pinchGesture.enabled = NO;
                
                if (self.delegate && [self.delegate respondsToSelector:@selector(lj_PinchNumberOfTouches:)] && pinchGesture.enabled == NO) {
                    [self.delegate lj_PinchNumberOfTouches:isEnLerge];
                }
            }
        }
        if ((pinchGesture.state ==UIGestureRecognizerStateEnded) || (pinchGesture.state ==UIGestureRecognizerStateCancelled))
        {
            oldScale = 1.0f;
            //pinchGesture.enabled = YES;
        }
    }
}

#pragma -mark 单击手势
- (void)timeTapGestureAction:(UITapGestureRecognizer *)tapGesture {
    
    //获取坐标
    //CGPoint point = [tapGesture locationInView:self];
    //NSLog(@"1-%@",NSStringFromCGPoint(point));
    if (_isTicks) {
        _isTicks = NO;
        
        if (self.delegate && [self.delegate respondsToSelector:@selector(lj_MoveTimeTicksEnd)]) {
            [self.delegate lj_MoveTimeTicksEnd];
        }
        [self clearTicks];
        //关闭浮层
        [self.layerView hideLayer];
    }else{
        //画线分析
        
    }
}

#pragma -mark 平移手势
- (void)timePanGestureAction:(UIPanGestureRecognizer *)panGesture {
    
    //CGPoint point = [panGesture locationInView:self];
    //NSLog(@"2-%@",NSStringFromCGPoint(point1));
    CGPoint point = [panGesture translationInView:_panGesture.view];
    //NSLog(@"2-%@",NSStringFromCGPoint(point1));
    if (_isTicks)
    {
        float x = _isTicksPoint.x + point.x;
        float y = _isTicksPoint.y + point.y;
        
        x = x < 0 ? 0 : x;
        x = x > self.width ? self.width : x;
        y = y < self.timePointH/2 ? self.timePointH/2 : y;
        y = y > self.height - self.timePointH/2 ? self.height - self.timePointH/2 : y;
        
        [self chartMovedDrawLine:CGPointMake(x, y) status:UIGestureRecognizerStateChanged];
        
        if (panGesture.state == UIGestureRecognizerStateEnded) {
            _isTicksPoint = CGPointMake(x, y);
        }
    }else {
        //画线下单
        //画线分析
    }
}

#pragma -mark 长按手势
- (void)timeChartLongGestureAction:(UILongPressGestureRecognizer *)longGesture
{
    //第一次长按获取 或者 长按然后变化坐标点
    //CGPoint point = [longGesture locationInView:self];
    //NSLog(@"3-%@",NSStringFromCGPoint(point));
    CGPoint point = [longGesture locationInView:self];
    if (longGesture.state == UIGestureRecognizerStateBegan || longGesture.state == UIGestureRecognizerStateChanged)
    {
        //不等于画线下单 or 不等于画线分析
        _isTicksPoint = point;
        _isTicks = YES;
        [self chartMovedDrawLine:_isTicksPoint status:UIGestureRecognizerStateChanged];
    }
}

- (void)chartMovedDrawLine:(CGPoint)point status:(UIGestureRecognizerState)status
{
    [self clearTicks];
    
    int index = (int)round(point.x / _dotWidth);
    if (index >= self.timeChartArr.count)
    {
        index = (int)self.timeChartArr.count - 1;
    }
    
    point.x = point.x < 0 ? 0 : point.x;
    point.x = point.x > self.width ? self.width : point.x;
    point.y = point.y < self.timePointH/2 ? self.timePointH/2 : point.y;
    point.y = point.y > self.height - self.timePointH/2 ? self.height - self.timePointH/2 : point.y;
    
    self.selectIdx = index;
    self.selectPointModel = [self.timeChartArr objectAtIndex:index];
    
    UIBezierPath *path = [UIBezierPath bezierPath];
    //竖线
    [path moveToPoint:CGPointMake(point.x, self.timePointH / 2)];
    [path addLineToPoint:CGPointMake(point.x, self.height - self.timePointH / 2)];
    //横线
    [path moveToPoint:CGPointMake(0, point.y)];
    [path addLineToPoint:CGPointMake(self.width, point.y)];
    //设置横竖线的属性
    self.ticksLayer.path = path.CGPath;
    self.ticksLayer.lineWidth = 0.8f;
    self.ticksLayer.strokeColor = [UIColor whiteColor].CGColor;
    self.ticksLayer.fillColor = [UIColor clearColor].CGColor;
    //再添加到分时图view的图层中
    [self.layer addSublayer:self.ticksLayer];
    
    //置顶浮层
    [self bringSubviewToFront:self.layerView];
    //浮层数据计算
    if (CGRectContainsPoint(CGRectMake(self.frameX, self.frameY, self.frameW, self.lineHeight), point)) {
        self.layerView.timeY = [self findTimeLayer_Y_Clp:point.y];
    }else if (CGRectContainsPoint(CGRectMake(self.frameX, self.frameY + self.lineHeight, self.frameW, self.volHeight), point)) {
        self.layerView.timeY = [self findTimeLayer_Y_Vol:point.y];
    }
    LJTimeChartModel *upChartModel = self.selectPointModel;
    if (index != 0) {
        upChartModel = [self.timeChartArr objectAtIndex:index-1];
    }
    //显示浮层
    [self.layerView showLayer:point chartModel:self.selectPointModel upChartModel:upChartModel];
    
    if (status == UIGestureRecognizerStateChanged) {
        if (self.delegate && [self.delegate respondsToSelector:@selector(lj_MoveTimeTicksChanged:idx:x:y:)]) {
            [self.delegate lj_MoveTimeTicksChanged:self.selectPointModel idx:index x:point.x y:point.y];
        }
    }
}

-(void)clearTicks {
    //清理十字叉图层
    [self.ticksLayer removeFromSuperlayer];
    self.ticksLayer.sublayers = nil;
}
//隐藏十字架
- (void)hideTicks {
    if (_isTicks) {
        _isTicks = NO;
        //关闭十字架
        [self clearTicks];
        //关闭浮层
        [self.layerView hideLayer];
    }
}

#pragma -mark 手势滑动  -------结束

/**
 根据索引获取Point
 */
-(CGPoint)getIdxLinePoint:(int)idx{
    return ((LJTimeChartModel *)[self.timeChartArr objectAtIndex:idx]).linePoint;
}

/**
 根据索引获取model，并移动十字架
 */
-(LJTimeChartModel *)getIdxLineModelAndMoveTicks:(int)idx{
    
    if (idx < 0 || idx > (self.timeChartArr.count - 1)) {
        return nil;
    }
    LJTimeChartModel *chartModel = [self.timeChartArr objectAtIndex:idx];
    if (_isTicks) {
        _isTicksPoint.x = chartModel.linePoint.x;
        if (CGPointEqualToPoint(chartModel.linePoint,CGPointZero)) {
            _isTicksPoint.x = idx * self.dotWidth;
        }
        [self chartMovedDrawLine:_isTicksPoint status:UIGestureRecognizerStateChanged];
    }
    return chartModel;
}

#pragma mark - lazy
- (CAShapeLayer *)ticksLayer{
    if (!_ticksLayer){
        _ticksLayer = [CAShapeLayer layer];
    }
    return _ticksLayer;
}

- (UILongPressGestureRecognizer *)longGesture {
    if (!_longGesture) {
        _longGesture = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(timeChartLongGestureAction:)];
        _longGesture.minimumPressDuration = 0.3f;
        _longGesture.numberOfTouchesRequired = 1;
        [self addGestureRecognizer:_longGesture];
    }
    return _longGesture;
}

-(UITapGestureRecognizer *)tapGesture {
    if (!_tapGesture) {
        _tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(timeTapGestureAction:)];
        [self addGestureRecognizer:_tapGesture];
    }
    return _tapGesture;
}

-(UIPanGestureRecognizer *)panGesture {
    if (!_panGesture) {
        _panGesture = [[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(timePanGestureAction:)];
        [self addGestureRecognizer:_panGesture];
    }
    return _panGesture;
}
-(UIPinchGestureRecognizer *)pinchGesture {
    if (!_pinchGesture) {
        _pinchGesture = [[UIPinchGestureRecognizer alloc]initWithTarget:self action:@selector(timePinchGestureAction:)];
        [self addGestureRecognizer:_pinchGesture];
    }
    return _pinchGesture;
}

- (LJTimeLayerView *)layerView {
    if (!_layerView) {
        _layerView = [[LJTimeLayerView alloc] init];
        [_layerView jk_cornerRadius:0 strokeSize:0.7 color:[UIColor whiteColor]];
        _layerView.frame = CGRectMake(0, self.timePointH/2, 90, 222);
        [self addSubview:_layerView];
    }
    return _layerView;
}


@end
