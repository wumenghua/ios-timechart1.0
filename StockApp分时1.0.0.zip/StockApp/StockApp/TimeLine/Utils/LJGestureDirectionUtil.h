//
//  LJGestureDirectionUtil.h
//  YiFu
//
//  Created by 伍孟华 on 2018/7/4.
//  Copyright © 2018年 伍孟华. All rights reserved.
//



//滑动方向
typedef enum {
    LJ_DirectionNone,  // 无法识别方向
    LJ_DirectionUp,    // 向上拖动
    LJ_DirectionDown,  // 向下拖动
    LJ_DirectionLeft,  // 向左拖动
    LJ_DirectionRight, // 向右拖动
}LJ_ENUM_Direction;

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface LJGestureDirectionUtil : NSObject

// 根据手势位移判断方向
+ (LJ_ENUM_Direction )directionByPoint:(CGPoint)translation direction:(LJ_ENUM_Direction)direction directionTranslation:(float)directionTranslation;

@end
