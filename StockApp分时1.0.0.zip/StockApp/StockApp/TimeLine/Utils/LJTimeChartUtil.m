//
//  LJTimeChartUtil.m
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/5/15.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "LJTimeChartUtil.h"
#import "NSDate+JKUtilities.h"
#import "LJTimeChartModel.h"
#import "NSString+Decimal.h"
#import "UIColor+JKHEX.h"

#import "LJKLineModel.h"
#import "LJKLineCandleModel.h"
#import "LJKLineMAModel.h"
#import "LJKLineEMAModel.h"
#import "LJKLineBOLLModel.h"
#import "LJKLineMVModel.h"
#import "LJKLineMACDModel.h"
#import "LJKLineKDJModel.h"
#import "LJKLineRSIModel.h"

@implementation LJTimeChartUtil

/**
 获取分时图接口字符串中分时bar的key-value

 @param content conteng
 @return dic
 */
+(NSMutableDictionary *)getTimeChartModelDictionary:(NSString *)content
{
    NSMutableDictionary *timeChartDic = [NSMutableDictionary dictionary];
    //交易时间范围
    NSArray *tradeTime = [content componentsSeparatedByString:@";"];
    for (int i = 0 ; i < tradeTime.count ; i++) {
        @autoreleasepool {
            NSArray *cutArr = [tradeTime[i] componentsSeparatedByString:@","] ;
            LJTimeChartModel *chartModel = [[LJTimeChartModel alloc] init];
            chartModel.op = cutArr[0];
            chartModel.clp = cutArr[1];
            chartModel.avp = cutArr[2];
            chartModel.vol = cutArr[3];
            chartModel.opi = cutArr[4];
            chartModel.bar =  [cutArr[5] intValue];
            //LJ_YYYY_MM_DD_HH_MM
            chartModel.dateChar = [NSDate jk_timeIntervalWithFormat:@"HH:mm" timeInterval:chartModel.bar];
            [timeChartDic setValue:chartModel forKey:chartModel.dateChar];
        }
        //[NSDate date] timeIntervalSinceNow
    }
    return timeChartDic;
}

+(NSInteger)getLastBarInterval:(NSString *)content {
    NSArray *tradeTime = [content componentsSeparatedByString:@";"];
    NSArray *cutArr = [tradeTime.lastObject componentsSeparatedByString:@","];
    return [[cutArr objectAtIndex:5] integerValue];
}

/**
 获取分时图接口字符串中分时bar的Array
 
 @param content conteng
 @return dic
 */
+(NSMutableArray *)getTimeChartModelArray:(NSString *)content
{
    NSMutableArray *timeChartArray = [[NSMutableArray alloc] init];
    //交易时间范围
    NSArray *tradeTime = [content componentsSeparatedByString:@";"];
    //删除第一个，第二个 已经获取的数据，删除最后一个空数据
    for (int i = 0 ; i < tradeTime.count ; i++) {
        @autoreleasepool {
            NSArray *cutArr = [tradeTime[i] componentsSeparatedByString:@","] ;
            LJTimeChartModel *chartModel = [[LJTimeChartModel alloc] init];
            chartModel.op = cutArr[0];
            chartModel.clp = cutArr[1];
            chartModel.avp = cutArr[2];
            chartModel.vol = cutArr[3];
            chartModel.opi = cutArr[4];
            chartModel.bar =  [cutArr[5] intValue];
            //LJ_YYYY_MM_DD_HH_MM
            chartModel.dateChar = [NSDate jk_timeIntervalWithFormat:@"yyyy-MM-dd HH:mm" timeInterval:chartModel.bar];
            chartModel.dateCharHm = [NSDate jk_timeIntervalWithFormat:@"HH:mm" timeInterval:chartModel.bar];
            [timeChartArray addObject:chartModel];
        }
    }
    return timeChartArray;
}


/**
 获取K线接口字符串中分时bar的key-value
 
 @param content conteng
 @return dic
 */
+(NSMutableArray *)getKLineChartModelArray:(NSString *)content
{
    NSMutableArray *kLineChartArray = [[NSMutableArray alloc] init];
    //交易时间范围
    NSArray *klineArray = [content componentsSeparatedByString:@";"];
    for (int i = 0 ; i < klineArray.count ; i++) {
        NSArray *cutArr = [klineArray[i] componentsSeparatedByString:@","] ;
        
        LJKLineModel *kLineModel = [[LJKLineModel alloc] init];
        kLineModel.op = cutArr[0];
        kLineModel.clp = cutArr[1];
        kLineModel.hip = cutArr[2];
        kLineModel.lop = cutArr[3];
        kLineModel.vol = cutArr[4];
        kLineModel.opi = cutArr[5];
        kLineModel.dateChar = cutArr[6];
        
        //蜡烛、趋势、量仓、摆动
        kLineModel.candleModel = [[LJKLineCandleModel alloc] init];
        kLineModel.qsModel = [[LJKLineBaseModel alloc] init];
        kLineModel.lcModel = [[LJKLineBaseModel alloc] init];
        kLineModel.bdModel = [[LJKLineBaseModel alloc] init];
        
        [kLineChartArray addObject:kLineModel];
    }
    return kLineChartArray;
}

/**
 计算数据时间相差分钟

 @param treatyArray 数组
 @return 返回总分钟
 */
+ (int)chartRange:(NSArray *)treatyArray {
    
    int minute = 0;
    for (int i=0; i < treatyArray.count; i++) {
        NSInteger startTime = [treatyArray[i] integerValue];
        NSInteger endTime = [treatyArray[i+1] integerValue];
        minute += [LJTimeChartUtil compareTime:startTime time2:endTime];
        i++;
    }
    return minute;
}

/**
 计算开始时间 - 结束时间 相差多少分钟

 @param time1 开始时间
 @param time2 结束时间
 @return 返回值
 */
+ (int)compareTime:(long long)time1 time2:(long long)time2{
    
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDate *starDate = [NSDate dateWithTimeIntervalSince1970:time1];//开始时间
    NSDate *endDate = [NSDate dateWithTimeIntervalSince1970:time2];//结束时间
    unsigned int unitFlags = NSCalendarUnitYear| NSCalendarUnitMonth | NSCalendarUnitDay | NSCalendarUnitHour | NSCalendarUnitMinute | NSCalendarUnitSecond ;
    NSDateComponents *d = [calendar components:unitFlags fromDate:starDate toDate:endDate options:0];
    
    int ren =0;
    //天
    if ([d day] > 0) {
        
        ren += [d day] * 24 * 60;
    }
    //小时
    if([d hour] > 0){
        ren += [d hour] * 60;
    }
    //分钟
    if ([d minute] > 0) {
        ren += [d minute];
    }
    //秒 [d second]
    return ren;
}



/**
 获取总分钟 / 分钟数 = 间隔区间
 
 @param minute 分钟数
 @param sumMinute 总分钟
 @return 间隔区间
 */
- (int)getChartLineCount:(int)minute sumMinute:(int)sumMinute{
    return sumMinute / minute;
}


/**
 计算数据时间相差分钟
 
 @param treatyArray 数组
 @return 返回总分钟
 */
+ (NSMutableArray *)chartTimeArray:(NSArray *)treatyArray isTimestamp:(BOOL)isTimestamp
{
    treatyArray = [LJTimeChartUtil chartTimesToDateArray:treatyArray];
    
    NSMutableArray *minuteArray = [[NSMutableArray alloc] init];
    for (int i=0; i < treatyArray.count; i++) {
        @autoreleasepool {
            NSInteger startTime;
            NSInteger endTime;
            NSMutableArray *timeArray;
            
            if (isTimestamp) {
                startTime = [treatyArray[i] integerValue];
                endTime = [treatyArray[i+1] integerValue];
                timeArray = [LJTimeChartUtil compareTwoTime:startTime time2:endTime];
            }else{
                NSDate *startDate = [NSDate jk_timeStringToNSDateWith:@"yyyy-MM-dd HH:mm" strValue:treatyArray[i]];
                startDate = [startDate jk_dateByAddingHours:8];
                NSDate *endDate = [NSDate jk_timeStringToNSDateWith:@"yyyy-MM-dd HH:mm" strValue:treatyArray[i+1]];
                endDate = [endDate jk_dateByAddingHours:8];
                if (i+1 == treatyArray.count-1) {
                    endDate = [endDate jk_dateByAddingMinutes:1];
                }
                timeArray = [LJTimeChartUtil compareTwoTimeNew:startDate endDate:endDate];
            }
            [minuteArray addObjectsFromArray:timeArray];
            i++;
        }
    }
    return minuteArray;
}

+(NSMutableArray *)chartTimesToDateArray:(NSArray *)treatyArray
{
    NSMutableArray *dateArray = [[NSMutableArray alloc] init];
    NSDate *dayDate = [NSDate date];//[[NSDate date] jk_dateByAddingHours:8];
    
    NSString *day = [[NSDate date] jk_stringWithFormat:@"yyyy-MM-dd"];
    NSString *timesStr = [NSString stringWithFormat:@"%@ %@",day ,treatyArray[0]];
    [dateArray addObject:timesStr];
    
    NSDate *oneDate = [NSDate jk_timeStringToNSDateWith:@"yyyy-MM-dd HH:mm" strValue:timesStr];
    for (int i = 1; i < treatyArray.count; i++) {
        NSString *timesStr = [NSString stringWithFormat:@"%@ %@",day,treatyArray[i]];
        NSDate *twoDate = [NSDate jk_timeStringToNSDateWith:@"yyyy-MM-dd HH:mm" strValue:timesStr];
        
        if ([twoDate compare:oneDate] == NSOrderedDescending) {
            //如果当前日期比前一个日期大，代表是今天
            [dateArray addObject:timesStr];
        }else{
            day = [[dayDate jk_dateByAddingDays:1] jk_stringWithFormat:@"yyyy-MM-dd"];
            timesStr = [NSString stringWithFormat:@"%@ %@",day,treatyArray[i]];
            [dateArray addObject:timesStr];
        }
        oneDate = twoDate;
    }
    return dateArray;
}

//        NSDate *starDate = [NSDate dateWithTimeIntervalSince1970:startTime];//开始时间
//        starDate = [starDate dateBySubtractingHours:3];
//        starDate = [starDate dateBySubtractingMinutes:1];
//        starDate = [starDate dateBySubtractingMinutes:1];
//        startTime = [starDate timeIntervalSince1970];



/**
 计算开始时间 - 结束时间 相差多少分钟
 
 @param time1 开始时间
 @param time2 结束时间
 @return 返回值
 */
+ (NSMutableArray *)compareTwoTime:(long long)time1 time2:(long long)time2{
    
    NSDate *starDate = [NSDate dateWithTimeIntervalSince1970:time1];//开始时间
    NSDate *endDate = [NSDate dateWithTimeIntervalSince1970:time2];//结束时间
//    endDate = [endDate jk_dateByAddingMinutes:1];
    
    NSMutableArray *dateArray = [[NSMutableArray alloc] init];
    do {
        
        NSString *dfDateStr = [starDate jk_dateWithFormat:@"yyyy-MM-dd HH:mm"];
        
        LJTimeChartModel *chartModel = [[LJTimeChartModel alloc] init];
        chartModel.dateChar = dfDateStr;
        chartModel.bar = [starDate timeIntervalSince1970];
        chartModel.isOffLine = NO;
        
        [dateArray addObject:chartModel];
        
        starDate = [starDate jk_dateByAddingMinutes:1];
        
    } while (![starDate jk_isSameMinute:endDate]);
    
    return dateArray;
}

+ (NSMutableArray *)compareTwoTimeNew:(NSDate *)starDate endDate:(NSDate *)endDate
{
    NSMutableArray *dateArray = [[NSMutableArray alloc] init];
    do {
        NSString *dfDateStr = [[starDate jk_dateBySubtractingHours:8] jk_dateWithFormat:@"yyyy-MM-dd HH:mm"];
        NSString *dfDateStrHm = [[starDate jk_dateBySubtractingHours:8] jk_dateWithFormat:@"HH:mm"];
        
        LJTimeChartModel *chartModel = [[LJTimeChartModel alloc] init];
        chartModel.dateChar = dfDateStr;
        chartModel.dateCharHm = dfDateStrHm;
        chartModel.bar = [starDate timeIntervalSince1970];
        chartModel.isOffLine = NO;
        
        [dateArray addObject:chartModel];
        
        starDate = [starDate jk_dateByAddingMinutes:1];
        
    } while (![starDate jk_isSameMinute:endDate]);
    
    return dateArray;
}












@end
