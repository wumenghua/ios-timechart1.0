//
//  LJCGContentUtil.h
//  YiFu
//
//  Created by 伍孟华 on 2018/7/6.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreGraphics/CGGeometry.h>
#import <CoreGraphics/CoreGraphics.h>
#import <UIKit/UIKit.h>

typedef enum {
    LJ_ENUM_CGContent_CLP = 0,
    LJ_ENUM_CGContent_AVG,
    LJ_ENUM_CGContent_VOL,
    LJ_ENUM_CGContent_OPI
} LJ_ENUM_CGContext_LineType;

@interface LJCGContextUtil : NSObject


//绘制虚线
+(void)lj_addLineDash:(CGContextRef)contextRef lineWidth:(float)lineWidth lineColorRef:(CGColorRef)lineColorRef lengths:(CGFloat[])lengths movePoint:(CGPoint)movePoint toPoint:(CGPoint)toPoint;

//绘制单条线
+(void)lj_AddLineToPoint:(CGContextRef)contextRef lineWidth:(float)lineWidth lineColorRef:(CGColorRef)lineColorRef movePoint:(CGPoint)movePoint toPoint:(CGPoint)toPoint;
//绘制多条线
+(void)lj_AddLineToPointsOff:(CGContextRef)contextRef lineWidth:(float)lineWidth lineColorRef:(CGColorRef)lineColorRef movePoints:(NSArray*)movePoints;
//绘制多条线
+(void)lj_AddLineToPoints:(CGContextRef)contextRef lineWidth:(float)lineWidth lineColorRef:(CGColorRef)lineColorRef points:(NSArray *)points lineType:(LJ_ENUM_CGContext_LineType)lineType;
+(void)lj_AddLineToPoints_KLine:(CGContextRef)contextRef lineWidth:(float)lineWidth lineColorRef:(CGColorRef)lineColorRef points:(NSArray *)points;

//绘制方形
+(void)lj_AddRect:(CGContextRef)contextRef lineWidth:(float)lineWidth fillColorRef:(CGColorRef)fillColorRef strokeColorRef:(CGColorRef)strokeColorRef rect:(CGRect)rect;
//绘制方形，背景透明
+(void)lj_AddRect:(CGContextRef)contextRef lineWidth:(float)lineWidth fillColorRef:(CGColorRef)fillColorRef strokeColorRef:(CGColorRef)strokeColorRef rect:(CGRect)rect alpha:(CGFloat)alpha;

//绘制方形列表
+(void)lj_AddRects:(CGContextRef)contextRef lineWidth:(float)lineWidth fillColorRef:(CGColorRef)fillColorRef strokeColorRef:(CGColorRef)strokeColorRef rects:(NSArray *)rects;

//绘制文字
+(void)lj_AddRectFont:(CGContextRef)contextRef text:(NSString *)text font:(UIFont *)font fontColor:(UIColor *)fontColor alignment:(NSTextAlignment)alignment rect:(CGRect)rect;

@end
