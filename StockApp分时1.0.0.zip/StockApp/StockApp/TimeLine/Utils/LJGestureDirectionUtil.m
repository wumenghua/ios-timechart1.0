//
//  LJGestureDirectionUtil.m
//  YiFu
//
//  Created by 伍孟华 on 2018/7/4.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "LJGestureDirectionUtil.h"

@implementation LJGestureDirectionUtil

// 根据手势位移判断方向
+ (LJ_ENUM_Direction )directionByPoint:(CGPoint)translation direction:(LJ_ENUM_Direction)direction directionTranslation:(float)directionTranslation
{
    if (direction != LJ_DirectionNone) {
        return direction;
    }
    // 取绝对值
    if (fabs(translation.x) > directionTranslation) {
        
        BOOL gestureHorizontal = NO;
        if (translation.y == 0) {
            gestureHorizontal = YES;
        }else {
            gestureHorizontal = (fabs(translation.x / translation.y) > 12.0);
        }
        if (gestureHorizontal) {
            if (translation.x > 0) {
                return LJ_DirectionRight;
            }else {
                return LJ_DirectionLeft;
            }
        }
        
    }else if(fabs(translation.y) > directionTranslation) {
        
        BOOL gesturnVertical = NO;
        if (translation.x == 0) {
            gesturnVertical = YES;
        }else {
            gesturnVertical = (fabs(translation.y / translation.x) > 12.0);
        }
        if (gesturnVertical) {
            if (translation.y > 0) {
                return LJ_DirectionDown;
            }else {
                return LJ_DirectionUp;
            }
        }
    }
    return direction;
}

@end
