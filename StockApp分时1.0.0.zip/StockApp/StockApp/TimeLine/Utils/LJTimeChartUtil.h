//
//  LJTimeChartUtil.h
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/5/15.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import <Foundation/Foundation.h>
@class LJKLineModel;

@interface LJTimeChartUtil : NSObject

/**
 获取分时图接口字符串中分时bar的key-value
 
 @param content conteng
 @return dic
 */
+(NSMutableDictionary *)getTimeChartModelDictionary:(NSString *)content;
+(NSInteger)getLastBarInterval:(NSString *)content;

/**
 获取分时图接口字符串中分时bar的Array
 
 @param content conteng
 @return dic
 */
+(NSMutableArray *)getTimeChartModelArray:(NSString *)content;

/**
 获取K线接口字符串中分时bar的key-value
 
 @param content conteng
 @return dic
 */
+(NSMutableArray *)getKLineChartModelArray:(NSString *)content;

/**
 计算数据时间相差分钟
 
 @param treatyArray 数组
 @return 返回总分钟
 */
+ (int)chartRange:(NSArray *)treatyArray;

/**
 计算开始时间 - 结束时间 相差多少分钟
 
 @param time1 开始时间
 @param time2 结束时间
 @return 返回值
 */
+ (int)compareTime:(long long)time1 time2:(long long)time2;


/**
 计算数据时间相差分钟
 
 @param treatyArray 数组
 @return 返回总分钟
 */
+ (NSMutableArray *)chartTimeArray:(NSArray *)treatyArray isTimestamp:(BOOL)isTimestamp;


/**
 计算开始时间 - 结束时间 相差多少分钟
 
 @param time1 开始时间
 @param time2 结束时间
 @return 返回值
 */
+ (NSMutableArray *)compareTwoTime:(long long)time1 time2:(long long)time2;







@end
