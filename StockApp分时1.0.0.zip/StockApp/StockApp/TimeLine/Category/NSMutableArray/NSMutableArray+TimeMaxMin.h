//
//  NSMutableArray+TimeMaxMin.h
//  YiFu
//
//  Created by 伍孟华 on 2018/6/26.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#define LJ_Max @"ljMax"
#define LJ_Min @"ljMin"

#import <Foundation/Foundation.h>

@interface NSMutableArray (TimeMaxMin)


/**
 计算Clp最大值、最小值

 @return dic
 */
- (NSDictionary *)calculateClpMaxMin;


/**
 计算Vol最大值、最小值

 @return dic
 */
- (NSDictionary *)calculateVolMaxMin;


/**
 计算OpI最大值、最小值

 @return dic
 */
- (NSDictionary *)calculateOpIMaxMin;

@end
