//
//  NSMutableArray+TimeMaxMin.m
//  YiFu
//
//  Created by 伍孟华 on 2018/6/26.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "NSMutableArray+TimeMaxMin.h"
#import "LJTimeChartModel.h"

@implementation NSMutableArray (TimeMaxMin)

- (NSDictionary *)calculateClpMaxMin
{
    __block float kpiMax = 0.0f;
    __block float kpiMin = 0.0f;
    __block BOOL isAssign = NO;
    
    [self enumerateObjectsUsingBlock:^(LJTimeChartModel *  _Nonnull model, NSUInteger idx, BOOL * _Nonnull stop) {
        
        if (model.clp.length > 0) {
            if (!isAssign) {
                isAssign = YES;
                kpiMax = [model.clp floatValue];
                kpiMin = kpiMax;
            }
            if ([model.clp floatValue] > kpiMax) {
                kpiMax = [model.clp floatValue];
            }
            if ([model.avp floatValue] > kpiMax) {
                kpiMax = [model.avp floatValue];
            }
            
            if ([model.clp floatValue] < kpiMin) {
                kpiMin = [model.clp floatValue];
            }
            if ([model.avp floatValue] < kpiMin) {
                kpiMin = [model.avp floatValue];
            }
            if (kpiMin > 2797 || kpiMax > 27970) {
                return;
            }
        }
    }];
    return [NSDictionary dictionaryWithObjectsAndKeys:@(kpiMax).stringValue,LJ_Max,@(kpiMin).stringValue,LJ_Min, nil];
}

- (NSDictionary *)calculateVolMaxMin
{
    __block float kpiMax = 0.0f;
    __block float kpiMin = 0.0f;
    __block BOOL isAssign = NO;
    
    [self enumerateObjectsUsingBlock:^(LJTimeChartModel *  _Nonnull model, NSUInteger idx, BOOL * _Nonnull stop) {
        
        if (model.vol.length > 0) {
            if (!isAssign) {
                isAssign = YES;
                kpiMax = [model.vol floatValue];
                kpiMin = kpiMax;
            }
            if ([model.vol floatValue] > kpiMax) {
                kpiMax = [model.vol floatValue];
            }
            if ([model.vol floatValue] < kpiMin) {
                kpiMin = [model.vol floatValue];
            }
        }
    }];
    return [NSDictionary dictionaryWithObjectsAndKeys:@(kpiMax).stringValue,LJ_Max,@(kpiMin).stringValue, LJ_Min, nil];
}

- (NSDictionary *)calculateOpIMaxMin
{
    __block float kpiMax = 0.0f;
    __block float kpiMin = 0.0f;
    __block BOOL isAssign = NO;
    
    [self enumerateObjectsUsingBlock:^(LJTimeChartModel *  _Nonnull model, NSUInteger idx, BOOL * _Nonnull stop) {
        
        if (model.opi.length > 0) {
            if (!isAssign) {
                isAssign = YES;
                kpiMax = [model.opi floatValue];
                kpiMin = kpiMax;
            }
            if ([model.opi floatValue] > kpiMax) {
                kpiMax = [model.opi floatValue];
            }
            if ([model.opi floatValue] < kpiMin) {
                kpiMin = [model.opi floatValue];
            }
        }
    }];
    return [NSDictionary dictionaryWithObjectsAndKeys:@(kpiMax).stringValue,LJ_Max,@(kpiMin).stringValue,LJ_Min, nil];
}

@end
