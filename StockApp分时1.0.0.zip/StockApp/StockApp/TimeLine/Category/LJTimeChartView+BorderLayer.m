//
//  LJTimeChartView+BorderLayer.m
//  YiFu
//
//  Created by 伍孟华 on 2018/6/26.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "LJTimeChartView+BorderLayer.h"
#import "LJTimeChartModel.h"
#import "LJCGContextUtil.h"

@implementation LJTimeChartView (BorderLayer)

/**
 绘制边框
 */
- (void)drawBorderLayer:(CGContextRef)contextRef
{
    float frameX = 0.f;
    float frameY = self.timePointH/2;
    float frameW = CGRectGetWidth(self.frame);
    float frameH = CGRectGetHeight(self.frame) - self.timePointH;
    CGRect rect = CGRectMake(frameX, frameY, frameW, frameH);

    [LJCGContextUtil lj_AddRect:contextRef lineWidth:0.7 fillColorRef:[UIColor clearColor].CGColor strokeColorRef:LJ_Red_Color_CG rect:rect];
}


/**
 设置分页图表填充颜色
 */
- (void)drawPageFillColor:(CGContextRef)contextRef
{
    // >1 才代表有分页
    if (self.pageIndex > 1 && (self.pageIndex-1 < self.timeChartTotalArray.count)) {
        
        NSArray *firstIdxArray = [self.timeChartTotalArray objectAtIndex:self.pageIndex-1];
        NSArray *lastIdxArray = [self.timeChartTotalArray objectAtIndex:0];
        if (firstIdxArray.count > 0 && lastIdxArray.count > 0) {
            LJTimeChartModel *firstModel = [firstIdxArray objectAtIndex:0];
            LJTimeChartModel *lastModel = [lastIdxArray objectAtIndex:0];
            NSInteger firstIndex = [self.timeChartArr indexOfObject:firstModel];
            NSInteger lastIndex = [self.timeChartArr indexOfObject:lastModel];

            float frameX = firstIndex;
            float frameY = self.timePointH/2;
            float frameW = lastIndex * self.dotWidth;
            float frameH = CGRectGetHeight(self.frame) - self.timePointH;
            CGRect rect = CGRectMake(frameX, frameY, frameW, frameH);
            
            [LJCGContextUtil lj_AddRect:contextRef lineWidth:0 fillColorRef:[UIColor grayColor].CGColor strokeColorRef:[UIColor clearColor].CGColor rect:rect alpha:0.2];
        }
    }
}

@end
