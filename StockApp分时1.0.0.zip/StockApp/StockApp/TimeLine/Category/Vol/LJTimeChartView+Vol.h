//
//  LJTimeChartView+Vol.h
//  YiFu
//
//  Created by 伍孟华 on 2018/6/26.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "LJTimeChartView.h"

@interface LJTimeChartView (Vol)


//计算幅图横虚线 成交量|持仓量文字 坐标
- (void)findVolOpiVerLinePointArray;
//绘制幅图横虚线 成交量|持仓量文字 坐标
- (void)drawVolOpiRange:(CGContextRef)contextRef;

//幅图Y轴坐标值 转 价格
- (NSString *)findTimeLayer_Y_Vol:(float)y;

@end
