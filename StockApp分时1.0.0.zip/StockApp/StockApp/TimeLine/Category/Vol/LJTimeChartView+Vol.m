//
//  LJTimeChartView+Vol.m
//  YiFu
//
//  Created by 伍孟华 on 2018/6/26.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "LJTimeChartView+Vol.h"
#import "CATextLayer+textLayer.h"
#import "LJCGContextUtil.h"
#import "NSString+Decimal.h"
#import "NSString+JKSize.h"

@implementation LJTimeChartView (Vol)

/**
 计算幅图横虚线 成交量|持仓量文字 坐标
 */
- (void)findVolOpiVerLinePointArray
{
    //成交量/持仓量 虚线数量
    int horVolLineCount = 5;
    
    //生成vol 单位高度
    double unitVolH = self.volHeight / horVolLineCount;
    
    //用于 vol - opi 计算价格，因为这两个数值计算规则是 horVolLineCount - 1，文华财经与逸富国际计算规则也是如此；
    double unitVolPrice = (self.maxVolValue - self.minVolValue) / (horVolLineCount);
    double unitOpiPrice = (self.maxOpiValue - self.minOpiValue) / (horVolLineCount);
    
    //求得最大成交价与持仓量的width/height
    CGRect volPriceRect = [NSString jk_rectOfNSString:[NSString stringWithFormat:@"%.0f", self.maxVolValue] attribute:self.attribute];
    volPriceRect.size.width += 3;
    
    CGRect opiPerRect   = [NSString jk_rectOfNSString:[NSString stringWithFormat:@"%.0f", self.maxOpiValue] attribute:self.attribute];
    opiPerRect.size.width += 3;
    
    self.horVolLineArray = [[NSMutableArray alloc] init];
    for (int i = 0; i <= horVolLineCount; i++) {
        
        LJChartLineModel *lineModel = [[LJChartLineModel alloc] init];
        
        CGPoint startPoint = CGPointMake(self.frameX, (self.frameY + self.frameH) + unitVolH * i);
        CGPoint endPoint   = CGPointMake(self.frameX + self.frameW, (self.frameY + self.frameH) + unitVolH * i);
        lineModel.lineStartPoint = startPoint;
        lineModel.lineEndPoint = endPoint;
        
        //为什么要加 unitVolH ，因为当前横线价格是显示在下一条线上的；
        float height = ((i * unitVolH) - volPriceRect.size.height + (self.frameY + self.frameH));
        
        CGRect leftRect = CGRectMake(2, height, volPriceRect.size.width, volPriceRect.size.height);
        CGRect rightRect = CGRectMake(self.frameW - opiPerRect.size.width - 2, height, opiPerRect.size.width, opiPerRect.size.height);
        lineModel.volRect = leftRect;
        lineModel.opiRect = rightRect;
        
        //计算成交量 和 持仓量
        double volPrice = self.maxVolValue - (i * unitVolPrice);
        double opiPrice = self.maxOpiValue - (i * unitOpiPrice);
        
        lineModel.vol = volPrice;
        lineModel.opi = opiPrice;
        lineModel.horFontColor = LJ_Red_Color;
        
        //设置第一根线 | 最后一根线 不显示
        if (i == 0 || i == horVolLineCount) {
            lineModel.lineStartPoint = lineModel.lineEndPoint = CGPointZero;
            lineModel.volRect = lineModel.opiRect = CGRectZero;
        }
        [self.horVolLineArray addObject:lineModel];
    }
}

/**
 绘制幅图横虚线 成交量|持仓量文字 坐标
 */
- (void)drawVolOpiRange:(CGContextRef)contextRef
{
    for (int idx = 0; idx < self.horVolLineArray.count; idx++)
    {
        @autoreleasepool {
            LJChartLineModel *lineModel = [self.horVolLineArray objectAtIndex:idx];
            
            if (lineModel.lineEndPoint.x > 0) {
                CGFloat lengths[] = {3,2};
                [LJCGContextUtil lj_addLineDash:contextRef lineWidth:0.2 lineColorRef:LJ_Red_Color_CG lengths:lengths movePoint:lineModel.lineStartPoint toPoint:lineModel.lineEndPoint];
                
            }
            //if (!lineModel.isIntersects) {
            if (lineModel.volRect.origin.x > 0 && lineModel.opiRect.origin.x > 0) {
                //计算价格和百分比
                NSString *leftStr = [NSString stringWithFormat:@"%.0f", lineModel.vol];
                NSString *rightStr = [NSString stringWithFormat:@"%.0f", lineModel.opi];
                
                [LJCGContextUtil lj_AddRectFont:contextRef text:leftStr font:LJ_FONTSYS(self.attfontSize) fontColor:LJ_Red_Color alignment:NSTextAlignmentLeft rect:lineModel.volRect];
                [LJCGContextUtil lj_AddRectFont:contextRef text:rightStr font:LJ_FONTSYS(self.attfontSize) fontColor:LJ_Red_Color alignment:NSTextAlignmentRight rect:lineModel.opiRect];
            }
        }
    }
}

/**
 幅图Y轴坐标值 转 价格
 
 @param y y
 */
- (NSString *)findTimeLayer_Y_Vol:(float)y
{
    double dotPrice = (self.maxVolValue - self.minVolValue) / self.volHeight;
    
    float value = self.maxVolValue - ((y - self.lineHeight - (self.timePointH/2)) * dotPrice);

    if (value > self.maxVolValue) {
        value = self.maxVolValue;
    }
    if (value < self.minVolValue) {
        value = self.minVolValue;
    }
    return [NSString jk_reviseString:value];
}


@end
