//
//  LJTimeChartView+BorderLayer.h
//  YiFu
//
//  Created by 伍孟华 on 2018/6/26.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "LJTimeChartView.h"

@interface LJTimeChartView (BorderLayer)

/**
 绘制边框
 */
- (void)drawBorderLayer:(CGContextRef)contextRef;

/**
 设置分页图表填充颜色
 */
- (void)drawPageFillColor:(CGContextRef)contextRef;

@end
