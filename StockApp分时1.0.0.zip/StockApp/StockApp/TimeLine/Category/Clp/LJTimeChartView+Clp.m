//
//  LJTimeChartView+Clp.m
//  YiFu
//
//  Created by 伍孟华 on 2018/6/26.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "LJTimeChartView+Clp.h"
#import "NSDate+JKUtilities.h"
#import "CATextLayer+textLayer.h"
#import "LJCGContextUtil.h"
#import "NSString+JKSize.h"
#import "NSString+Decimal.h"

@implementation LJTimeChartView (Clp)

/**
 计算主图竖线 位置+时间
 */
- (void)findClpAVGVerLinePointArray {
    
    CGRect strRect = [NSString jk_rectOfNSString:@"00:00" attribute:self.attribute];
    strRect.size.width = strRect.size.width + 1;
    
    self.verLineArray = [[NSMutableArray alloc] init];
    /*
     当pageIndex = 1 时才使用常规竖线，> 1 时需要根据 “timeChartTotalArray”的i索引 第0条数据位置绘制竖线，并设置时间
     */
    if (self.pageIndex == 1) {
        //计算起始时间 与 结束时间位置
        LJChartLineModel *startLineModel = [[LJChartLineModel alloc] init];
        CGRect fontRect = CGRectMake(0 ,CGRectGetHeight(self.frame) - strRect.size.height, strRect.size.width, strRect.size.height);
        startLineModel.dateChartRect = fontRect;
        startLineModel.isRealityLinel = NO;
        startLineModel.dateChar = ((LJTimeChartModel *)self.timeChartArr.firstObject).dateChar;
        startLineModel.dateChar = [NSDate jk_timeStringWithFormat:@"yyyy-MM-dd HH:mm" targetFormat:@"HH:mm" strValue:startLineModel.dateChar];
        [self.verLineArray addObject:startLineModel];
        
        if (self.firstTimeHmDictionary.count > 0) {
            NSArray *timesArray = [self.treatyTimes componentsSeparatedByString:@","];
            for (int i = 0; i < timesArray.count; i++) {
                if (i%2 == 0 && (i != 0 && i != timesArray.count-1)) {
                    
                    LJChartLineModel *lineModel = [[LJChartLineModel alloc] init];
                    
                    NSString *key = timesArray[i];
                    NSInteger index = [[self.firstTimeHmDictionary objectForKey:key] integerValue];
                    CGPoint startPoint = CGPointMake(index * self.dotWidth, self.frameY);
                    CGPoint endPoint   = CGPointMake(index * self.dotWidth, self.frameY + self.frameH + self.volHeight);
                    lineModel.lineStartPoint = startPoint;
                    lineModel.lineEndPoint = endPoint;
                    lineModel.isRealityLinel = NO;
                    
                    lineModel.dateChar = ((LJTimeChartModel *)[self.timeChartArr objectAtIndex:index]).dateChar;
                    lineModel.dateChar = [NSDate jk_timeStringWithFormat:@"yyyy-MM-dd HH:mm" targetFormat:@"HH:mm" strValue:lineModel.dateChar];
                    fontRect = CGRectMake((index * self.dotWidth) - strRect.size.width/2, fontRect.origin.y, strRect.size.width, strRect.size.height);
                    lineModel.dateChartRect = fontRect;
                    
                    [self.verLineArray addObject:lineModel];
                }
            }
        }else{
            //竖线值 | 坐标
            for (int i = 1; i <= self.verLineCount; i++)
            {
                LJChartLineModel *lineModel = [[LJChartLineModel alloc] init];
                
                CGPoint startPoint = CGPointMake(i * self.minute * self.dotWidth, self.frameY);
                CGPoint endPoint   = CGPointMake(i * self.minute * self.dotWidth, self.frameY + self.frameH + self.volHeight);
                lineModel.lineStartPoint = startPoint;
                lineModel.lineEndPoint = endPoint;
                lineModel.isRealityLinel = NO;
                
                lineModel.dateChar = ((LJTimeChartModel *)[self.timeChartArr objectAtIndex:(i * self.minute)]).dateChar;
                lineModel.dateChar = [NSDate jk_timeStringWithFormat:@"yyyy-MM-dd HH:mm" targetFormat:@"HH:mm" strValue:lineModel.dateChar];
                fontRect = CGRectMake((i * self.minute * self.dotWidth) - strRect.size.width/2, fontRect.origin.y, strRect.size.width, strRect.size.height);
                lineModel.dateChartRect = fontRect;
                
                [self.verLineArray addObject:lineModel];
            }
        }
        
        LJChartLineModel *endLineModel = [[LJChartLineModel alloc] init];
        fontRect = CGRectMake(self.frameW - strRect.size.width ,fontRect.origin.y, strRect.size.width, strRect.size.height);
        endLineModel.dateChartRect = fontRect;
        endLineModel.isRealityLinel = NO;
        endLineModel.dateChar = ((LJTimeChartModel *)self.timeChartArr.lastObject).dateChar;
        endLineModel.dateChar = [NSDate jk_timeStringWithFormat:@"yyyy-MM-dd HH:mm" targetFormat:@"HH:mm" strValue:endLineModel.dateChar];
        [self.verLineArray addObject:endLineModel];
        
    }else{
        //计算分页时竖线 + 时间 位置
        for (int i = 0; i < self.pageIndex; i++) {
            NSArray *idxArray = (NSArray *)[self.timeChartTotalArray objectAtIndex:i];
            if (idxArray && idxArray.count > 0)
            {
                LJTimeChartModel *chartModel = (LJTimeChartModel *)idxArray.firstObject;
                
                NSInteger idx = [self.timeChartArr indexOfObject:chartModel];
                CGFloat x = idx * self.dotWidth;
                
                LJChartLineModel *lineModel = [[LJChartLineModel alloc] init];
                CGPoint startPoint = CGPointMake(x, self.frameY);
                CGPoint endPoint   = CGPointMake(x, self.frameY + self.frameH + self.volHeight);
                lineModel.lineStartPoint = startPoint;
                lineModel.lineEndPoint = endPoint;
                lineModel.isRealityLinel = YES;
                
                lineModel.dateChar = chartModel.tradingDay;
                lineModel.dateChar = [NSDate jk_timeStringWithFormat:@"yyyyMMdd" targetFormat:@"MM/dd" strValue:lineModel.dateChar];
                CGRect fontRect = CGRectMake(x, CGRectGetHeight(self.frame) - strRect.size.height, strRect.size.width, strRect.size.height);
                lineModel.dateChartRect = fontRect;
                
                [self.verLineArray addObject:lineModel];
            }
        }
    }
    
    //判断坐标是否有重叠
    for (int i=1; i<self.verLineArray.count; i++) {
        
        LJChartLineModel *lineModel = [self.verLineArray objectAtIndex:i];
        LJChartLineModel *upLineModel = [self.verLineArray objectAtIndex:(i-1)];
        
        if (CGRectIntersectsRect(lineModel.dateChartRect, upLineModel.dateChartRect)) {
            
            //如果有重叠，判断是否为最后一个，如果是最后一个就需要将前一个隐藏
            if (i == self.verLineArray.count-1) {
                upLineModel.isIntersects = YES;
            }else{
                lineModel.isIntersects = YES;
            }
        }
    }
}

/**
 绘制主图竖线 位置+时间
 */
- (void)drawVerTimePointLayer:(CGContextRef)contextRef
{
    @autoreleasepool {
        for (int i = 0; i < self.verLineArray.count; i++)
        {
            LJChartLineModel *lineModel = [self.verLineArray objectAtIndex:i];
            if (!lineModel.isRealityLinel) {
                if (!lineModel.isIntersects) {
                    //虚线
                    CGFloat lengths[] = {3,2};
                    [LJCGContextUtil lj_addLineDash:contextRef lineWidth:0.2 lineColorRef:LJ_Red_Color_CG lengths:lengths movePoint:lineModel.lineStartPoint toPoint:lineModel.lineEndPoint];
                }
            }else{
                if (!lineModel.isIntersects) {
                    //实线
                    [LJCGContextUtil lj_AddLineToPoint:contextRef lineWidth:0.4 lineColorRef:LJ_Red_Color_CG movePoint:lineModel.lineStartPoint toPoint:lineModel.lineEndPoint];
                }
            }
            if (!lineModel.isIntersects) {
                [LJCGContextUtil lj_AddRectFont:contextRef text:lineModel.dateChar font:LJ_FONTSYS(self.attfontSize) fontColor:LJ_Red_Color alignment:NSTextAlignmentCenter rect:lineModel.dateChartRect];
            }
        }
    }
}

/**
 计算 ClpAVG 横线位置
 */
- (void)findClpAVGHorLinePointArray
{
    //===横线 价格 / 百分比 ========================================================================
    //生成 单位高度
    double unitPrice = (self.maxClpValue - self.minClpValue) / self.horLineCount;
    
    //@"%df",yaxis.decimal
    //求得价格和百分比的rect
    CGRect priceRect = [NSString jk_rectOfNSString:[NSString stringWithFormat:self.format, self.zrclp] attribute:self.attribute];
    priceRect.size.width += 3;
    CGRect perRect   = [NSString jk_rectOfNSString:@"-100.00%" attribute:self.attribute];
    perRect.size.width += 3;
    
    self.horLineArray = [[NSMutableArray alloc] init];
    for (int i = 0; i <= self.horLineCount; i++) {
        
        LJChartLineModel *lineModel = [[LJChartLineModel alloc] init];
        
        CGPoint startPoint = CGPointMake(self.frameX, self.frameY + self.unitH * i);
        CGPoint endPoint   = CGPointMake(self.frameX + self.frameW, self.frameY + self.unitH * i);
        lineModel.lineStartPoint = startPoint;
        lineModel.lineEndPoint = endPoint;
        
        //设置第一根线不显示
        if (i == 0) {
            lineModel.lineStartPoint = lineModel.lineEndPoint = CGPointZero;
        }
        //设置最后一根线为实线
        if (i == self.horLineCount) {
            lineModel.isRealityLinel = YES;
        }
        float height = i * self.unitH - priceRect.size.height + self.frameY;
        
        CGRect leftRect = CGRectMake(2, height, priceRect.size.width+2, priceRect.size.height);
        CGRect rightRect = CGRectMake(self.frameW - perRect.size.width - 2, height, perRect.size.width, perRect.size.height);
        lineModel.clpRect = leftRect;
        lineModel.percentageRect = rightRect;
        
        //计算价格和百分比
        double leftValue;
        double rightValue;
        UIColor *fontColor;
        double verPrice = self.maxClpValue - (i * unitPrice);
        if (i == 3) {
            //昨日收盘价，不做计算，直接设定
            leftValue = self.zrclp;
            rightValue = 0.00;
            fontColor = LJ_White_Color;
            lineModel.isRealityLinel = YES;
        }else if ((self.maxClpValue - i * unitPrice) > self.zrclp) {
            //当前横线价格大于均价
            leftValue = verPrice;
            rightValue = (verPrice - self.zrclp) / self.zrclp * 100;
            fontColor = LJ_Red_Color;
        }else{
            //当前横线价格小于均价
            leftValue = verPrice;
            rightValue = (verPrice - self.zrclp) / self.zrclp * 100;
            fontColor = LJ_Green_Color;
        }
        if (isnan(rightValue)) {
            rightValue = 0;
        }
        lineModel.clp = leftValue;
        lineModel.percentage = rightValue;
        lineModel.horFontColor = fontColor;
        
        [self.horLineArray addObject:lineModel];
    }
}


/**
 绘制 主图 横线位置 + 价格
 */
- (void)drawHorTimePointLayer:(CGContextRef)contextRef;
{
    for (int i = 0; i < self.horLineArray.count; i++)
    {
        @autoreleasepool {
            LJChartLineModel *lineModel = [self.horLineArray objectAtIndex:i];
            if (!lineModel.isRealityLinel) {
                //虚线
                CGFloat lengths[] = {3,2};
                [LJCGContextUtil lj_addLineDash:contextRef lineWidth:0.2 lineColorRef:LJ_Red_Color_CG lengths:lengths movePoint:lineModel.lineStartPoint toPoint:lineModel.lineEndPoint];
            }else{
                //实线
                [LJCGContextUtil lj_AddLineToPoint:contextRef lineWidth:0.4 lineColorRef:LJ_Red_Color_CG movePoint:lineModel.lineStartPoint toPoint:lineModel.lineEndPoint];
            }
            NSString *leftStr = [NSString stringWithFormat:self.format, lineModel.clp];
            NSString *rightStr = [NSString stringWithFormat:@"%.2f%%", lineModel.percentage];
            if (lineModel.percentage > 0) {
                rightStr = [NSString stringWithFormat:@"+%@",rightStr];
            }
            [LJCGContextUtil lj_AddRectFont:contextRef text:leftStr font:LJ_FONTSYS(self.attfontSize) fontColor:lineModel.horFontColor alignment:NSTextAlignmentLeft rect:lineModel.clpRect];
            [LJCGContextUtil lj_AddRectFont:contextRef text:rightStr font:LJ_FONTSYS(self.attfontSize) fontColor:lineModel.horFontColor alignment:NSTextAlignmentRight rect:lineModel.percentageRect];
        }
    }
}

/**
 计算分时图 收盘价、均价 成交量、持仓量 线的位置
 */
- (void)findClpAvpDrawLineArray
{
//    CFAbsoluteTime startTime =CFAbsoluteTimeGetCurrent();
    //+1 底部可留出空白
    CGFloat _volBottomY = self.viewHeight - self.timePointH/2;
    
    self.timeDrawChartArr = [[NSMutableArray alloc] init];
    self.volDrawCharArr = [[NSMutableArray alloc] init];
    
    NSMutableArray *drawArray = [[NSMutableArray alloc] init];
    for (int idx = 0; idx < self.timeChartArr.count; idx++) {
        @autoreleasepool {
            LJTimeChartModel *chartModel = [self.timeChartArr objectAtIndex:idx];
            
            CGFloat x = idx * self.dotWidth;
            //当前bar必须有收盘价，否则视为空数据，需要断线重绘
            if (chartModel.clp.length > 0)
            {
                //成交坐标点
                CGPoint linePoint = CGPointMake(x, (self.maxClpValue - [chartModel.clp doubleValue]) * self.dotHeight + self.timePointH/2 + self.lineRealityGapHeight/2);
                chartModel.linePoint = linePoint;
                
                //均线坐标点
                CGPoint avgPoint = CGPointMake(x, (self.maxClpValue - [chartModel.avp doubleValue]) * self.dotHeight + self.timePointH/2+ self.lineRealityGapHeight/2);
                chartModel.avgPoint = avgPoint;
                
                //成交量坐标点
                CGPoint startVolPoint = CGPointMake(x, _volBottomY);
                CGPoint endVolPoint = CGPointMake(x, _volBottomY - ([chartModel.vol doubleValue] - self.minVolValue) * self.dotVolHeight);
                chartModel.startVolPoint = startVolPoint;
                chartModel.endVolPoint = endVolPoint;
                
                //持仓量坐标点
                CGPoint opiPoint = CGPointMake(x, _volBottomY - ([chartModel.opi doubleValue] - self.minOpiValue) * self.dotOpiHeight);
                chartModel.opiPoint = opiPoint;
                
                [self.volDrawCharArr addObject:chartModel];
                [drawArray addObject:chartModel];
                //断点重绘
                if (chartModel.isOffLine || (idx == self.timeChartArr.count-1)) {
                    if (drawArray.count > 0) {
                        [self.timeDrawChartArr addObject:drawArray];
                    }
                    drawArray = [[NSMutableArray alloc] init];
                }
            }else{
                if (drawArray.count > 0) {
                    [self.timeDrawChartArr addObject:drawArray];
                }
                drawArray = [[NSMutableArray alloc] init];
            }
        }
    }
    
    for (NSInteger idx = self.timeChartArr.count-1; idx >= 0; idx--) {
        //计算最后一个有数据的bar
        @autoreleasepool {
            LJTimeChartModel *upChartModel = [self.timeChartArr objectAtIndex:idx];
            if ([upChartModel.clp length] == 0) {
                self.lastExistChattModel = upChartModel;
                break;
            }
        }
    }
//    CFAbsoluteTime linkTime = (CFAbsoluteTimeGetCurrent() - startTime);
//    NSLog(@"Linked in %f ms - 2", linkTime *1000.0);
}


/**
 绘制分时图 收盘价、均价 成交量、持仓量 线的位置
 */
- (void)drawClpTimeLinePointCG:(CGContextRef)contextRef
{
    //主图绘制
    for (int i = 0; i < self.timeDrawChartArr.count; i++) {
        @autoreleasepool {
            NSMutableArray *drawArray = [self.timeDrawChartArr objectAtIndex:i];
            //收盘价
            [LJCGContextUtil lj_AddLineToPoints:contextRef lineWidth:0.9 lineColorRef:LJ_White_Color_CG points:drawArray lineType:LJ_ENUM_CGContent_CLP];
            //均价线
            [LJCGContextUtil lj_AddLineToPoints:contextRef lineWidth:1.0 lineColorRef:LJ_Yellow_Color_CG points:drawArray lineType:LJ_ENUM_CGContent_AVG];
            //持仓量线
            [LJCGContextUtil lj_AddLineToPoints:contextRef lineWidth:0.7 lineColorRef:LJ_Yellow_Color_CG points:drawArray lineType:LJ_ENUM_CGContent_OPI];
        }
    }
    //成交量or持仓量 柱形图
    for (int i = 0; i < self.volDrawCharArr.count; i++) {
        @autoreleasepool {
            LJTimeChartModel *chartModel = [self.volDrawCharArr objectAtIndex:i];
            if (chartModel.clp >= chartModel.op) {
                [LJCGContextUtil lj_AddLineToPoint:contextRef lineWidth:0.5 lineColorRef:LJ_Red_Color_CG movePoint:chartModel.startVolPoint toPoint:chartModel.endVolPoint];
            }else{
                [LJCGContextUtil lj_AddLineToPoint:contextRef lineWidth:0.5 lineColorRef:LJ_Green_Color_CG movePoint:chartModel.startVolPoint toPoint:chartModel.endVolPoint];
            }
        }
    }
}

/**
 主图Y轴坐标值 转 价格

 @param y y
 */
- (NSString *)findTimeLayer_Y_Clp:(float)y
{
    double dotPrice = (self.maxClpValue - self.minClpValue) / self.lineHeightReality;
    
    float value = self.maxClpValue - ((y - self.timePointH/2 - self.lineRealityGapHeight/2) * dotPrice);
    
    if (value > self.maxClpValue) {
        value = self.maxClpValue;
    }
    if (value < self.minClpValue) {
        value = self.minClpValue;
    }
    return [NSString jk_reviseString:value];
}
//主图Y轴坐标值 转 价格，无max min限制，用于画线分析功能
- (NSString *)findTimeLayerAtWill_Y_Clp:(float)y
{
    double dotPrice = (self.maxClpValue - self.minClpValue) / self.lineHeightReality;
    float value = self.maxClpValue - ((y - self.timePointH/2 - self.lineRealityGapHeight/2) * dotPrice);
    return [NSString jk_reviseString:value];
}


/**
 主图价格 转 Y轴坐标

 @param price price
 @return Y轴坐标
 */
- (float)findTImeLayer_Price_Clp:(float)price
{
    float y = ((self.maxClpValue - price) * self.dotHeight) + self.timePointH/2 + self.lineRealityGapHeight/2;
    if (y < self.frameY) {
        y = self.frameY;
    }
    if (y > self.frameH) {
        y = self.frameH;
    }
    return y;
}
//主图价格 转 Y轴坐标，无max min限制，用于画线分析功能
- (float)findTImeLayerAtWill_Price_Clp:(float)price
{
    float y = ((self.maxClpValue - price) * self.dotHeight) + self.timePointH/2 + self.lineRealityGapHeight/2;
    return y;
}




@end
