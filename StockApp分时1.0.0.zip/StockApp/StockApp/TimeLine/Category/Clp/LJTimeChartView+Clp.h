//
//  LJTimeChartView+Clp.h
//  YiFu
//
//  Created by 伍孟华 on 2018/6/26.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "LJTimeChartView.h"

@interface LJTimeChartView (Clp)

//计算主图竖线 位置+时间
- (void)findClpAVGVerLinePointArray;
//绘制主图竖线 位置+时间
- (void)drawVerTimePointLayer:(CGContextRef)contextRef;

//计算主图横线 位置+价格
- (void)findClpAVGHorLinePointArray;
//绘制主图横线 位置+价格
- (void)drawHorTimePointLayer:(CGContextRef)contextRef;


//计算分时图 收盘价、均价 成交量、持仓量 线的位置
- (void)findClpAvpDrawLineArray;
//绘制分时图 收盘价、均价 成交量、持仓量 线的位置
- (void)drawClpTimeLinePointCG:(CGContextRef)contextRef;


//主图Y轴坐标值 转 价格
- (NSString *)findTimeLayer_Y_Clp:(float)y;
- (NSString *)findTimeLayerAtWill_Y_Clp:(float)y;

//主图价格 转 Y轴坐标
- (float)findTImeLayer_Price_Clp:(float)price;
- (float)findTImeLayerAtWill_Price_Clp:(float)price;

@end
