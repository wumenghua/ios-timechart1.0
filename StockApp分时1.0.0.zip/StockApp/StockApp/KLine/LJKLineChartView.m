//
//  LJKLineChartView.m
//  YiFu
//
//  Created by 伍孟华 on 2018/8/16.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "LJKLineChartView.h"
#import "LJKLineChartView+Basics.h"
#import "LJKLineChartView+BasicsLayer.h"
#import "NSMutableArray+KLineExpand.h"

#import "LJKLineChartView+Candle.h"
#import "LJKLineChartView+MA.h"
#import "LJKLineChartView+EMA.h"
#import "LJKLineChartView+BOLL.h"

#import "LJKLineChartView+MV.h"

#import "LJKLineChartView+MACD.h"
#import "LJKLineChartView+KDJ.h"
#import "LJKLineChartView+RSI.h"

#import "LJKLineLayerView.h"
#import "UIView+JKVisuals.h"

@interface LJKLineChartView()
{
}
//间隔单机时间
@property (nonatomic,assign) float eventInterval;
//间隔 滑动or 平移 时间
@property (nonatomic,assign) float eventPanPinInterval;
//上次单机时间
@property (nonatomic,assign) NSTimeInterval eventTime;

//最小滑动距离
@property (nonatomic,assign) float minSlideWidth;
//bar缩放界限
@property (nonatomic,assign) float barScaleBound;
//bar最小最大值
@property (nonatomic,assign) float barMinWidth;
@property (nonatomic,assign) float barMaxWidth;

//当前绘制数据最后一条数据，在所有K线数据中的索引
@property (nonatomic,assign) NSInteger rightKLineChartIndex;

//当前绘制数据最后一条数据，在所有K线数据中的索引
@property (nonatomic,assign) NSInteger rightBarIndex;

//绘制数据在基础数据最左端的索引
@property (nonatomic,assign) NSInteger leftIndex;
//绘制数据总条数据，也是在基础数据最右端的索引
@property (nonatomic,assign) NSInteger slideCount;

//最左端索引 、 数据总条数零时数据
@property (nonatomic,assign) NSInteger leftTempIndex;
@property (nonatomic,assign) NSInteger slideTempCount;

//是否显示十字架
@property (nonatomic,assign) BOOL isTicks;
//十字架位置
@property (nonatomic,assign) CGPoint ticksPoint;
@property (nonatomic,assign) CGPoint ticksPanPoint;
/**十字叉图层*/
@property (nonatomic, strong) CAShapeLayer *ticksLayer;
//左右浮层
@property (nonatomic,strong) LJKLineLayerView *layerView;

@property (nonatomic,assign) NSInteger executeCount;
@property (nonatomic,strong) dispatch_queue_t kLineQueue;

@end
@implementation LJKLineChartView

- (instancetype)init
{
    self = [super init];
    if (self) {
        
        //单机切换指标间隔时间
        self.eventInterval = 0.5;
        //间隔滑动时间
        self.eventPanPinInterval = 0.1;
        //蜡烛图间隙 百分比
        self.kLineInterval = 0.2;
        //bar间隙 百分比
        self.barInterval = 0.2;
        //默认横线格数量
        self.kLineHorCount = 5;
        self.kLineVerCount = 5;
        //是否允许分页
        self.isRightMovePage = YES;
        //下一页是否有数据
        self.isNextPage = YES;
        //是否更换屏幕显示规则
        self.isLandscapeUpdate = NO;
        //倒计时
        self.intervalCount = -1;
        //默认蜡烛宽度
        self.kLineWidth = 5;
        //bar最小最大宽度
        self.barMinWidth = 0.6;
        self.barMaxWidth = 20;
        //最小滑动距离
        self.minSlideWidth = 5;
        //bar缩放界限
        self.barScaleBound = 0.03;
        //小数位
        self.decimal = 2;
        self.format = [@"%." stringByAppendingFormat:@"%ldf",self.decimal];
        //画线字体大小
        self.attfontSize = 14.f;
        self.attribute = @{NSFontAttributeName:[UIFont systemFontOfSize:self.attfontSize]};
        // 串行队列的创建方法
        self.kLineQueue = dispatch_queue_create("yifu.kLineQueue", nil);
        
        //初始化手势
        [self longGesture];
        [self tapGesture];
        [self panGesture];
        [self pinchGesture];
    }
    return self;
}

- (void)initialize
{
    //初始化趋势、量仓、摆动指标
    [self setupQSLayer];
    [self setupLCLayer];
    [self setupBDLayer];
    if (!self.kLineLayoutArray) {
        self.drawRectArray = [[NSMutableArray alloc] init];
        self.kLineLayoutArray = [[NSMutableArray alloc] init];
        //绘制边框
        [self calculateBorder:self.drawRectArray tempLayoutArray:self.kLineLayoutArray];
        [self setNeedsDisplay];
    }
    self.format = [@"%." stringByAppendingFormat:@"%ldf",self.decimal];
    self.attribute = @{NSFontAttributeName:[UIFont systemFontOfSize:self.attfontSize]};
    
    //隐藏十字架
    [self hideTicks];
    
}

- (void)addKLineChartArray:(NSMutableArray *)chartArray
{
    if (chartArray.count == 0) {
        //无数据，不做处理，并将K线设置为无更多数据状态
        self.isRightMovePage = NO;
        self.isNextPage = NO;
    }else{
        if (!self.kLineChartArray) {
            self.kLineChartArray = [[NSMutableArray alloc] init];
        }
        //有数据，允许右滑分页
        self.isRightMovePage = YES;
        self.isNextPage = YES;
        //图形没有数据，需要开始绘制 | 后续分页只要图形没有数据都需要重新绘制
        [self.kLineChartArray insertObjects:chartArray atIndexes:[NSIndexSet indexSetWithIndexesInRange:NSMakeRange(0, chartArray.count)]];
        //清空最后一条数据指标
        [self emptyArrayLastKPI];
        //清空K线基础数据集合 - 时间所在的Index
        [self.indexChartDictionary removeAllObjects];
        //计算当前屏幕显示范围
        [self calculateDrawKLineArray];
        //计算需要绘制的基础数据 ,串型同步队列
        dispatch_sync(self.kLineQueue, ^{
            [self reloadView:self.drawChartArray];
        });
        //判断第一条数据是否为0 , 代表需要请求新数据
        [self kLineFirstIndexDataUpdate];
    }
}

- (void)reloadView:(NSMutableArray *)tempDrawChartArray
{
    int kLineCount = self.qsLayout.innerW / self.kLineWidth;
    if (kLineCount > self.drawRectArray.count) {
        //计算当前屏幕显示范围
        [self calculateDrawKLineArray];
    }
    //浮层小数位、浮层置顶
    self.layerView.decimal = self.decimal;
    
    //重新计算所选指标
    [self calculateKLineChartAllKPI];
    
    //计算所有时间在当前集合中的索引位置
    [self calculateKlineIndexDictionary];
    
    //计算指标KPI数据及高度、选中指标位置
    NSMutableArray *tempRectArray= [[NSMutableArray alloc] init];
    NSMutableArray *tempLayoutArray = [[NSMutableArray alloc] init];
    NSMutableArray *tempKPIDrawArray = [[NSMutableArray alloc] init];
    if (!tempDrawChartArray) {
        tempDrawChartArray = [NSMutableArray arrayWithArray:self.drawChartArray];
    }
    __weak typeof(self) weakself = self;
    [self calculateDrawKPIPoint:tempRectArray tempLayoutArray:tempLayoutArray tempDrawChartArray:tempDrawChartArray tempKPIDrawArray:(NSMutableArray *)tempKPIDrawArray block:^(NSMutableArray *retRectArray, NSMutableArray *retLayoutArray, NSMutableArray *retDrawChartArray, NSMutableArray *retKPIDrawArray) {
        
            weakself.drawRectArray = retRectArray;
            weakself.kLineLayoutArray = retLayoutArray;
            //绘制顶部文字 消耗 1%CPU
            [weakself drawKPILayout:retKPIDrawArray];
            [weakself bringSubviewToFront:weakself.layerView];
            //设置最右边箭头图标 超级消耗CPU
            [weakself drawRightArrowImageView:[weakself.kLineChartArray indexOfObject:retDrawChartArray.lastObject]];
            //如果十字架已显示，那么重绘时也需要将十字架重绘
            if (weakself.isTicks) {
                if ([retDrawChartArray containsObject:weakself.selectPointModel]) {
                    if (weakself.isLandscapeUpdate) {
                        weakself.isLandscapeUpdate = NO;
                        //更新Y轴位置
                        CGPoint point = CGPointMake(weakself.ticksPoint.x, weakself.qsLayout.innerY + weakself.selectPointModel.candleModel.pillarY );
                        weakself.ticksPoint = point;
                        NSInteger idx = [retDrawChartArray indexOfObject:weakself.selectPointModel];
                        [weakself getkLineIndexMoveTick:idx];
                        //更新浮层位置
                        [weakself.layerView updateLayerFrame];
                    }else{
                        if (CGPointEqualToPoint(weakself.ticksPanPoint,CGPointZero)) {
                            [weakself chartMovedDrawLine:weakself.ticksPoint status:UIGestureRecognizerStateChanged];
                        }else{
                            [weakself chartMovedDrawLine:weakself.ticksPanPoint status:UIGestureRecognizerStateChanged];
                        }
                    }
                }else{
                    [weakself getkLineIndexMoveTick:retDrawChartArray.count-1];
                }
            }
            weakself.executeCount++;
            //NSLog(@"executeCount: %ld",weakself.executeCount);
//            //绘制
            [weakself setNeedsDisplay];
    }];
}

//更新视图绘制
- (void)updateDraw
{
    //绘制数组的最后一条数据等于基础数组的最后一条数据，代表最后一条数据需要重绘
    if ([self.kLineChartArray indexOfObject:self.drawChartArray.lastObject] >= self.kLineChartArray.count - 2)
    {
        NSInteger finalLeftIndex = [self.kLineChartArray indexOfObject:self.drawChartArray.firstObject];;
        NSInteger finalSlideCount = self.drawChartArray.count;;
        
        int sumCount = self.qsLayout.innerW/self.kLineWidth;
        //计算滑动数量
        if (finalSlideCount < sumCount) {
            finalSlideCount = finalSlideCount + 1;
        }else{
            finalLeftIndex = finalLeftIndex + 1;
        }
        finalLeftIndex = finalLeftIndex < 0 ? 0 : finalLeftIndex;
        if ((finalLeftIndex + finalSlideCount) > self.kLineChartArray.count) {
            finalLeftIndex = self.kLineChartArray.count - finalSlideCount;
        }
        finalSlideCount = finalSlideCount > self.kLineChartArray.count ? self.kLineChartArray.count : finalSlideCount;
        finalLeftIndex = finalLeftIndex < 0 ? 0 : finalLeftIndex;
        
        NSMutableArray *tempDrawChartArray = [NSMutableArray arrayWithArray:[self.kLineChartArray subarrayWithRange:NSMakeRange(finalLeftIndex, finalSlideCount)]];
        self.drawChartArray = tempDrawChartArray;
        //计算需要绘制的基础数据 ,串型同步队列
        dispatch_sync(self.kLineQueue, ^{
            [self reloadView:tempDrawChartArray];
        });
    }
}
//主动清空数据
- (void)releaseView
{
    
    self.indexChartDictionary = self.drawChartDictionary = nil;
    self.kLineChartArray = self.drawChartArray = self.drawRectArray = self.kLineLayoutArray = self.kpiLayoutArray = nil;
    self.qsLayout = self.lcLayout = self.bdLayout = nil;
    self.qsKPIModel = self.lcKPIModel = self.bdKPIModel = nil;
}

//判断第一条数据是否为0,代表需要请求新数据
- (void)kLineFirstIndexDataUpdate
{
    //判断当前显示的第一条数据,如果为0代表全部显示完,判断是否需要添加新数据
    self.leftIndex = [self.kLineChartArray indexOfObject:self.drawChartArray.firstObject];
    self.slideCount = self.drawChartArray.count;
    
    if (self.leftIndex == 0) {
        //正常缩放，请求下一页数据
        if (self.isRightMovePage && self.isNextPage) {
            self.isRightMovePage = NO;
            if (self.delegate && [self.delegate respondsToSelector:@selector(lj_kLineRightMovePage)]) {
                [self.delegate lj_kLineRightMovePage];
            }
        }
    }
}
//计算基础数据
- (void)calculateKLineChartAllKPI
{
    //当前选择趋势指标
    if (self.qsLayout.kpiArray.count > 0 && self.qsKPIIndex < self.qsLayout.kpiArray.count) {
        self.qsKPIModel = [self.qsLayout.kpiArray objectAtIndex:self.qsKPIIndex];
    }else{
        if (self.qsLayout.kpiArray.count > 0) {
            self.qsKPIModel = [self.qsLayout.kpiArray objectAtIndex:0];
        }
    }
    if (self.qsKPIModel && self.qsLayout.layerScale > 0) {
        [self.qsKPIModel calculateKLineKPIModel:self.kLineChartArray];
    }
    
    //当前选择量仓指标
    if (self.lcLayout.kpiArray.count > 0 && self.lcKPIIndex < self.lcLayout.kpiArray.count) {
        self.lcKPIModel = [self.lcLayout.kpiArray objectAtIndex:self.lcKPIIndex];
    }else{
        if (self.lcLayout.kpiArray.count > 0) {
            self.lcKPIModel = [self.lcLayout.kpiArray objectAtIndex:0];
        }
    }
    if (self.lcKPIModel && self.lcLayout.layerScale > 0) {
        [self.lcKPIModel calculateKLineKPIModel:self.kLineChartArray];
    }
    
    //当前选择摆动指标
    if (self.bdLayout.kpiArray.count > 0 && self.bdKPIIndex < self.bdLayout.kpiArray.count) {
        self.bdKPIModel = [self.bdLayout.kpiArray objectAtIndex:self.bdKPIIndex];
    }else{
        if (self.bdLayout.kpiArray.count > 0) {
            self.bdKPIModel = [self.bdLayout.kpiArray objectAtIndex:0];
        }
    }
    if (self.bdKPIModel && self.bdLayout.layerScale > 0) {
        [self.bdKPIModel calculateKLineKPIModel:self.kLineChartArray];
    }
}

//计算所有时间在当前集合中的索引位置
- (void)calculateKlineIndexDictionary
{
    //集合已存在,并且集合整体数量并没有发生改变,无需计算
    if (self.indexChartDictionary && self.indexChartDictionary.count == self.kLineChartArray.count) {
        return;
    }
    [self.indexChartDictionary removeAllObjects];
    self.indexChartDictionary = [[NSMutableDictionary alloc] init];
    for (NSInteger i = self.indexChartDictionary.count; i < self.kLineChartArray.count; i++) {
        LJKLineModel *model = [self.kLineChartArray objectAtIndex:i];
        [self.indexChartDictionary setObject:@(i).stringValue forKey:model.dateChar];
    }
}

/**
 计算当前屏幕可显示数据量
 */
- (void)calculateDrawKLineArray
{
    NSInteger kLineCount = self.qsLayout.innerW / self.kLineWidth;
    
    if (kLineCount > self.kLineChartArray.count) {
        self.drawChartArray = [NSMutableArray arrayWithArray:self.kLineChartArray];
    }else{
        if (!self.drawChartArray || self.drawChartArray.count == 0) {
            NSInteger loc = self.kLineChartArray.count - kLineCount;
            self.drawChartArray = [NSMutableArray arrayWithArray:[self.kLineChartArray subarrayWithRange:NSMakeRange(loc, kLineCount)]];
        }else{
            NSInteger lastIndex = [self.kLineChartArray indexOfObject:self.drawChartArray.lastObject]+1;
            lastIndex = lastIndex - kLineCount;
            if (lastIndex < 0) {
                lastIndex = 0;
            }
            if (kLineCount > self.kLineChartArray.count) {
                kLineCount = self.kLineChartArray.count-1;
            }
            //NSLog(@"-------------------------%ld----------------------%ld------------------------",lastIndex,kLineCount);
            self.drawChartArray = [NSMutableArray arrayWithArray:[self.kLineChartArray subarrayWithRange:NSMakeRange(lastIndex, kLineCount)]];
        }
    }
    //得到绘制数据最左边索引 、 最右边索引
    self.leftIndex = [self.kLineChartArray indexOfObject:self.drawChartArray.firstObject];
    self.slideCount = self.drawChartArray.count;
}

- (void)calculateDrawKPIPoint:(NSMutableArray *)tempRectArray tempLayoutArray:(NSMutableArray *)tempLayoutArray tempDrawChartArray:(NSMutableArray *)tempDrawChartArray tempKPIDrawArray:(NSMutableArray *)tempKPIDrawArray block:(void(^)(NSMutableArray *retRectArray ,NSMutableArray *retLayoutArray ,NSMutableArray *retDrawChartArray ,NSMutableArray *retKPIDrawArray))block;
{
    if (self.qsKPIModel && self.qsLayout.layerScale > 0)
    {
        if ([self.qsKPIModel isKindOfClass:[LJKLineCandleKPIModel class]])
        {
            [self setupQSLayerHeight:0];
            [self calculateLJKLineCandleKPIModelPoint:tempRectArray tempLayoutArray:tempLayoutArray tempDrawChartArray:tempDrawChartArray];
        }else if ([self.qsKPIModel isKindOfClass:[LJKLineMAKPIModel class]])
        {
            float kpiHeight = [self calculateMATopKPIHeight:tempDrawChartArray.lastObject isDraw:YES tempKPIDrawArray:tempKPIDrawArray];
            [self setupQSLayerHeight:kpiHeight];
            
            [self calculateLJKLineMAKPIModelPoint:tempRectArray tempLayoutArray:tempLayoutArray tempDrawChartArray:tempDrawChartArray];
        }else if ([self.qsKPIModel isKindOfClass:[LJKLineEMAKPIModel class]])
        {
            float kpiHeight = [self calculateEMATopKPIHeight:tempDrawChartArray.lastObject isDraw:YES tempKPIDrawArray:tempKPIDrawArray];
            [self setupQSLayerHeight:kpiHeight];
            
            [self calculateLJKLineEMAKPIModelPoint:tempRectArray tempLayoutArray:tempLayoutArray tempDrawChartArray:tempDrawChartArray];
        }else if ([self.qsKPIModel isKindOfClass:[LJKLineBOLLKPIModel class]])
        {
            float kpiHeight = [self calculateBOLLTopKPIHeight:tempDrawChartArray.lastObject isDraw:YES tempKPIDrawArray:tempKPIDrawArray];
            [self setupQSLayerHeight:kpiHeight];
            
            [self calculateLJKLineBOLLKPIModelPoint:tempRectArray tempLayoutArray:tempLayoutArray tempDrawChartArray:tempDrawChartArray];
        }
        if (self.delegate && [self.delegate respondsToSelector:@selector(lj_kLineUpdateKPIHeight)]) {
            [self.delegate lj_kLineUpdateKPIHeight];
        }
    }
    
    if (self.lcKPIModel && self.lcLayout.layerScale > 0)
    {
        if ([self.lcKPIModel isKindOfClass:[LJKLineMVKPIModel class]])
        {
            float kpiHeight = [self calculateMVTopKPIHeight:tempDrawChartArray.lastObject isDraw:YES tempKPIDrawArray:tempKPIDrawArray];
            [self setupLCLayerHeight:kpiHeight];
            
            [self calculateLJKLineMVKPIModelPoint:tempRectArray tempLayoutArray:tempLayoutArray tempDrawChartArray:tempDrawChartArray];
        }
    }
    
    if (self.bdKPIModel && self.bdLayout.layerScale > 0)
    {
        if ([self.bdKPIModel isKindOfClass:[LJKLineMACDKPIModel class]])
        {
            float kpiHeight = [self calculateMACDTopKPIHeight:tempDrawChartArray.lastObject isDraw:YES tempKPIDrawArray:tempKPIDrawArray];
            [self setupBDLayerHeight:kpiHeight];
            
            [self calculateLJKLineMACDKPIModelPoint:tempRectArray tempLayoutArray:tempLayoutArray tempDrawChartArray:tempDrawChartArray];
        }else if ([self.bdKPIModel isKindOfClass:[LJKLineKDJKPIModel class]])
        {
            float kpiHeight = [self calculateKDJTopKPIHeight:tempDrawChartArray.lastObject isDraw:YES tempKPIDrawArray:tempKPIDrawArray];
            [self setupBDLayerHeight:kpiHeight];
            
            [self calculateLJKLineKDJKPIModelPoint:tempRectArray tempLayoutArray:tempLayoutArray tempDrawChartArray:tempDrawChartArray];
        }else if ([self.bdKPIModel isKindOfClass:[LJKLineRSIKPIModel class]])
        {
            float kpiHeight = [self calculateRSITopKPIHeight:tempDrawChartArray.lastObject isDraw:YES tempKPIDrawArray:tempKPIDrawArray];
            [self setupBDLayerHeight:kpiHeight];
            
            [self calculateLJKLineRSIKPIModelPoint:tempRectArray tempLayoutArray:tempLayoutArray tempDrawChartArray:tempDrawChartArray];
        }
    }
    //边框
    [self calculateBorder:tempRectArray tempLayoutArray:tempLayoutArray];
    
    if (block) {
        block(tempRectArray,tempLayoutArray,tempDrawChartArray,tempKPIDrawArray);
    }
}

//清空最后一条数据KPI
- (void)emptyArrayLastKPI
{
    LJKLineModel *klineModel = self.kLineChartArray.lastObject;
    klineModel.qsModel = [[LJKLineBaseModel alloc] init];
    klineModel.lcModel = [[LJKLineBaseModel alloc] init];
    klineModel.bdModel = [[LJKLineBaseModel alloc] init];
}

#pragma -mark 单击手势
- (void)kLineTapGestureAction:(UITapGestureRecognizer *)tapGesture
{
    if (self.isTicks)
    {
        self.isTicks = NO;
        //根据索引重新绘制KPI顶部的值
        [self drawUpdateAllKPI:self.drawChartArray.count-1 tempRectArray:nil tempLayoutArray:nil tempDrawChartArray:self.drawChartArray tempKPIDrawArray:nil];
        //清空十字架Layer
        [self clearTicks];
        //关闭浮层
        [self.layerView hideLayer];
        //十字架移动结束
        if (self.delegate && [self.delegate respondsToSelector:@selector(lj_kLineTicksEnd)]) {
            [self.delegate lj_kLineTicksEnd];
        }
    }else
    {
        BOOL needSendAction = (NSDate.date.timeIntervalSince1970 - self.eventTime >= self.eventInterval);
        if (needSendAction) {
            // 更新上一次点击时间戳
            if (self.eventInterval > 0) {
                self.eventTime = NSDate.date.timeIntervalSince1970;
            }
//            //画线分析
//            if (self.isLineAnalysisStatus) {
//                [self kLineLineAnalysisTapGestureAction:tapGesture];
//            }else{
//                
//            }
            //获取坐标
            CGPoint point = [tapGesture locationInView:self];
            //判断点击范围
            if (CGRectContainsPoint(CGRectMake(self.qsLayout.x, self.qsLayout.y, self.qsLayout.w, self.qsLayout.h), point)) {
                self.qsKPIIndex = [self.qsLayout.kpiArray lj_nextArrayIndex:self.qsKPIIndex];
                [self setQsKPIIndex:self.qsKPIIndex];
            }else if (CGRectContainsPoint(CGRectMake(self.lcLayout.x, self.lcLayout.y, self.lcLayout.w, self.lcLayout.h), point))
            {
                self.lcKPIIndex = [self.lcLayout.kpiArray lj_nextArrayIndex:self.lcKPIIndex];
                [self setLcKPIIndex:self.lcKPIIndex];
            }else if (CGRectContainsPoint(CGRectMake(self.bdLayout.x, self.bdLayout.y, self.bdLayout.w, self.bdLayout.h), point))
            {
                self.bdKPIIndex = [self.bdLayout.kpiArray lj_nextArrayIndex:self.bdKPIIndex];
                [self setBdKPIIndex:self.bdKPIIndex];
            }
            //计算需要绘制的基础数据 ,串型同步队列
            dispatch_sync(self.kLineQueue, ^{
                [self reloadView:self.drawChartArray];
            });
        }else{
            return;
        }
    }
}

#pragma -mark 平移手势
- (void)kLinePanGestureAction:(UIPanGestureRecognizer *)panGesture
{
    CGPoint point1 = [panGesture translationInView:panGesture.view];
    
    if (_isTicks) {
        float x = self.ticksPoint.x + point1.x;
        float y = self.ticksPoint.y + point1.y;
        
        //平移方式x轴持续增大，左滑时无法立即索引到右侧最后索引
        if (x > self.drawChartArray.count * self.kLineWidth){
            x = self.drawChartArray.count * self.kLineWidth;
        }
        self.ticksPanPoint = CGPointMake(x, y);
        [self chartMovedDrawLine:CGPointMake(x, y) status:UIGestureRecognizerStateChanged];
        
        if (panGesture.state == UIGestureRecognizerStateEnded || panGesture.state == UIGestureRecognizerStateCancelled || panGesture.state == UIGestureRecognizerStateFailed) {
            [self chartMovedDrawLine:CGPointMake(x, y) status:UIGestureRecognizerStateEnded];
            self.ticksPanPoint = CGPointZero;
        }
    }else {
        if (self.kLineWidth > 1) self.eventPanPinInterval = 0.05;
        else self.eventPanPinInterval = 0.15;
        //NSLog(@"kLineWidth : %f",self.kLineWidth);
        
        BOOL needSendAction = (NSDate.date.timeIntervalSince1970 - self.eventTime >= self.eventPanPinInterval);
        if (needSendAction) {
            // 更新上一次点击时间戳
            if (self.eventInterval > 0) {
                self.eventTime = NSDate.date.timeIntervalSince1970;
            }
            NSInteger finalLeftIndex = 0;
            NSInteger finalSlideCount = 0;
            if (panGesture.state == UIGestureRecognizerStateBegan) {
                self.leftTempIndex = self.leftIndex;
                self.slideTempCount = self.slideCount;
            }
            if (panGesture.state == UIGestureRecognizerStateChanged && self.kLineChartArray.count > 0) {
                CGPoint velocity = [panGesture velocityInView:_panGesture.view];
                
                if (self.kLineWidth > 2) self.minSlideWidth = 2;
                else self.minSlideWidth = 5;
                #pragma -mark  (abs((int)velocity.x) < _minSlideWidth)  该判断条件需要修改,计算不科学  20180601
                if (abs((int)velocity.x) < _minSlideWidth) {
                    return;
                }
                finalLeftIndex = self.leftTempIndex;
                finalSlideCount = self.slideTempCount;
                //滑动需要移动的count
                NSInteger slideCount = fabs(point1.x)/self.kLineWidth;
                if (point1.x > 0) {
                    //右滑动
                    finalLeftIndex = self.leftTempIndex - slideCount;
                }else{
                    int sumCount = self.qsLayout.innerW/self.kLineWidth;
                    //计算滑动数量
                    if (self.slideTempCount < sumCount) {
                        finalSlideCount = self.slideTempCount + slideCount;
                    }else{
                        finalLeftIndex = self.leftTempIndex + slideCount;
                    }
                }
                finalLeftIndex = finalLeftIndex < 0 ? 0 : finalLeftIndex;
                if ((finalLeftIndex + finalSlideCount) > self.kLineChartArray.count) {
                    finalLeftIndex = self.kLineChartArray.count - finalSlideCount;
                }
                finalSlideCount = finalSlideCount > self.kLineChartArray.count ? self.kLineChartArray.count : finalSlideCount;
                finalLeftIndex = finalLeftIndex < 0 ? 0 : finalLeftIndex;
                if (finalLeftIndex == 0) {
                    //正常右滑，请求下一页数据
                    if (self.isRightMovePage && self.isNextPage) {
                        self.isRightMovePage = NO;
                        if (self.delegate && [self.delegate respondsToSelector:@selector(lj_kLineRightMovePage)])
                        {
                            [self.delegate lj_kLineRightMovePage];
                        }
                    }
                }
                NSMutableArray *tempDrawChartArray = [NSMutableArray arrayWithArray:[self.kLineChartArray subarrayWithRange:NSMakeRange(finalLeftIndex, finalSlideCount)]];
                self.drawChartArray = tempDrawChartArray;
                //计算需要绘制的基础数据 ,串型同步队列
                dispatch_sync(self.kLineQueue, ^{
                    [self reloadView:tempDrawChartArray];
                });
            }
            if ((panGesture.state == UIGestureRecognizerStateEnded || panGesture.state == UIGestureRecognizerStateCancelled || panGesture.state == UIGestureRecognizerStateFailed) && self.kLineChartArray.count > 0) {
                self.leftIndex = [self.kLineChartArray indexOfObject:self.drawChartArray.firstObject];
                self.slideCount = self.drawChartArray.count;
                //暂无更多数据
                if (self.leftIndex == 0 && !self.isNextPage && self.delegate && [self.delegate respondsToSelector:@selector(lj_kLineNotMoreData)])
                {
                    [self.delegate lj_kLineNotMoreData];
                }
            }
        }
    }
}

#pragma -mark 长按手势
- (void)kLineChartLongGestureAction:(UILongPressGestureRecognizer *)longGesture
{
    if (longGesture.state == UIGestureRecognizerStateBegan || longGesture.state == UIGestureRecognizerStateChanged)
    {
        CGPoint point = [longGesture locationInView:self];
        
        self.isTicks = YES;
        self.ticksPoint = point;
        
        int sumCount = self.qsLayout.innerW/self.kLineWidth;
        if (sumCount >= self.drawChartArray.count)
        {
            //当前长按位置非K线位置
            NSInteger index = floor(point.x / _kLineWidth);
            if (index < sumCount-self.drawChartArray.count) {
                [self getkLineIndexMoveTick:0];
                self.ticksPoint = CGPointMake(0, self.ticksPoint.y);
                
            }else{
                index = index - (sumCount - self.drawChartArray.count);
                self.ticksPoint = CGPointMake(self.kLineWidth * index, self.ticksPoint.y);
                [self chartMovedDrawLine:self.ticksPoint status:UIGestureRecognizerStateChanged];
            }
        }
    }
}

#pragma -mark 缩放手势
- (void)kLinePinchGestureAction:(UIPinchGestureRecognizer *)pinchGesture
{
    static CGFloat oldScale = 1.0f;
    if(pinchGesture.numberOfTouches == 2 ) {
        if (self.kLineWidth > 1) self.eventPanPinInterval = 0.05;
        else self.eventPanPinInterval = 0.1;
        //NSLog(@"kLineWidth : %f",self.kLineWidth);
        BOOL needSendAction = (NSDate.date.timeIntervalSince1970 - self.eventTime >= self.eventPanPinInterval);
        if (needSendAction) {
            // 更新上一次点击时间戳
            if (self.eventInterval > 0) {
                self.eventTime = NSDate.date.timeIntervalSince1970;
            }
            if (pinchGesture.state == UIGestureRecognizerStateBegan)
            {
                self.rightKLineChartIndex = [self.kLineChartArray indexOfObject:self.drawChartArray.lastObject] + 1;
                oldScale = pinchGesture.scale;
            }
            if (pinchGesture.state == UIGestureRecognizerStateChanged && self.kLineChartArray.count > 0)
            {
                CGFloat difValue = pinchGesture.scale - oldScale;
                
                if(ABS(difValue) > self.barScaleBound)
                {
                    self.kLineWidth = self.kLineWidth * ((difValue > 0) ? (1 + 0.1):(1 - 0.1));
                    oldScale = pinchGesture.scale;
                    
                    if (self.kLineWidth < self.barMinWidth){
                        self.kLineWidth = self.barMinWidth;
                    }else if (self.kLineWidth > self.barMaxWidth){
                        self.kLineWidth = self.barMaxWidth;
                    }
                    //屏幕最新可显示 蜡烛图 数量
                    int kLineCount = self.qsLayout.innerW / self.kLineWidth;
                    NSInteger loc;
                    if(kLineCount > self.rightKLineChartIndex){
                        loc = 0;
                    }else{
                        loc = self.rightKLineChartIndex - kLineCount;
                    }
                    NSMutableArray *tempDrawChartArray = [NSMutableArray arrayWithArray:[self.kLineChartArray subarrayWithRange:NSMakeRange(loc, _rightKLineChartIndex-loc)]];
                    self.drawChartArray = tempDrawChartArray;
                    //得到绘制数据最左边索引 、 最右边索引
                    self.leftIndex = [self.kLineChartArray indexOfObject:self.drawChartArray.firstObject];
                    self.slideCount = self.drawChartArray.count;
                    //计算需要绘制的基础数据 ,串型同步队列
                    dispatch_sync(self.kLineQueue, ^{
                        [self reloadView:tempDrawChartArray];
                    });
                }
            }
        }
        if ((pinchGesture.state ==UIGestureRecognizerStateEnded) || pinchGesture.state ==UIGestureRecognizerStateCancelled || pinchGesture.state == UIGestureRecognizerStateFailed)
        {
            self.leftIndex = [self.kLineChartArray indexOfObject:self.drawChartArray.firstObject];
            self.slideCount = self.drawChartArray.count;
            
            if (self.kLineWidth <= self.barMinWidth) {
                if (self.delegate && [self.delegate respondsToSelector:@selector(lj_kLineZoomMin)]) {
                    [self.delegate lj_kLineZoomMin];
                }
            }
            
            if (self.leftIndex == 0) {
                //正常缩放，请求下一页数据
                if (self.isRightMovePage && self.isNextPage) {
                    self.isRightMovePage = NO;
                    if (self.delegate && [self.delegate respondsToSelector:@selector(lj_kLineRightMovePage)]) {
                        [self.delegate lj_kLineRightMovePage];
                    }
                }
            }
        }
    }
}

#pragma -mark 十字架处理
- (void)chartMovedDrawLine:(CGPoint)point status:(UIGestureRecognizerState)status
{
    point.x = point.x < 0 ? 0 : point.x;
    point.x = point.x > self.qsLayout.innerW ? self.qsLayout.innerW : point.x;
    
    point.y = point.y < self.qsLayout.innerY ? self.qsLayout.innerY : point.y;
    point.y = point.y > self.qsLayout.layoutHeight-self.qsLayout.layoutBottonHeight ? self.qsLayout.layoutHeight-self.qsLayout.layoutBottonHeight : point.y;
    
    NSInteger index = floor(point.x / self.kLineWidth);
    if (index >= self.drawChartArray.count){
        index = self.drawChartArray.count - 1;
    }
    index = index < 0 ? 0 : index;
    
    [self chartMoveDrawLineIndex:index point:point];
    
    if (status == UIGestureRecognizerStateChanged) {
        if (self.delegate && [self.delegate respondsToSelector:@selector(lj_kLineTicksMove:idx:x:y:)]) {
            [self.delegate lj_kLineTicksMove:[self.drawChartArray objectAtIndex:index] idx:index x:point.x y:point.y];
        }
    }
    
    if (status == UIGestureRecognizerStateEnded || status == UIGestureRecognizerStateCancelled || status == UIGestureRecognizerStateFailed)
    {
        self.ticksPoint = point;
    }
}

- (void)chartMoveDrawLineIndex:(NSInteger)index point:(CGPoint)point
{
    self.selectPointModel = [self.drawChartArray objectAtIndex:index];
    self.selectIdx = index;
    //
    [self drawUpdateAllKPI:index tempRectArray:nil tempLayoutArray:nil tempDrawChartArray:self.drawChartArray tempKPIDrawArray:nil];
    //清空十字架Layer
    [self clearTicks];
    self.ticksLayer = [CAShapeLayer layer];
    
    UIBezierPath *path = [UIBezierPath bezierPath];
    //竖线
    [path moveToPoint:CGPointMake(self.selectPointModel.candleModel.candleX , self.qsLayout.innerY-self.qsLayout.topSpace)];
    [path addLineToPoint:CGPointMake(self.selectPointModel.candleModel.candleX,  self.qsLayout.innerY + self.selectPointModel.candleModel.upY - 2)];
    
    [path moveToPoint:CGPointMake(self.selectPointModel.candleModel.candleX , self.qsLayout.innerY + self.selectPointModel.candleModel.downY + self.selectPointModel.candleModel.downHeight + 2)];
    [path addLineToPoint:CGPointMake(self.selectPointModel.candleModel.candleX, self.qsLayout.layoutHeight-self.qsLayout.layoutBottonHeight)];
    //横线
    if (point.y >  + self.qsLayout.innerY + self.selectPointModel.candleModel.upY && point.y <  self.qsLayout.innerY + self.selectPointModel.candleModel.downY + self.selectPointModel.candleModel.downHeight) {
        //中间需要切段
        [path moveToPoint:CGPointMake(0, point.y)];
        [path addLineToPoint:CGPointMake(self.selectPointModel.candleModel.candleX-(self.kLineWidth/1.3), point.y)];
        
        [path moveToPoint:CGPointMake(self.selectPointModel.candleModel.candleX+(self.kLineWidth/1.5), point.y)];
        [path addLineToPoint:CGPointMake(self.qsLayout.w, point.y)];
    }else{
        [path moveToPoint:CGPointMake(0, point.y)];
        [path addLineToPoint:CGPointMake(self.qsLayout.w, point.y)];
    }
    //设置横竖线的属性
    self.ticksLayer.path = path.CGPath;
    self.ticksLayer.lineWidth = 0.8f;
    self.ticksLayer.strokeColor = [UIColor whiteColor].CGColor;
    self.ticksLayer.fillColor = [UIColor clearColor].CGColor;
    //再添加到分时图view的图层中
    [self.layer addSublayer:self.ticksLayer];
    //置顶浮层
    [self bringSubviewToFront:self.layerView];
    //浮层数据计算
    if (CGRectContainsPoint(CGRectMake(self.qsLayout.x, self.qsLayout.y, self.qsLayout.w, self.qsLayout.h), point)) {
        self.layerView.timeY = [self calculateKLine_QSKPI:point.y];
    }else if (CGRectContainsPoint(CGRectMake(self.lcLayout.x, self.lcLayout.y, self.lcLayout.w, self.lcLayout.h), point)) {
        self.layerView.timeY = [self calculateKLine_LCKPI:point.y];
    }else if (CGRectContainsPoint(CGRectMake(self.bdLayout.x, self.bdLayout.y, self.bdLayout.w, self.bdLayout.h), point)) {
        self.layerView.timeY = [self calculateKLine_BDKPI:point.y];
    }
    
    //浮层对象
    LJKLineModel *upkLineModel = self.selectPointModel;
    if (index != 0) {
        upkLineModel = [self.drawChartArray objectAtIndex:index-1];
    }else{
        //如果绘图数组上一条无数据时，就从总绘图数组中取出数据
        NSInteger kLineIndex = [self.kLineChartArray indexOfObject:self.drawChartArray.firstObject];
        if (index != 0) {
            upkLineModel = [self.kLineChartArray objectAtIndex:kLineIndex-1];
        }
    }
    //显示浮层
    self.layerView.top = self.qsLayout.innerY-self.qsLayout.topSpace;
    [self.layerView showLayer:CGPointMake(self.selectPointModel.candleModel.candleX, self.selectPointModel.candleModel.upY) kLineModel:self.selectPointModel upkLineModel:upkLineModel];
}

-(void)clearTicks {
    //清理十字叉图层
    [self.ticksLayer removeFromSuperlayer];
    self.ticksLayer.sublayers = nil;
}

//隐藏十字架
- (void)hideTicks {
    self.isTicks = NO;
    //清空十字架Layer
    [self clearTicks];
    //关闭浮层
    [self.layerView hideLayer];
}
/**
 根据索引获取model，并移动十字架
 */
-(LJKLineModel *)getkLineIndexMoveTick:(NSInteger)index
{
    if (index < 0 || index > self.drawChartArray.count-1){
        return nil;
    }
    if (self.isTicks)
    {
        [self chartMoveDrawLineIndex:index point:self.ticksPoint];
    }
    LJKLineModel *chartModel = [self.drawChartArray objectAtIndex:index];
    self.ticksPoint = CGPointMake(chartModel.candleModel.candleX - (self.kLineWidth/2), self.ticksPoint.y);
    
    return chartModel;
}

- (void)setIntervalCount:(NSInteger)intervalCount
{
    _intervalCount = intervalCount;
    if (intervalCount <= 0) {
        _intervalCount = 1;
    }
    [self updateIntervalCount];
}

- (void)setDecimal:(NSInteger)decimal
{
    _decimal = decimal;
    self.format = [@"%." stringByAppendingFormat:@"%ldf",_decimal];
}

#pragma -mark ----手势事件----
- (UILongPressGestureRecognizer *)longGesture {
    if (!_longGesture) {
        _longGesture = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(kLineChartLongGestureAction:)];
        _longGesture.minimumPressDuration = 0.3f;
        _longGesture.numberOfTouchesRequired = 1;
        [self addGestureRecognizer:_longGesture];
    }
    return _longGesture;
}

-(UITapGestureRecognizer *)tapGesture {
    if (!_tapGesture) {
        _tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(kLineTapGestureAction:)];
        [self addGestureRecognizer:_tapGesture];
    }
    return _tapGesture;
}

-(UIPanGestureRecognizer *)panGesture {
    if (!_panGesture) {
        _panGesture = [[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(kLinePanGestureAction:)];
        [self addGestureRecognizer:_panGesture];
    }
    return _panGesture;
}

-(UIPinchGestureRecognizer *)pinchGesture {
    if (!_pinchGesture) {
        _pinchGesture = [[UIPinchGestureRecognizer alloc]initWithTarget:self action:@selector(kLinePinchGestureAction:)];
        [self addGestureRecognizer:_pinchGesture];
    }
    return _pinchGesture;
}

- (LJKLineLayerView *)layerView {
    if (!_layerView) {
        _layerView = [[LJKLineLayerView alloc] init];
        _layerView.frame = CGRectMake(0, self.qsLayout.y, 95, 272);
        [_layerView jk_cornerRadius:0 strokeSize:0.7 color:[UIColor whiteColor]];
        [self addSubview:_layerView];
    }
    return _layerView;
}

- (UILabel *)intervalLabel
{
    if (!_intervalLabel) {
        _intervalLabel = [[UILabel alloc] init];
        _intervalLabel.font = [UIFont systemFontOfSize:(13)];
        _intervalLabel.textAlignment = NSTextAlignmentCenter;
        _intervalLabel.textColor = [UIColor whiteColor];
        _intervalLabel.backgroundColor = [[UIColor redColor] colorWithAlphaComponent:0.5f];
        [self addSubview:_intervalLabel];
    }
    return _intervalLabel;
}

- (void)drawRect:(CGRect)rect
{
    [super drawRect:rect];
    
    //CFAbsoluteTime startTime =CFAbsoluteTimeGetCurrent();
    [self draw];
    //CFAbsoluteTime linkTime = (CFAbsoluteTimeGetCurrent() - startTime);
    //NSLog(@"drawRect-----Linked in %f ms", linkTime * 1000.0);
}
@end
