//
//  LJKLineLayerView.m
//  YiFu
//
//  Created by 伍孟华 on 2018/6/29.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "LJKLineLayerView.h"
#import "NSDate+JKUtilities.h"
#import "NSString+Decimal.h"
#import "NSString+JKColor.h"
#import "UIViewAdditions.h"
#import "UIColor+JKHEX.h"

@interface LJKLineLayerView()

//浮层 左/右 控制  YES:不在 NO:在，用户控制动画
@property (nonatomic,assign) BOOL leftDirection;
@property (nonatomic,assign) BOOL rightDirection;

//浮层所在位置，用于K线横竖屏切换时位置错误
@property (nonatomic,assign) BOOL isLeftDir;
@property (nonatomic,assign) BOOL isRightDir;

//父层
@property (nonatomic,strong) UIView *superView;

//日期
@property (weak, nonatomic) IBOutlet UILabel *timeYLab;
@property (weak, nonatomic) IBOutlet UILabel *dateLab;

//开盘
@property (weak, nonatomic) IBOutlet UILabel *opLab;

//最高
@property (weak, nonatomic) IBOutlet UILabel *hipLab;

//最低
@property (weak, nonatomic) IBOutlet UILabel *lopLab;

//收盘
@property (weak, nonatomic) IBOutlet UILabel *clpLab;
@property (weak, nonatomic) IBOutlet UILabel *clp2Lab;
@property (weak, nonatomic) IBOutlet UILabel *clpPerLab;

//成交量
@property (weak, nonatomic) IBOutlet UILabel *vol1Lab;
@property (weak, nonatomic) IBOutlet UILabel *vol2Lab;

//持仓量
//@property (weak, nonatomic) IBOutlet UILabel *opi1Lab;
//@property (weak, nonatomic) IBOutlet UILabel *opi2Lab;



//@property (nonatomic,strong) NSMutableArray *kLinePeriodArray;

@end


@implementation LJKLineLayerView

- (instancetype)init
{
    self = [super init];
    if (self) {
        self = [[[NSBundle mainBundle] loadNibNamed:NSStringFromClass(self.class) owner:self options:nil] lastObject];
    }
    self.backgroundColor = [UIColor blackColor];
    
    [self setupUI];
    
    return self;
}

- (void)setupUI
{
    self.hidden = YES;
    self.dateLab.adjustsFontSizeToFitWidth = YES;
    self.dateLab.baselineAdjustment = UIBaselineAdjustmentNone;
    
    self.leftDirection = NO;
    self.rightDirection = NO;
    
    
    self.timeYLab.adjustsFontSizeToFitWidth = YES;
    self.dateLab.adjustsFontSizeToFitWidth = YES;
    
    self.opLab.adjustsFontSizeToFitWidth = YES;
    self.hipLab.adjustsFontSizeToFitWidth = YES;
    
    self.lopLab.adjustsFontSizeToFitWidth = YES;
    
    self.clpLab.adjustsFontSizeToFitWidth = YES;
    self.clp2Lab.adjustsFontSizeToFitWidth = YES;
    self.clpPerLab.adjustsFontSizeToFitWidth = YES;
}

- (void)showLayer:(CGPoint)point kLineModel:(LJKLineModel *)kLineModel upkLineModel:(LJKLineModel *)upkLineModel
{
    self.superView = self.superview;
    //LJRZLogRect(self.superView.frame);
    if (self.hidden) {
        
        if (point.x > (self.superView.width - self.width)) {
            //左边显示
            self.left = -self.width;
            [UIView animateWithDuration:0.25 delay:0 options:UIViewAnimationOptionCurveLinear animations:^{
                self.left = 0;
            } completion:^(BOOL finished) {
                self.leftDirection = NO;
                self.isLeftDir = YES;
            }];
        }else{
            //右边显示
            self.left = self.superView.width;
            [UIView animateWithDuration:0.25 delay:0 options:UIViewAnimationOptionCurveLinear animations:^{
                self.left = self.superView.width - self.width;
            } completion:^(BOOL finished) {
                self.rightDirection = NO;
                self.isRightDir = YES;
            }];
        }
    }
    
    self.hidden = NO;
    //    LJRZLogRect(self.frame);
    if (point.x < self.width) {
        //右边出来
        if (self.left != (self.superView.width-self.width) && !self.rightDirection) {
            self.rightDirection = YES;
            self.isRightDir = YES;
            
            //切换
            if (self.left == 0) {
                //先左隐藏，再右显示
                [UIView animateWithDuration:0.25 delay:0 options:UIViewAnimationOptionCurveLinear animations:^{
                    self.left = -self.width;
                } completion:^(BOOL finished) {
                    self.left = self.superView.width;
                    [UIView animateWithDuration:0.25 delay:0 options:UIViewAnimationOptionCurveLinear animations:^{
                        self.left = self.superView.width - self.width;
                    } completion:^(BOOL finished) {
                        self.rightDirection = NO;
                    }];
                }];
            }else{
                self.left = self.superView.width;
                [UIView animateWithDuration:0.25 delay:0 options:UIViewAnimationOptionCurveLinear animations:^{
                    self.left = self.superView.width - self.width;
                } completion:^(BOOL finished) {
                    self.rightDirection = NO;
                }];
            }
        }
        
    }else if (point.x > (self.superView.width - self.width)) {
        //左边出来
        if (self.left != 0 && !self.leftDirection) {
            self.leftDirection = YES;
            self.isLeftDir = YES;
            
            //切换
            if (self.left == (self.superView.width-self.width)) {
                //先右隐藏，再左显示
                [UIView animateWithDuration:0.25 delay:0 options:UIViewAnimationOptionCurveLinear animations:^{
                    self.left = self.superView.width;
                } completion:^(BOOL finished) {
                    self.left = -self.width;
                    [UIView animateWithDuration:0.25 delay:0 options:UIViewAnimationOptionCurveLinear animations:^{
                        self.left = 0;
                    } completion:^(BOOL finished) {
                        self.leftDirection = NO;
                    }];
                }];
            }else{
                self.left = -self.width;
                [UIView animateWithDuration:0.25 delay:0 options:UIViewAnimationOptionCurveLinear animations:^{
                    self.left = 0;
                } completion:^(BOOL finished) {
                    self.leftDirection = NO;
                }];
            }
        }
    }
    
    //设置数据
    [self setupLayerData:kLineModel upChartModel:upkLineModel];
}

- (void)hideLayer
{
    self.superView = self.superview;
    if (self.left == 0) {
        //左隐藏
        [UIView animateWithDuration:0.25 delay:0 options:UIViewAnimationOptionCurveEaseIn animations:^{
            self.left = -self.width;
        } completion:^(BOOL finished) {
            self.hidden = YES;
        }];
    }else {
        //右隐藏
        [UIView animateWithDuration:0.25 delay:0 options:UIViewAnimationOptionCurveEaseIn animations:^{
            self.left = self.superView.width;
        } completion:^(BOOL finished) {
            self.hidden = YES;
        }];
    }
//    [self.kLinePeriodArray removeAllObjects];
//    self.kLinePeriodArray = nil;
}
//更新图层位置
- (void)updateLayerFrame
{
    if (!self.hidden) {
        if (self.isLeftDir) {
            //原来在左边显示
            self.left = 0;
        }
        if (self.isRightDir) {
            //原来在右边显示
            self.left = self.superView.width - self.width;
        }
    }
}

- (void)setIsLeftDir:(BOOL)isLeftDir {
    _isLeftDir = isLeftDir;
    _isRightDir = !isLeftDir;
}

- (void)setIsRightDir:(BOOL)isRightDir {
    _isRightDir = isRightDir;
    _isLeftDir = !isRightDir;
}

- (void)setupLayerData:(LJKLineModel *)chartModel upChartModel:(LJKLineModel *)upChartModel
{
    self.timeYLab.text = [NSString jk_formatDecFloat:self.timeY.floatValue decimal:self.decimal];
    
//    if (!self.kLinePeriodArray || self.kLinePeriodArray.count == 0) {
//        self.kLinePeriodArray = (NSMutableArray *)[LJSettingManager kLinePeriodList];
//    }
//    LJKLinePeriodModel *periodModel = [self.kLinePeriodArray objectAtIndex:self.periodIndex];
//    NSString *dateChart = chartModel.dateChar;
    NSString *layerYMD = @"MM/dd HH:mm:ss";///[LJSettingManager getKLinePeriodIndexLayerYMD];
    self.dateLab.text = [NSDate jk_timeStringWithFormat:@"yyyy-MM-dd HH:mm:ss" targetFormat:layerYMD strValue:chartModel.dateChar];
    self.timeYLab.textColor = self.dateLab.textColor = [UIColor jk_colorWithHexString:@"#f3f94c"];
    
    //开盘
    self.opLab.text = [NSString jk_formatDecFloat:chartModel.op.floatValue decimal:self.decimal];
    //最高
    self.hipLab.text = [NSString jk_formatDecFloat:chartModel.hip.floatValue decimal:self.decimal];
    //最低
    self.lopLab.text = [NSString jk_formatDecFloat:chartModel.lop.floatValue decimal:self.decimal];
    
    //收盘
    self.clpLab.text = [NSString jk_formatDecFloat:chartModel.clp.floatValue decimal:self.decimal];
    self.clp2Lab.text = [NSString jk_formatDecFloat:(chartModel.clp.floatValue - upChartModel.clp.floatValue) decimal:self.decimal];
    self.clpPerLab.text = [[NSString jk_formatDecFloat:(chartModel.clp.floatValue - upChartModel.clp.floatValue)/upChartModel.vol.floatValue decimal:self.decimal] stringByAppendingString:@"%"];
    if (chartModel.clp.floatValue < chartModel.op.floatValue) {
        self.opLab.textColor = self.hipLab.textColor = self.lopLab.textColor = self.clpLab.textColor = self.clp2Lab.textColor = self.clpPerLab.textColor = [UIColor jk_colorWithHexString:@"#05c444"];
    }else{
        self.opLab.textColor = self.hipLab.textColor = self.lopLab.textColor = self.clpLab.textColor = self.clp2Lab.textColor = self.clpPerLab.textColor = [UIColor jk_colorWithHexString:@"#ce2327"];
    }
    
    //成交量
    self.vol1Lab.text = [NSString jk_formatDecFloat:chartModel.vol.floatValue decimal:0];
    self.vol2Lab.text = [NSString jk_formatDecFloat:(chartModel.vol.floatValue - upChartModel.vol.floatValue) decimal:0];
    
    //持仓量
//    self.opi1Lab.text = [NSString jk_formatDecFloat:chartModel.opi.floatValue decimal:self.decimal];
//    self.opi1Lab.text = [NSString jk_formatDecFloat:(chartModel.opi.floatValue - upChartModel.opi.floatValue) decimal:self.decimal];
}
@end
