//
//  LJKLineLayerView.h
//  YiFu
//
//  Created by 伍孟华 on 2018/6/29.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LJKLineModel.h"

@interface LJKLineLayerView : UIView

//K线周期索引
@property (nonatomic,assign) NSInteger periodIndex;

//合约小数位
@property (assign ,nonatomic) NSInteger decimal;

//分时图画线Y轴值
@property (nonatomic,strong) NSString *timeY;

//显示浮层
- (void)showLayer:(CGPoint)point kLineModel:(LJKLineModel *)kLineModel upkLineModel:(LJKLineModel *)upkLineModel;

//关闭浮层
- (void)hideLayer;

//更新图层位置
- (void)updateLayerFrame;

@end
