//
//  LJKLineContextUtil.h
//  YiFu
//
//  Created by 伍孟华 on 2018/8/20.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreGraphics/CGGeometry.h>
#import <CoreGraphics/CoreGraphics.h>
#import <UIKit/UIKit.h>

@interface LJKLineContextUtil : NSObject

//绘制虚线
+(void)lj_addLineDash:(float)lineWidth lineColorRef:(CGColorRef)lineColorRef lengths:(CGFloat[])lengths length:(NSInteger)length movePoint:(CGPoint)movePoint toPoint:(CGPoint)toPoint;

//绘制直线
+(void)lj_AddLineToPoint:(float)lineWidth lineColorRef:(CGColorRef)lineColorRef movePoint:(CGPoint)movePoint toPoint:(CGPoint)toPoint;

//绘制多条件->折线 第一种方式
+(void)lj_AddLineToPointsOff:(float)lineWidth lineColorRef:(CGColorRef)lineColorRef movePoints:(NSArray*)movePoints;

//绘制多条件->折线 第二种方式
+(void)lj_AddLineToPoints:(float)lineWidth lineColorRef:(CGColorRef)lineColorRef movePoints:(NSArray *)movePoints;

//绘制蜡烛图
+(void)lj_AddRect:(float)lineWidth fillColorRef:(CGColorRef)fillColorRef strokeColorRef:(CGColorRef)strokeColorRef rect:(CGRect)rect alpha:(CGFloat)alpha;
//绘制蜡烛图列表
+(void)lj_AddRects:(float)lineWidth fillColorRef:(CGColorRef)fillColorRef strokeColorRef:(CGColorRef)strokeColorRef rects:(NSArray *)rects;

//绘制文字
+(void)lj_AddText:(NSString *)text font:(UIFont *)font fontColor:(UIColor *)fontColor alignment:(NSTextAlignment)alignment rect:(CGRect)rect;

//添加圆
+(void)lj_AddCircle:(CGColorRef)fillColorRef circlePoint:(CGPoint)circlePoint radius:(float)radius;
//添加外围透明圆
+(void)lj_AddCircleOutskirts:(CGColorRef)fillColorRef circlePoint:(CGPoint)circlePoint radius:(float)radius;
//绘制圆-外层圆,无填充,只有线
+(void)lj_AddCircleOutskirtsLine:(CGColorRef)lineColorRef circlePoint:(CGPoint)circlePoint radius:(float)radius lineWidth:(float)lineWidth;

//绘制不规则方形
+(void)lj_AddIrregularSquare:(CGColorRef)fillColorRef movePoint:(CGPoint)movePoint toPoint:(CGPoint)toPoint tdMovePoint:(CGPoint)tdMovePoint tdToPoint:(CGPoint)tdToPoint;




@end
