//
//  LJKLineContextUtil.m
//  YiFu
//
//  Created by 伍孟华 on 2018/8/20.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "LJKLineContextUtil.h"
#import "LJDrawPointModel.h"
#import "LJDrawRectModel.h"

@implementation LJKLineContextUtil

//绘制虚线
+(void)lj_addLineDash:(float)lineWidth lineColorRef:(CGColorRef)lineColorRef lengths:(CGFloat[])lengths length:(NSInteger)length movePoint:(CGPoint)movePoint toPoint:(CGPoint)toPoint
{
    CGContextRef contextRef = UIGraphicsGetCurrentContext();
    CGContextSetLineWidth(contextRef, lineWidth);//线条宽度
    CGContextSetStrokeColorWithColor(contextRef, lineColorRef);
    CGContextSetLineDash(contextRef, 0, lengths, length);//画虚线,可参考
    CGContextSetLineJoin(contextRef, kCGLineJoinRound);//线条结尾处绘制一个直径为线条宽度的半圆。
    CGContextSetLineCap(contextRef , kCGLineCapRound);// 稍微圆角
    CGContextMoveToPoint(contextRef, movePoint.x, movePoint.y);//开始画线, x，y 为开始点的坐标
    CGContextAddLineToPoint(contextRef, toPoint.x, toPoint.y);//画直线, x，y 为线条结束点的坐标
    CGContextStrokePath(contextRef);//开始画线
}

//绘制直线
+(void)lj_AddLineToPoint:(float)lineWidth lineColorRef:(CGColorRef)lineColorRef movePoint:(CGPoint)movePoint toPoint:(CGPoint)toPoint
{
    CGContextRef contextRef = UIGraphicsGetCurrentContext();
    CGContextSetStrokeColorWithColor(contextRef, lineColorRef);//线条颜色
    CGContextSetLineWidth(contextRef, lineWidth);//线条宽度
    CGContextSetLineDash(contextRef, 0, 0, 0);//不需要虚线
    CGContextSetLineJoin(contextRef, kCGLineJoinMiter);//线条结尾处绘制一个直径为线条宽度的半圆。
    CGContextSetLineCap(contextRef , kCGLineCapRound);// 稍微圆角
    CGContextSetAlpha(contextRef, 1);//透明度
    CGContextMoveToPoint(contextRef, movePoint.x, movePoint.y); //开始画线, x，y 为开始点的坐标
    CGContextAddLineToPoint(contextRef, toPoint.x, toPoint.y);//画直线, x，y 为线条结束点的坐标
    CGContextStrokePath(contextRef); //开始画线
}

//绘制多条件->折线 第一种方式
+(void)lj_AddLineToPointsOff:(float)lineWidth lineColorRef:(CGColorRef)lineColorRef movePoints:(NSArray*)movePoints
{
    CGContextRef contextRef = UIGraphicsGetCurrentContext();
    CGContextSetStrokeColorWithColor(contextRef, lineColorRef);//线条颜色
    CGContextSetLineWidth(contextRef, lineWidth);//线条宽度
    CGContextSetLineDash(contextRef, 0, 0, 0);//不需要虚线
    CGContextSetLineJoin(contextRef, kCGLineJoinRound);//线条结尾处绘制一个直径为线条宽度的半圆。
    CGContextSetLineCap(contextRef , kCGLineCapRound);// 稍微圆角
    if (movePoints && movePoints.count > 0) {
        for (int i = 0; i < movePoints.count; i++) {
            LJDrawPointModel *model = movePoints[i];
            if (!isnan(model.movePoint.x) && !isnan(model.movePoint.y)) {
                CGContextMoveToPoint(contextRef, model.movePoint.x, model.movePoint.y); //开始画线, x，y 为开始点的坐标
                CGContextAddLineToPoint(contextRef, model.toPoint.x, model.toPoint.y);//画直线, x，y 为线条结束点的坐标
            }
        }
    }
    CGContextStrokePath(contextRef); //开始画线
}

//绘制多条件->折线 第二种方式
+(void)lj_AddLineToPoints:(float)lineWidth lineColorRef:(CGColorRef)lineColorRef movePoints:(NSArray *)movePoints
{
    CGContextRef contextRef = UIGraphicsGetCurrentContext();
    CGContextSetStrokeColorWithColor(contextRef, lineColorRef);//线条颜色
    CGContextSetLineWidth(contextRef, lineWidth);//线条宽度
    CGContextSetLineDash(contextRef, 0, 0, 0);//不需要虚线
    CGContextSetLineJoin(contextRef, kCGLineJoinRound);//线条结尾处绘制一个直径为线条宽度的半圆。
    CGContextSetLineCap(contextRef , kCGLineCapRound);// 稍微圆角
    CGPoint addLines[movePoints.count==1 ? 1+movePoints.count : movePoints.count];
    
    for (int i = 0; i < movePoints.count; i++) {
        LJDrawPointModel *model = movePoints[i];
        addLines[i] = model.movePoint;
    }
    if (movePoints.count == 1) {
        LJDrawPointModel *model = movePoints[0];
        addLines[1] = model.toPoint;
    }
    CGContextAddLines(contextRef, addLines, sizeof(addLines)/sizeof(addLines[0]));
    CGContextStrokePath(contextRef); //开始画线
}

//绘制蜡烛图
+(void)lj_AddRect:(float)lineWidth fillColorRef:(CGColorRef)fillColorRef strokeColorRef:(CGColorRef)strokeColorRef rect:(CGRect)rect alpha:(CGFloat)alpha
{
    //矩形，并填充颜色
    CGContextRef contextRef = UIGraphicsGetCurrentContext();
    CGContextSetLineWidth(contextRef, lineWidth);//线的宽度
    CGContextSetLineDash(contextRef, 0, 0, 0);//不需要虚线
    CGContextSetFillColorWithColor(contextRef, fillColorRef);//填充颜色
    CGContextSetAlpha(contextRef, alpha);
    CGContextSetStrokeColorWithColor(contextRef, strokeColorRef);//线框颜色
    CGContextAddRect(contextRef,rect);//画方框
    CGContextDrawPath(contextRef, kCGPathFillStroke);//绘画路径
}

+(void)lj_AddRects:(float)lineWidth fillColorRef:(CGColorRef)fillColorRef strokeColorRef:(CGColorRef)strokeColorRef rects:(NSArray *)rects
{
    //矩形，并填充颜色
    CGContextRef contextRef = UIGraphicsGetCurrentContext();
    CGContextSetLineWidth(contextRef, lineWidth);//线的宽度
    CGContextSetFillColorWithColor(contextRef, fillColorRef);//填充颜色
    CGContextSetStrokeColorWithColor(contextRef, strokeColorRef);//线框颜色
    CGRect addRects[rects.count];
    for (int i = 0; i < rects.count; i++) {
        LJDrawRectModel *rectModel = [rects objectAtIndex:i];
        addRects[i] = rectModel.rect;
    }
    CGContextAddRects(contextRef, addRects, sizeof(addRects)/sizeof(addRects[0]));
    CGContextDrawPath(contextRef, kCGPathFillStroke);//绘画路径
}

+(void)lj_AddText:(NSString *)text font:(UIFont *)font fontColor:(UIColor *)fontColor alignment:(NSTextAlignment)alignment rect:(CGRect)rect
{
    
    CGContextRef contextRef = UIGraphicsGetCurrentContext();
    CGContextSetAlpha(contextRef, 1);//透明度
    //文本风格，设置居中
    NSMutableParagraphStyle *paragraphStyle = [[NSParagraphStyle defaultParagraphStyle] mutableCopy];
    [paragraphStyle setAlignment:alignment];
    //打印文本
    NSDictionary* dic = @{NSFontAttributeName:font,NSParagraphStyleAttributeName:paragraphStyle,NSForegroundColorAttributeName:fontColor,NSBackgroundColorAttributeName : [UIColor clearColor]};
    [text drawInRect:rect withAttributes:dic];
}

//绘制圆
+(void)lj_AddCircle:(CGColorRef)fillColorRef circlePoint:(CGPoint)circlePoint radius:(float)radius
{
    CGContextRef contextRef = UIGraphicsGetCurrentContext();
    CGContextSetLineWidth(contextRef, 0);//线的宽度
    CGContextAddArc(contextRef, circlePoint.x, circlePoint.y, radius, 0, 2*M_PI, 0); //添加一个圆
    CGContextSetFillColorWithColor(contextRef, fillColorRef);//填充颜色
    CGContextSetAlpha(contextRef, 1);//透明度
    CGContextDrawPath(contextRef, kCGPathFill);//绘制填充
    CGContextDrawPath(contextRef, kCGPathStroke); //绘制路径
}

//绘制圆-外层圆
+(void)lj_AddCircleOutskirts:(CGColorRef)fillColorRef circlePoint:(CGPoint)circlePoint radius:(float)radius
{
    CGContextRef contextRef = UIGraphicsGetCurrentContext();
    CGContextSetLineWidth(contextRef, 0);//线的宽度
    CGContextAddArc(contextRef, circlePoint.x, circlePoint.y, radius, 0, 2*M_PI, 0); //添加一个圆
    CGContextSetFillColorWithColor(contextRef, fillColorRef);//填充颜色
    CGContextSetAlpha(contextRef, 0.5);//透明度
    CGContextDrawPath(contextRef, kCGPathFill);//绘制填充
    CGContextDrawPath(contextRef, kCGPathStroke); //绘制路径
}

//绘制圆-外层圆,无填充,只有线
+(void)lj_AddCircleOutskirtsLine:(CGColorRef)lineColorRef circlePoint:(CGPoint)circlePoint radius:(float)radius lineWidth:(float)lineWidth
{
    CGContextRef contextRef = UIGraphicsGetCurrentContext();
    CGContextSetLineWidth(contextRef, lineWidth);//线的宽度
    CGContextAddArc(contextRef, circlePoint.x, circlePoint.y, radius, 0, 2*M_PI, 0); //添加一个圆
    CGContextSetFillColorWithColor(contextRef, [UIColor clearColor].CGColor);//填充颜色
    CGContextSetStrokeColorWithColor(contextRef, lineColorRef);//线框颜色
    CGContextSetAlpha(contextRef, 1);//透明度
    CGContextDrawPath(contextRef, kCGPathStroke); //绘制路径
}


//绘制不规则方形
+(void)lj_AddIrregularSquare:(CGColorRef)fillColorRef movePoint:(CGPoint)movePoint toPoint:(CGPoint)toPoint tdMovePoint:(CGPoint)tdMovePoint tdToPoint:(CGPoint)tdToPoint
{
    CGContextRef contextRef = UIGraphicsGetCurrentContext();
    CGContextSetLineWidth(contextRef, 0);//线的宽度
    CGMutablePathRef path = CGPathCreateMutable();
    CGPathMoveToPoint(path, nil, movePoint.x, movePoint.y);
    CGPathAddLineToPoint(path, nil, toPoint.x, toPoint.y);
    CGPathAddLineToPoint(path, nil, tdToPoint.x, tdToPoint.y);
    CGPathAddLineToPoint(path, nil, tdMovePoint.x, tdMovePoint.y);
    CGPathAddLineToPoint(path, nil, movePoint.x, movePoint.y);
    CGContextAddPath(contextRef, path);
    CGContextSetFillColorWithColor(contextRef, fillColorRef);//填充颜色
    CGContextSetAlpha(contextRef, 0.1);//透明度
    CGContextDrawPath(contextRef, kCGPathFill);//绘制填充
    CGContextDrawPath(contextRef, kCGPathStroke); //绘制路径
}

@end
