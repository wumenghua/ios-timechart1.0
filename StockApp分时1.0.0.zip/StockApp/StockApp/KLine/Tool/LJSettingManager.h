//
//  LJSettingManager.h
//  StockApp
//
//  Created by 伍孟华 on 2018/11/5.
//  Copyright © 2018 分时K线. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LJKLineKPITreeModel.h"
#import "LJKLineKPITreeStairModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface LJSettingManager : NSObject

#pragma mark - KLine指标
+(NSMutableArray <LJKLineKPITreeModel *>*)getKLineKPITreeList;


@end

NS_ASSUME_NONNULL_END
