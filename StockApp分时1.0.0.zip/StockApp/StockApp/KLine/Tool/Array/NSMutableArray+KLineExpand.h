//
//  NSMutableArray+KLineExpand.h
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/6/1.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import <Foundation/Foundation.h>

#define LJ_Left_Index @"lj_left_index"
#define LJ_Right_Index @"lj_right_index"

@interface NSMutableArray (KLineExpand)


/**
 返回当前索引的下一个索引

 @param index 当前索引
 @return 下一个索引
 */
- (NSInteger)lj_nextArrayIndex:(NSInteger)index;

@end
