//
//  NSMutableArray+KLineExpand.m
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/6/1.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "NSMutableArray+KLineExpand.h"

@implementation NSMutableArray (KLineExpand)

/**
 返回当前索引的下一个索引
 
 @param index 当前索引
 @return 下一个索引
 */
- (NSInteger)lj_nextArrayIndex:(NSInteger)index {
    
    if (index < self.count-1) {
        return ++index;
    }else{
        return 0;
    }
}





@end
