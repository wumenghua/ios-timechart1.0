//
//  NSMutableArray+MaxMin.m
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/5/31.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "NSMutableArray+MaxMin.h"
#import "LJKLineModel.h"
#import "NSString+Decimal.h"

#import "LJKLineMAModel.h"
#import "LJKLineEMAModel.h"
#import "LJKLineBOLLModel.h"

#import "LJKLineMVModel.h"

#import "LJKLineMACDModel.h"
#import "LJKLineKDJModel.h"
#import "LJKLineRSIModel.h"

@implementation NSMutableArray (MaxMin)

/**
 计算普通K线(蜡烛图)最高价 、最低价
 
 @return NSDictionary
 */
- (NSDictionary *)calculateCandleMaxMin
{
    __block float kpiMax = 0.0f;
    __block float kpiMin = 0.0f;
    __block BOOL isAssign = NO;
    
    for (int i = 0; i < self.count; i++) {
        LJKLineModel *model = self[i];
        if (model.hip.length > 0 || model.lop.length > 0) {
            if (!isAssign) {
                isAssign = YES;
                kpiMax = [model.hip floatValue];
                kpiMin = kpiMax;
            }
            if ([model.hip floatValue] > kpiMax) {
                kpiMax = [model.hip floatValue];
            }
            if ([model.lop floatValue] < kpiMin) {
                kpiMin = [model.lop floatValue];
            }
        }
    }
    return [NSDictionary dictionaryWithObjectsAndKeys:[NSString jk_reviseString:kpiMax],LJ_KPI_Max,[NSString jk_reviseString:kpiMin],LJ_KPI_Min,[NSString jk_reviseString:kpiMax],LJ_Max_Hip,[NSString jk_reviseString:kpiMin],LJ_Min_Lop, nil];
}


/**
 计算MA 最高价 、最低价
 
 @return NSDictionary
 */
- (NSDictionary *)calculateMAMaxMin
{
    float kpiMax = 0.0f;
    float kpiMin = 0.0f;
    
    float maxHip = 0.0f;
    float minLop = 0.0f;
    
    
    if (self.count > 0) {
        kpiMax = [((LJKLineModel *)[self objectAtIndex:0]).hip floatValue];
        kpiMin = kpiMax;
        
        maxHip = kpiMax;
        minLop = kpiMax;
    }
    for (int i = 0; i < self.count; i++) {
        LJKLineModel *model = self[i];
        LJKLineMAModel *maModel = (LJKLineMAModel *)model.qsModel;
        if ([model.qsModel isKindOfClass:[LJKLineMAModel class]])
        {
            if ([model.hip floatValue] > maxHip) {
                maxHip = [model.hip floatValue];
            }
            if ([model.lop floatValue] < minLop) {
                minLop = [model.lop floatValue];
            }
            
            //MA5 MA10 MA20 MA40
            if ([model.hip floatValue] > kpiMax) {
                kpiMax = [model.hip floatValue];
            }
            if (maModel.ma5.length > 0 && [maModel.ma5 floatValue] > kpiMax) {
                kpiMax = [maModel.ma5 floatValue];
            }
            if (maModel.ma10.length > 0 && [maModel.ma10 floatValue] > kpiMax) {
                kpiMax = [maModel.ma10 floatValue];
            }
            if (maModel.ma20.length > 0 && [maModel.ma20 floatValue] > kpiMax) {
                kpiMax = [maModel.ma20 floatValue];
            }
            if (maModel.ma40.length > 0 && [maModel.ma40 floatValue] > kpiMax) {
                kpiMax = [maModel.ma40 floatValue];
            }
            
            //MA5 MA10 MA20 MA40
            if ([model.lop floatValue] < kpiMin) {
                kpiMin = [model.lop floatValue];
            }
            if (maModel.ma5.length > 0 && [maModel.ma5 floatValue] < kpiMin) {
                kpiMin = [maModel.ma5 floatValue];
            }
            if (maModel.ma10.length > 0 && [maModel.ma10 floatValue] < kpiMin) {
                kpiMin = [maModel.ma10 floatValue];
            }
            if (maModel.ma20.length > 0 && [maModel.ma20 floatValue] < kpiMin) {
                kpiMin = [maModel.ma20 floatValue];
            }
            if (maModel.ma40.length > 0 && [maModel.ma40 floatValue] < kpiMin) {
                kpiMin = [maModel.ma40 floatValue];
            }
        }
    }
    return [NSDictionary dictionaryWithObjectsAndKeys:[NSString jk_reviseString:kpiMax],LJ_KPI_Max,[NSString jk_reviseString:kpiMin],LJ_KPI_Min,[NSString jk_reviseString:maxHip],LJ_Max_Hip,[NSString jk_reviseString:minLop],LJ_Min_Lop, nil];
}

/**
 计算EMA 最高价 、最低价
 
 @return NSDictionary
 */
- (NSDictionary *)calculateEMAMaxMin
{
    float kpiMax = 0.0f;
    float kpiMin = 0.0f;
    
    float maxHip = 0.0f;
    float minLop = 0.0f;
    
    
    if (self.count > 0) {
        kpiMax = [((LJKLineModel *)[self objectAtIndex:0]).hip floatValue];
        kpiMin = kpiMax;
        
        maxHip = kpiMax;
        minLop = kpiMax;
    }
    
    for (int i = 0; i < self.count; i++) {
        LJKLineModel *model = self[i];
        LJKLineEMAModel *emaModel = (LJKLineEMAModel *)model.qsModel;
        if ([model.qsModel isKindOfClass:[LJKLineEMAModel class]])
        {
            if ([model.hip floatValue] > maxHip) {
                maxHip = [model.hip floatValue];
            }
            if ([model.lop floatValue] < minLop) {
                minLop = [model.lop floatValue];
            }
            
            //EMA5 EMA10 EMA20 EMA40
            if ([model.hip floatValue] > kpiMax) {
                kpiMax = [model.hip floatValue];
            }
            if (emaModel.ema5.length > 0 && [emaModel.ema5 floatValue] > kpiMax) {
                kpiMax = [emaModel.ema5 floatValue];
            }
            if (emaModel.ema10.length > 0 && [emaModel.ema10 floatValue] > kpiMax) {
                kpiMax = [emaModel.ema10 floatValue];
            }
            if (emaModel.ema20.length > 0 && [emaModel.ema20 floatValue] > kpiMax) {
                kpiMax = [emaModel.ema20 floatValue];
            }
            if (emaModel.ema40.length > 0 && [emaModel.ema40 floatValue] > kpiMax) {
                kpiMax = [emaModel.ema40 floatValue];
            }
            
            //EMA5 EMA10 EMA20 EMA40
            if ([model.lop floatValue] < kpiMin) {
                kpiMin = [model.lop floatValue];
            }
            if (emaModel.ema5.length > 0 && [emaModel.ema5 floatValue] < kpiMin) {
                kpiMin = [emaModel.ema5 floatValue];
            }
            if (emaModel.ema10.length > 0 && [emaModel.ema10 floatValue] < kpiMin) {
                kpiMin = [emaModel.ema10 floatValue];
            }
            if (emaModel.ema20.length > 0 && [emaModel.ema20 floatValue] < kpiMin) {
                kpiMin = [emaModel.ema20 floatValue];
            }
            if (emaModel.ema40.length > 0 && [emaModel.ema40 floatValue] < kpiMin) {
                kpiMin = [emaModel.ema40 floatValue];
            }
        }
    }
    return [NSDictionary dictionaryWithObjectsAndKeys:[NSString jk_reviseString:kpiMax],LJ_KPI_Max,[NSString jk_reviseString:kpiMin],LJ_KPI_Min,[NSString jk_reviseString:maxHip],LJ_Max_Hip,[NSString jk_reviseString:minLop],LJ_Min_Lop, nil];
}


/**
 计算BOLL 最高价 、最低价
 
 @return NSDictionary
 */
- (NSDictionary *)calculateBOLLMaxMin
{
    float kpiMax = 0.0f;
    float kpiMin = 0.0f;
    
    float maxHip = 0.0f;
    float minLop = 0.0f;
    
    
    if (self.count > 0) {
        kpiMax = [((LJKLineModel *)[self objectAtIndex:0]).hip floatValue];
        kpiMin = kpiMax;
        
        maxHip = kpiMax;
        minLop = kpiMax;
    }
    
    for (int i = 0; i < self.count; i++) {
        LJKLineModel *model = self[i];
        LJKLineBOLLModel *bollModel = (LJKLineBOLLModel *)model.qsModel;
        if ([model.qsModel isKindOfClass:[LJKLineBOLLModel class]])
        {
            if ([model.hip floatValue] > maxHip) {
                maxHip = [model.hip floatValue];
            }
            if ([model.lop floatValue] < minLop) {
                minLop = [model.lop floatValue];
            }
            
            //boll_MB boll_UP boll_DN
            if ([model.hip floatValue] > kpiMax) {
                kpiMax = [model.hip floatValue];
            }
            if (bollModel.boll_MB.length > 0 && [bollModel.boll_MB floatValue] > kpiMax) {
                kpiMax = [bollModel.boll_MB floatValue];
            }
            if (bollModel.boll_UP.length > 0 && [bollModel.boll_UP floatValue] > kpiMax) {
                kpiMax = [bollModel.boll_UP floatValue];
            }
            if (bollModel.boll_DN.length > 0 && [bollModel.boll_DN floatValue] > kpiMax) {
                kpiMax = [bollModel.boll_DN floatValue];
            }
            
            //boll_MB boll_UP boll_DN
            if ([model.lop floatValue] < kpiMin) {
                kpiMin = [model.lop floatValue];
            }
            if (bollModel.boll_MB.length > 0 && [bollModel.boll_MB floatValue] < kpiMin) {
                kpiMin = [bollModel.boll_MB floatValue];
            }
            if (bollModel.boll_UP.length > 0 && [bollModel.boll_UP floatValue] < kpiMin) {
                kpiMin = [bollModel.boll_UP floatValue];
            }
            if (bollModel.boll_DN.length > 0 && [bollModel.boll_DN floatValue] < kpiMin) {
                kpiMin = [bollModel.boll_DN floatValue];
            }
        }
    }
    return [NSDictionary dictionaryWithObjectsAndKeys:[NSString jk_reviseString:kpiMax],LJ_KPI_Max,[NSString jk_reviseString:kpiMin],LJ_KPI_Min,[NSString jk_reviseString:maxHip],LJ_Max_Hip,[NSString jk_reviseString:minLop],LJ_Min_Lop, nil];
}




/**
 计算MV 最高价 、 最低价
 
 @return NSDictionary
 */
- (NSDictionary *)calculateMVMaxMin
{
    float kpiMax = 0.0f;
    float kpiMin = 0.0f;
    if (self.count > 0) {
        kpiMax = [((LJKLineModel *)[self objectAtIndex:0]).vol floatValue];
        kpiMin = kpiMax;
    }
    
    for (int i = 0; i < self.count; i++) {
        LJKLineModel *model = self[i];
        LJKLineMVModel *mvModel = (LJKLineMVModel *)model.lcModel;
        if ([model.lcModel isKindOfClass:[LJKLineMVModel class]])
        {
            if ([model.vol floatValue] > kpiMax) {
                kpiMax = [model.vol floatValue];
            }
            if (mvModel.ma5.length > 0 && [mvModel.ma5 floatValue] > kpiMax) {
                kpiMax = [mvModel.ma5 floatValue];
            }
            if (mvModel.ma10.length > 0 && [mvModel.ma10 floatValue] > kpiMax) {
                kpiMax = [mvModel.ma10 floatValue];
            }
            
            //
            if ([model.vol floatValue] < kpiMin) {
                kpiMin = [model.vol floatValue];
            }
            if (mvModel.ma5.length > 0 && [mvModel.ma5 floatValue] < kpiMin) {
                kpiMin = [mvModel.ma5 floatValue];
            }
            if (mvModel.ma10.length > 0 && [mvModel.ma10 floatValue] < kpiMin) {
                kpiMin = [mvModel.ma10 floatValue];
            }
        }
    }
    return [NSDictionary dictionaryWithObjectsAndKeys:[NSString jk_reviseString:kpiMax],LJ_KPI_Max,[NSString jk_reviseString:kpiMin],LJ_KPI_Min, nil];
}


/**
 计算MACD 最高价 、 最低价
 
 @return NSDictionary
 */
- (NSDictionary *)calculateMACDMaxMin
{
    float kpiMax = 0.0f;
    float kpiMin = 0.0f;
    if (self.count > 0) {
        LJKLineModel *model = self[0];
        LJKLineMACDModel *macdModel = (LJKLineMACDModel *)model.bdModel;
        
        kpiMax = [macdModel.dif floatValue];
        kpiMin = kpiMax;
    }
    
    for (int i = 0; i < self.count; i++) {
        LJKLineModel *model = self[i];
        LJKLineMACDModel *macdModel = (LJKLineMACDModel *)model.bdModel;
        if ([model.bdModel isKindOfClass:[LJKLineMACDModel class]])
        {
            if (macdModel.dif.length > 0 && [macdModel.dif floatValue] > kpiMax) {
                kpiMax = [macdModel.dif floatValue];
            }
            if (macdModel.dea.length > 0 && [macdModel.dea floatValue] > kpiMax) {
                kpiMax = [macdModel.dea floatValue];
            }
            if (macdModel.macd.length > 0 && [macdModel.macd floatValue] > kpiMax) {
                kpiMax = [macdModel.macd floatValue];
            }
            
            //
            if (macdModel.dif.length > 0 && [macdModel.dif floatValue] < kpiMin) {
                kpiMin = [macdModel.dif floatValue];
            }
            if (macdModel.dea.length > 0 && [macdModel.dea floatValue] < kpiMin) {
                kpiMin = [macdModel.dea floatValue];
            }
            if (macdModel.macd.length > 0 && [macdModel.macd floatValue] < kpiMin) {
                kpiMin = [macdModel.macd floatValue];
            }
        }
    }
    return [NSDictionary dictionaryWithObjectsAndKeys:[NSString jk_reviseString:kpiMax],LJ_KPI_Max,[NSString jk_reviseString:kpiMin],LJ_KPI_Min, nil];
}

/**
 计算KDJ 最高价 、 最低价
 
 @return NSDictionary
 */
- (NSDictionary *)calculateKDJMaxMin
{
    float kpiMax = 0.0f;
    float kpiMin = 0.0f;
    if (self.count > 0) {
        LJKLineModel *model = self[0];
        LJKLineKDJModel *kdjModel = (LJKLineKDJModel *)model.bdModel;
        
        kpiMax = [kdjModel.kdj_K floatValue];
        kpiMin = kpiMax;
    }
    
    for (int i = 0; i < self.count; i++) {
        LJKLineModel *model = self[i];
        LJKLineKDJModel *kdjModel = (LJKLineKDJModel *)model.bdModel;
        if ([model.bdModel isKindOfClass:[LJKLineKDJModel class]])
        {
            if (kdjModel.kdj_K.length > 0 && [kdjModel.kdj_K floatValue] > kpiMax) {
                kpiMax = [kdjModel.kdj_K floatValue];
            }
            if (kdjModel.kdj_D.length > 0 && [kdjModel.kdj_D floatValue] > kpiMax) {
                kpiMax = [kdjModel.kdj_D floatValue];
            }
            if (kdjModel.kdj_J.length > 0 && [kdjModel.kdj_J floatValue] > kpiMax) {
                kpiMax = [kdjModel.kdj_J floatValue];
            }
            
            //
            if (kdjModel.kdj_K.length > 0 && [kdjModel.kdj_K floatValue] < kpiMin) {
                kpiMin = [kdjModel.kdj_K floatValue];
            }
            if (kdjModel.kdj_D.length > 0 && [kdjModel.kdj_D floatValue] < kpiMin) {
                kpiMin = [kdjModel.kdj_D floatValue];
            }
            if (kdjModel.kdj_J.length > 0 && [kdjModel.kdj_J floatValue] < kpiMin) {
                kpiMin = [kdjModel.kdj_J floatValue];
            }
        }
    }
    return [NSDictionary dictionaryWithObjectsAndKeys:[NSString jk_reviseString:kpiMax],LJ_KPI_Max,[NSString jk_reviseString:kpiMin],LJ_KPI_Min, nil];
}

/**
 计算RSI 最高价 、 最低价
 
 @return NSDictionary
 */
- (NSDictionary *)calculateRSIMaxMin
{
    float kpiMax = 0.0f;
    float kpiMin = 0.0f;
    if (self.count > 0) {
        LJKLineModel *model = self[0];
        LJKLineRSIModel *rsiModel = (LJKLineRSIModel *)model.bdModel;
        
        kpiMax = [rsiModel.rsi_6 floatValue];
        kpiMin = kpiMax;
    }
    
    for (int i = 0; i < self.count; i++) {
        LJKLineModel *model = self[i];
        LJKLineRSIModel *rsiModel = (LJKLineRSIModel *)model.bdModel;
        if ([model.bdModel isKindOfClass:[LJKLineRSIModel class]])
        {
            if (rsiModel.rsi_6.length > 0 && [rsiModel.rsi_6 floatValue] > kpiMax) {
                kpiMax = [rsiModel.rsi_6 floatValue];
            }
            if (rsiModel.rsi_12.length > 0 && [rsiModel.rsi_12 floatValue] > kpiMax) {
                kpiMax = [rsiModel.rsi_12 floatValue];
            }
            if (rsiModel.rsi_24.length > 0 && [rsiModel.rsi_24 floatValue] > kpiMax) {
                kpiMax = [rsiModel.rsi_24 floatValue];
            }
            
            //
            if (rsiModel.rsi_6.length > 0 && [rsiModel.rsi_6 floatValue] < kpiMin) {
                kpiMin = [rsiModel.rsi_6 floatValue];
            }
            if (rsiModel.rsi_12.length > 0 && [rsiModel.rsi_12 floatValue] < kpiMin) {
                kpiMin = [rsiModel.rsi_12 floatValue];
            }
            if (rsiModel.rsi_24.length > 0 && [rsiModel.rsi_24 floatValue] < kpiMin) {
                kpiMin = [rsiModel.rsi_24 floatValue];
            }
        }
    }
    return [NSDictionary dictionaryWithObjectsAndKeys:[NSString jk_reviseString:kpiMax],LJ_KPI_Max,[NSString jk_reviseString:kpiMin],LJ_KPI_Min, nil];
}








@end
