//
//  NSMutableArray+MaxMin.h
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/5/31.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import <Foundation/Foundation.h>

#define LJ_KPI_Max @"kpiMax"
#define LJ_KPI_Min @"kpiMin"

#define LJ_Max_Hip @"maxHip"
#define LJ_Min_Lop @"minLop"

@interface NSMutableArray (MaxMin)

#pragma -mark 趋势指标
/**
 计算普通K线(蜡烛图)最高价-最低价

 @return NSDictionary
 */
- (NSDictionary *)calculateCandleMaxMin;

/**
 计算MA 最高价 、最低价
 
 @return NSDictionary
 */
- (NSDictionary *)calculateMAMaxMin;

/**
 计算EMA 最高价 、最低价
 
 @return NSDictionary
 */
- (NSDictionary *)calculateEMAMaxMin;


/**
 计算BOLL 最高价 、最低价
 
 @return NSDictionary
 */
- (NSDictionary *)calculateBOLLMaxMin;



#pragma -mark 量仓指标
/**
 计算MV 最高价 、 最低价
 
 @return NSDictionary
 */
- (NSDictionary *)calculateMVMaxMin;


#pragma -mark 摆动指标
/**
 计算MACD 最高价 、 最低价
 
 @return NSDictionary
 */
- (NSDictionary *)calculateMACDMaxMin;

/**
 计算KDJ 最高价 、 最低价
 
 @return NSDictionary
 */
- (NSDictionary *)calculateKDJMaxMin;

/**
 计算RSI 最高价 、 最低价
 
 @return NSDictionary
 */
- (NSDictionary *)calculateRSIMaxMin;



@end
