//
//  LJSettingManager.m
//  StockApp
//
//  Created by 伍孟华 on 2018/11/5.
//  Copyright © 2018 分时K线. All rights reserved.
//

#import "LJSettingManager.h"

@implementation LJSettingManager

#pragma mark - KLine指标
+(NSMutableArray <LJKLineKPITreeModel *>*)getKLineKPITreeList
{
    
    NSMutableArray *klineKPITreeArray = [[NSMutableArray alloc] init];
    //MA
    LJKLineKPITreeModel *maKPIModel = [[LJKLineKPITreeModel alloc] init];
    maKPIModel.treeType = LJKLineKPITreeType_QS;
    maKPIModel.kpiName = @"MA";
    maKPIModel.kpiIdx = 0;
    maKPIModel.isShow = YES;
    
    LJKLineKPITreeStairModel *stairModel = [[LJKLineKPITreeStairModel alloc] init];
    stairModel.kpiName = maKPIModel.kpiName;
    stairModel.paramName = @"MA5";
    stairModel.paramValue = @"5";
    [maKPIModel.paramArray addObject:stairModel];
    
    stairModel = [[LJKLineKPITreeStairModel alloc] init];
    stairModel.kpiName = maKPIModel.kpiName;
    stairModel.paramName = @"MA10";
    stairModel.paramValue = @"10";
    [maKPIModel.paramArray addObject:stairModel];
    
    stairModel = [[LJKLineKPITreeStairModel alloc] init];
    stairModel.kpiName = maKPIModel.kpiName;
    stairModel.paramName = @"MA20";
    stairModel.paramValue = @"20";
    [maKPIModel.paramArray addObject:stairModel];
    
    stairModel = [[LJKLineKPITreeStairModel alloc] init];
    stairModel.kpiName = maKPIModel.kpiName;
    stairModel.paramName = @"MA40";
    stairModel.paramValue = @"40";
    [maKPIModel.paramArray addObject:stairModel];
    [klineKPITreeArray addObject:maKPIModel];
    
    //EMA
    LJKLineKPITreeModel *emaKPIModel = [[LJKLineKPITreeModel alloc] init];
    emaKPIModel.treeType = LJKLineKPITreeType_QS;
    emaKPIModel.kpiName = @"EMA";
    emaKPIModel.kpiIdx = 1;
    emaKPIModel.isShow = YES;
    
    stairModel = [[LJKLineKPITreeStairModel alloc] init];
    stairModel.kpiName = emaKPIModel.kpiName;
    stairModel.paramName = @"EMA5";
    stairModel.paramValue = @"5";
    [emaKPIModel.paramArray addObject:stairModel];
    
    stairModel = [[LJKLineKPITreeStairModel alloc] init];
    stairModel.kpiName = emaKPIModel.kpiName;
    stairModel.paramName = @"EMA10";
    stairModel.paramValue = @"10";
    [emaKPIModel.paramArray addObject:stairModel];
    
    stairModel = [[LJKLineKPITreeStairModel alloc] init];
    stairModel.kpiName = emaKPIModel.kpiName;
    stairModel.paramName = @"EMA20";
    stairModel.paramValue = @"20";
    [emaKPIModel.paramArray addObject:stairModel];
    
    stairModel = [[LJKLineKPITreeStairModel alloc] init];
    stairModel.kpiName = emaKPIModel.kpiName;
    stairModel.paramName = @"EMA40";
    stairModel.paramValue = @"40";
    [emaKPIModel.paramArray addObject:stairModel];
    [klineKPITreeArray addObject:emaKPIModel];
    
    //BOLL
    LJKLineKPITreeModel *bollKPIModel = [[LJKLineKPITreeModel alloc] init];
    bollKPIModel.treeType = LJKLineKPITreeType_QS;
    bollKPIModel.kpiName = @"BOLL";
    bollKPIModel.kpiIdx = 2;
    bollKPIModel.isShow = YES;
    
    stairModel = [[LJKLineKPITreeStairModel alloc] init];
    stairModel.kpiName = bollKPIModel.kpiName;
    stairModel.paramName = @"N";
    stairModel.paramValue = @"26";
    [bollKPIModel.paramArray addObject:stairModel];
    
    stairModel = [[LJKLineKPITreeStairModel alloc] init];
    stairModel.kpiName = bollKPIModel.kpiName;
    stairModel.paramName = @"M";
    stairModel.paramValue = @"26";
    [bollKPIModel.paramArray addObject:stairModel];
    
    stairModel = [[LJKLineKPITreeStairModel alloc] init];
    stairModel.kpiName = bollKPIModel.kpiName;
    stairModel.paramName = @"P";
    stairModel.paramValue = @"2";
    [bollKPIModel.paramArray addObject:stairModel];
    [klineKPITreeArray addObject:bollKPIModel];
    
    //MV
    LJKLineKPITreeModel *mvKPIModel = [[LJKLineKPITreeModel alloc] init];
    mvKPIModel.treeType = LJKLineKPITreeType_LC;
    mvKPIModel.kpiName = @"MV";
    mvKPIModel.kpiIdx = 0;
    mvKPIModel.isShow = YES;
    
    stairModel = [[LJKLineKPITreeStairModel alloc] init];
    stairModel.kpiName = mvKPIModel.kpiName;
    stairModel.paramName = @"N";
    stairModel.paramValue = @"10";
    [mvKPIModel.paramArray addObject:stairModel];
    
    stairModel = [[LJKLineKPITreeStairModel alloc] init];
    stairModel.kpiName = mvKPIModel.kpiName;
    stairModel.paramName = @"M";
    stairModel.paramValue = @"20";
    [mvKPIModel.paramArray addObject:stairModel];
    [klineKPITreeArray addObject:mvKPIModel];
    
    //MACD
    LJKLineKPITreeModel *macdKPIModel = [[LJKLineKPITreeModel alloc] init];
    macdKPIModel.treeType = LJKLineKPITreeType_BD;
    macdKPIModel.kpiName = @"MACD";
    macdKPIModel.kpiIdx = 0;
    macdKPIModel.isShow = YES;
    
    stairModel = [[LJKLineKPITreeStairModel alloc] init];
    stairModel.kpiName = macdKPIModel.kpiName;
    stairModel.paramName = @"SHORT";
    stairModel.paramValue = @"12";
    [macdKPIModel.paramArray addObject:stairModel];
    
    stairModel = [[LJKLineKPITreeStairModel alloc] init];
    stairModel.kpiName = macdKPIModel.kpiName;
    stairModel.paramName = @"LONG";
    stairModel.paramValue = @"26";
    [macdKPIModel.paramArray addObject:stairModel];
    
    stairModel = [[LJKLineKPITreeStairModel alloc] init];
    stairModel.kpiName = macdKPIModel.kpiName;
    stairModel.paramName = @"M";
    stairModel.paramValue = @"9";
    [macdKPIModel.paramArray addObject:stairModel];
    [klineKPITreeArray addObject:macdKPIModel];
    
    //KDJ
    LJKLineKPITreeModel *kdjKPIModel = [[LJKLineKPITreeModel alloc] init];
    kdjKPIModel.treeType = LJKLineKPITreeType_BD;
    kdjKPIModel.kpiName = @"KDJ";
    kdjKPIModel.kpiIdx = 1;
    kdjKPIModel.isShow = YES;
    
    stairModel = [[LJKLineKPITreeStairModel alloc] init];
    stairModel.kpiName = kdjKPIModel.kpiName;
    stairModel.paramName = @"N";
    stairModel.paramValue = @"9";
    [kdjKPIModel.paramArray addObject:stairModel];
    
    stairModel = [[LJKLineKPITreeStairModel alloc] init];
    stairModel.kpiName = kdjKPIModel.kpiName;
    stairModel.paramName = @"M1";
    stairModel.paramValue = @"3";
    [kdjKPIModel.paramArray addObject:stairModel];
    
    stairModel = [[LJKLineKPITreeStairModel alloc] init];
    stairModel.kpiName = kdjKPIModel.kpiName;
    stairModel.paramName = @"M2";
    stairModel.paramValue = @"3";
    [kdjKPIModel.paramArray addObject:stairModel];
    [klineKPITreeArray addObject:kdjKPIModel];
    
    //RSI
    LJKLineKPITreeModel *rsiKPIModel = [[LJKLineKPITreeModel alloc] init];
    rsiKPIModel.treeType = LJKLineKPITreeType_BD;
    rsiKPIModel.kpiName = @"RSI";
    rsiKPIModel.kpiIdx = 2;
    rsiKPIModel.isShow = YES;
    
    stairModel = [[LJKLineKPITreeStairModel alloc] init];
    stairModel.kpiName = rsiKPIModel.kpiName;
    stairModel.paramName = @"N1";
    stairModel.paramValue = @"7";
    [rsiKPIModel.paramArray addObject:stairModel];
    
    stairModel = [[LJKLineKPITreeStairModel alloc] init];
    stairModel.kpiName = rsiKPIModel.kpiName;
    stairModel.paramName = @"N2";
    stairModel.paramValue = @"14";
    [rsiKPIModel.paramArray addObject:stairModel];
    
    stairModel = [[LJKLineKPITreeStairModel alloc] init];
    stairModel.kpiName = rsiKPIModel.kpiName;
    stairModel.paramName = @"N3";
    stairModel.paramValue = @"24";
    [rsiKPIModel.paramArray addObject:stairModel];
    [klineKPITreeArray addObject:rsiKPIModel];
    
    return klineKPITreeArray;
}


@end
