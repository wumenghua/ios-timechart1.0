//
//  CATextLayer+kLineTextLayer.h
//  YiFu
//
//  Created by 伍孟华 on 2018/8/20.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import <UIKit/UIKit.h>

@interface CATextLayer (kLineTextLayer)

/**
 绘制文字
 
 @param text 字符串
 @param textColor 文字颜色
 @param bgColor 背景颜色
 @param frame 文字frame
 @return 返回textLayer
 */
+ (CATextLayer *)lj_kLineTextLayerWithString:(NSString *)text
                              textColor:(UIColor *)textColor
                               fontSize:(NSInteger)fontSize
                        backgroundColor:(UIColor *)bgColor
                                  frame:(CGRect)frame;

/**
 绘制K线顶部指标
 
 @param textArray 指标数组
 @return Layer数组
 */
+ (NSMutableArray *)lj_calculateTextPoint:(NSArray *)textArray maxWidth:(float)maxWidth drawY:(float)drawY reservedWidth:(float)reservedWidth;

@end
