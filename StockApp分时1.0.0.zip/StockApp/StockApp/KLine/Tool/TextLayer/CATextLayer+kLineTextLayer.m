//
//  CATextLayer+kLineTextLayer.m
//  YiFu
//
//  Created by 伍孟华 on 2018/8/20.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "CATextLayer+kLineTextLayer.h"
#import "LJDrawTextModel.h"
#import "NSString+JKSize.h"

@implementation CATextLayer (kLineTextLayer)

/**
 绘制文字
 
 @param text 字符串
 @param textColor 文字颜色
 @param bgColor 背景颜色
 @param frame 文字frame
 @return 返回textLayer
 */
+ (CATextLayer *)lj_kLineTextLayerWithString:(NSString *)text
                              textColor:(UIColor *)textColor
                               fontSize:(NSInteger)fontSize
                        backgroundColor:(UIColor *)bgColor
                                  frame:(CGRect)frame
{
    //初始化一个CATextLayer
    CATextLayer *textLayer = [CATextLayer layer];
    //设置文字frame
    textLayer.frame = frame;
    //设置文字
    textLayer.string = text;
    //设置文字大小
    textLayer.fontSize = fontSize;
    //设置文字颜色
    textLayer.foregroundColor = textColor.CGColor;
    //设置背景颜色
    textLayer.backgroundColor = bgColor.CGColor;
    //设置对齐方式
    textLayer.alignmentMode = kCAAlignmentLeft;
    //设置分辨率
    textLayer.contentsScale = [UIScreen mainScreen].scale;
    
    return textLayer;
}

/**
 绘制K线顶部指标

 @param textArray 指标数组
 @return Layer数组
 */
+ (NSMutableArray *)lj_calculateTextPoint:(NSArray *)textArray maxWidth:(float)maxWidth drawY:(float)drawY reservedWidth:(float)reservedWidth
{

    NSMutableArray *layerArray = [[NSMutableArray alloc] init];
    float y = drawY;
    //文字上面留1个间隙
    y += 1;

    float x = 0;
    CGRect rect;
    for (LJDrawTextModel *textModel in textArray) {

        NSDictionary *attribute = @{NSFontAttributeName:[UIFont systemFontOfSize:textModel.fontSize]};
        rect = [NSString jk_rectOfNSString:textModel.text attribute:attribute];

        float tempX = x + rect.size.width + reservedWidth;
        if (tempX > maxWidth)
        {
            x = 0;
            y += rect.size.height;
        }
        //如果Left + 文字宽度 小于最大宽度，就代表可以继续写入
        textModel.textRect = CGRectMake(x, y, rect.size.width + reservedWidth, rect.size.height);
        [layerArray addObject:textModel];
        
//        CATextLayer *textLayer = [CATextLayer lj_kLineTextLayerWithString:@"213" textColor:[UIColor whiteColor] fontSize:textModel.fontSize backgroundColor:[UIColor clearColor] frame:CGRectMake(x, y, rect.size.width, rect.size.height)];
//        [layerArray addObject:textLayer];
        
        //x + 文字宽度 + 文字间隙
        x = x + rect.size.width + 15 + reservedWidth;
    }
    y += rect.size.height;
    //文字下面留1个间隙
    y += 1;

    [layerArray addObject:@(y-drawY)];
    return layerArray;
}

@end
