//
//  LJKLineLayoutModel.h
//  YiFu
//
//  Created by 伍孟华 on 2018/8/16.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LJKLineLayoutModel : NSObject

#pragma -mark 赋值
//K线控件宽度
@property (assign ,nonatomic) float layoutWidth;
//K线控件高度
@property (assign ,nonatomic) float layoutHeight;
//K线控件底部留出高度，用于绘制时间
@property (assign ,nonatomic) float layoutBottonHeight;
//内部控件高度，不需要可滞空；按百分比计算
@property (assign ,nonatomic) float layerScale;

//左空隙
@property (assign ,nonatomic) float leftSpace;
//右空隙
@property (assign ,nonatomic) float rightSpace;
//上空隙
@property (assign ,nonatomic) float topSpace;
//下空隙
@property (assign ,nonatomic) float bottonSpace;

//KPI 起始位置
@property (assign ,nonatomic) float kpiY;
//KPI 高度
@property (assign ,nonatomic) float kpiHeight;

//是否隐藏
@property (nonatomic,assign) BOOL isHide;

//指标类型数组
@property (strong ,nonatomic) NSMutableArray *kpiArray;

#pragma -mark 属性
//CGRect
@property (assign ,nonatomic) float x;
@property (assign ,nonatomic) float y;
@property (assign ,nonatomic) float w;
@property (assign ,nonatomic) float h;
@property (assign ,nonatomic) float botton;

@property (assign ,nonatomic) float innerX;
@property (assign ,nonatomic) float innerY;
@property (assign ,nonatomic) float innerW;
@property (assign ,nonatomic) float innerH;

/**
 计算控件属性
 */
- (void)calculateLayerModel;

@end
