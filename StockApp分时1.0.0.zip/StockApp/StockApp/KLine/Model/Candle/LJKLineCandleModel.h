//
//  LJKLineCandleModel.h
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/5/31.
//  Copyright © 2018年 伍孟华. All rights reserved.
//  蜡烛图

typedef enum {
    LJ_KLine_UP_Type=0,//上涨
    LJ_KLine_Down_Type,//下跌
    LJ_KLine_Equality_Type//相等
} LJ_ENUM_KLineCandleType;

#import "LJKLineBaseModel.h"
#import <CoreGraphics/CGGeometry.h>

@interface LJKLineCandleModel : LJKLineBaseModel

//蜡烛图中点位置，用于十字架绘制
@property (nonatomic ,assign) float candleX;

//上边蜡烛图线 Y位置 、 高度
@property (nonatomic, assign) float upY;
@property (nonatomic, assign) float upHeight;

//柱形蜡烛图 Y位置 、 高度
@property (nonatomic, assign) float pillarY;
@property (nonatomic, assign) float pillarHeight;

//下边蜡烛线 Y位置 、 高度
@property (nonatomic, assign) float downY;
@property (nonatomic, assign) float downHeight;

//上涨、下跌、相等
@property (nonatomic ,assign) NSInteger kLineType;

//是否最高价
@property (nonatomic ,assign) BOOL isMaxValue;
@property (nonatomic ,strong) NSString *maxValue;
//最高价Rect
@property (nonatomic,assign) CGRect drawMaxRect;

//是否最低价
@property (nonatomic ,assign) BOOL isMinValue;
@property (nonatomic ,strong) NSString *minValue;
//最高价Rect
@property (nonatomic,assign) CGRect drawMinRect;



@end
