//
//  LJKLineLayoutModel.m
//  YiFu
//
//  Created by 伍孟华 on 2018/8/16.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "LJKLineLayoutModel.h"

@implementation LJKLineLayoutModel

- (instancetype)init
{
    self = [super init];
    if (self) {
        
        self.layoutBottonHeight = 20;
        
        self.isHide = NO;
    }
    return self;
}

/**
 计算控件属性
 */
- (void)calculateLayerModel
{
    self.x = self.leftSpace;
    self.w = self.layoutWidth;
    self.h = (self.layoutHeight-self.layoutBottonHeight) * self.layerScale;
    
    self.innerX = self.leftSpace;
    self.innerY = self.y + self.kpiY + self.kpiHeight + self.topSpace;
    self.innerW = self.w - self.leftSpace - self.rightSpace;
    self.innerH = self.h - self.kpiY - self.kpiHeight - self.topSpace - self.bottonSpace;
    
    self.botton = (self.y + self.h) - self.bottonSpace;
}

@end
