//
//  LJKLineBaseModel.h
//  YiFu
//
//  Created by 伍孟华 on 2018/8/16.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LJKLineBaseModel : NSObject

@end
