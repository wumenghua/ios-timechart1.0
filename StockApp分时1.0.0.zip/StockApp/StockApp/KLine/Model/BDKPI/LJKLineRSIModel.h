//
//  LJKLineRSIModel.h
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/5/31.
//  Copyright © 2018年 伍孟华. All rights reserved.
//  RSI指标

#import "LJKLineBaseModel.h"

@interface LJKLineRSIModel : LJKLineBaseModel

//RSI_6 的值
@property (nonatomic, strong) NSString *rsi_6;
@property (nonatomic, assign) double rsi_6_A;
@property (nonatomic, assign) double rsi_6_B;

//RSI_12 的值
@property (nonatomic, strong) NSString *rsi_12;
@property (nonatomic, assign) double rsi_12_A;
@property (nonatomic, assign) double rsi_12_B;

//RSI_24 的值
@property (nonatomic, strong) NSString *rsi_24;
@property (nonatomic, assign) double rsi_24_A;
@property (nonatomic, assign) double rsi_24_B;


//RSI_6、RSI_12、RSI_24 的值
@property (nonatomic, assign) float rsi_6_Y;
@property (nonatomic, assign) float rsi_12_Y;
@property (nonatomic, assign) float rsi_24_Y;


@end
