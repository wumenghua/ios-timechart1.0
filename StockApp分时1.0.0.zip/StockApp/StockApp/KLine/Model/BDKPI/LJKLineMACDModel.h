//
//  LJKLineMACDModel.h
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/5/31.
//  Copyright © 2018年 伍孟华. All rights reserved.
//  MACD指标

#import "LJKLineBaseModel.h"

@interface LJKLineMACDModel : LJKLineBaseModel

//EMA12值
@property (nonatomic,strong) NSString *ema12;
//EMA26值
@property (nonatomic,strong) NSString *ema26;

//dif、dea、macd 值
@property (nonatomic,strong) NSString *dif;
@property (nonatomic,strong) NSString *dea;
@property (nonatomic,strong) NSString *macd;

//dif的Y值、dea的Y值
@property (nonatomic,assign) float dif_Y;
@property (nonatomic,assign) float dea_Y;

//macd的中心线Y值
@property (nonatomic,assign) float macd_centerY;
//macd的Y值
@property (nonatomic,assign) float macd_Y;





@end
