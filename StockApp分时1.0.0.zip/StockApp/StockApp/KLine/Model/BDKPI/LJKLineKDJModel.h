//
//  LJKLineKDJModel.h
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/5/31.
//  Copyright © 2018年 伍孟华. All rights reserved.
//  KDJ指标

#import "LJKLineBaseModel.h"

@interface LJKLineKDJModel : LJKLineBaseModel

//N日最高价
@property (nonatomic, strong) NSString *hip9Price;
//N日最低价
@property (nonatomic, strong) NSString *lop9Price;
//N日RSV
@property (nonatomic, strong) NSString *rsv_9;

//K、D、J 值
@property (nonatomic, strong) NSString *kdj_K;
@property (nonatomic, strong) NSString *kdj_D;
@property (nonatomic, strong) NSString *kdj_J;

//K、D、J Y值
@property (nonatomic, assign) float kdj_K_Y;
@property (nonatomic, assign) float kdj_D_Y;
@property (nonatomic, assign) float kdj_J_Y;


@end
