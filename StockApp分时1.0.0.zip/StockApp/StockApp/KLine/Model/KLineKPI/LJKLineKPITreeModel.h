//
//  LJKLineKPITreeModel.h
//  YiFu
//
//  Created by 伍孟华 on 2018/8/27.
//  Copyright © 2018年 伍孟华. All rights reserved.
//


#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, LJKLineKPITreeType) {
    LJKLineKPITreeType_QS = 0,
    LJKLineKPITreeType_LC = 1,
    LJKLineKPITreeType_BD = 2
};

@interface LJKLineKPITreeModel : NSObject

//类型  趋势、量仓、摆动
@property (nonatomic,assign) NSInteger treeType;

//KPI名称
@property (nonatomic,strong) NSString *kpiName;

//序号
@property (nonatomic,assign) NSInteger kpiIdx;

//是否显示
@property (nonatomic,assign) NSInteger isShow;

//子集Array
@property (nonatomic,strong) NSMutableArray *paramArray;

+ (LJKLineKPITreeModel *)createModel:(NSInteger)treeType kpiName:(NSString *)kpiName kpiIdx:(NSInteger)kpiIdx isShow:(NSInteger)isShow;


@end
