//
//  LJKLineKPITreeModel.m
//  YiFu
//
//  Created by 伍孟华 on 2018/8/27.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "LJKLineKPITreeModel.h"

@implementation LJKLineKPITreeModel

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.treeType = -1;
        
        self.paramArray = [[NSMutableArray alloc] init];
    }
    return self;
}

+ (LJKLineKPITreeModel *)createModel:(NSInteger)treeType kpiName:(NSString *)kpiName kpiIdx:(NSInteger)kpiIdx isShow:(NSInteger)isShow
{
    LJKLineKPITreeModel *treeModel = [[LJKLineKPITreeModel alloc] init];
    treeModel.treeType = treeType;
    treeModel.kpiName = kpiName;
    treeModel.kpiIdx = kpiIdx;
    treeModel.isShow = isShow;
    treeModel.paramArray = [[NSMutableArray alloc] init];
    return treeModel;
}

@end
