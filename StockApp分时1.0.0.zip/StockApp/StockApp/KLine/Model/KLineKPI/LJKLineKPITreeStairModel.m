//
//  LJKLineKPITreeStairModel.m
//  YiFu
//
//  Created by 伍孟华 on 2018/8/27.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "LJKLineKPITreeStairModel.h"
#import "LJKLineKPITreeModel.h"

@implementation LJKLineKPITreeStairModel

+ (LJKLineKPITreeStairModel *)createModel:(NSString *)kpiName paramName:(NSString *)paramName paramValue:(NSString *)paramValue
{
    LJKLineKPITreeStairModel *treeModel = [[LJKLineKPITreeStairModel alloc] init];
    treeModel.kpiName = kpiName;
    treeModel.paramName = paramName;
    treeModel.paramValue = paramValue;
    return treeModel;
}

@end

