//
//  LJKLineKPITreeStairModel.h
//  YiFu
//
//  Created by 伍孟华 on 2018/8/27.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LJKLineKPITreeStairModel : NSObject

//指标名称，关联字段
@property (nonatomic,strong) NSString *kpiName;

//指标参数名称
@property (nonatomic,strong) NSString *paramName;

//指标参数值
@property (nonatomic,strong) NSString *paramValue;

//指标线颜色值

+ (LJKLineKPITreeStairModel *)createModel:(NSString *)kpiName paramName:(NSString *)paramName paramValue:(NSString *)paramValue;

@end
