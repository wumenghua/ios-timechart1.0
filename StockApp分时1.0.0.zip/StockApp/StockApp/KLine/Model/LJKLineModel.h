//
//  LJKLineModel.h
//  YiFu
//
//  Created by 伍孟华 on 2018/8/16.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import <Foundation/Foundation.h>
@class LJKLineCandleModel;
@class LJKLineBaseModel;

@interface LJKLineModel : NSObject

//时间
@property (nonatomic ,strong) NSString * dateChar;

//开盘价
@property (nonatomic ,strong) NSString *op;

//收盘价
@property (nonatomic ,strong) NSString *clp;

//最高价
@property (nonatomic ,strong) NSString *hip;

//最低价
@property (nonatomic ,strong) NSString *lop;

//成交量
@property (nonatomic, strong) NSString *vol;

//持仓量
@property (nonatomic, strong) NSString *opi;

//--------------------指标对象-----------------------
//蜡烛图
@property (nonatomic, strong) LJKLineCandleModel *candleModel;

//趋势指标
@property (nonatomic, strong) LJKLineBaseModel *qsModel;

//量仓指标
@property (nonatomic, strong) LJKLineBaseModel *lcModel;

//摆动指标
@property (nonatomic, strong) LJKLineBaseModel *bdModel;



@end
