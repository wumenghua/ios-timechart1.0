//
//  LJKLineMVModel.h
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/5/31.
//  Copyright © 2018年 伍孟华. All rights reserved.
//  MV指标

#import "LJKLineBaseModel.h"

@interface LJKLineMVModel : LJKLineBaseModel

//MA5、MA10 计算后值
@property (nonatomic ,strong) NSString *ma5;
@property (nonatomic ,strong) NSString *ma10;

//柱形高度
@property (nonatomic ,assign) float volHeight;

//MA5、MA10 计算后的Y值
@property (nonatomic ,assign) float ma5_Y;
@property (nonatomic ,assign) float ma10_Y;



@end
