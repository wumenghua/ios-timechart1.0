//
//  LJKLineMAModel.h
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/5/31.
//  Copyright © 2018年 伍孟华. All rights reserved.
//  MA指标

#import "LJKLineBaseModel.h"

@interface LJKLineMAModel : LJKLineBaseModel

//MA5、MA10、MA20、MA40 计算后值
@property (nonatomic ,strong) NSString *ma5;
@property (nonatomic ,strong) NSString *ma10;
@property (nonatomic ,strong) NSString *ma20;
@property (nonatomic ,strong) NSString *ma40;

//MA5、MA10、MA20、MA40 计算后的Y值
@property (nonatomic ,assign) float ma5_Y;
@property (nonatomic ,assign) float ma10_Y;
@property (nonatomic ,assign) float ma20_Y;
@property (nonatomic ,assign) float ma40_Y;

@end
