//
//  LJKLineEMAModel.h
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/5/31.
//  Copyright © 2018年 伍孟华. All rights reserved.
//  EMA指标

#import "LJKLineBaseModel.h"

@interface LJKLineEMAModel : LJKLineBaseModel

//EMA5、EMA10、EMA20、EMA40 计算后值
@property (nonatomic ,strong) NSString *ema5;
@property (nonatomic ,strong) NSString *ema10;
@property (nonatomic ,strong) NSString *ema20;
@property (nonatomic ,strong) NSString *ema40;

//EMA5、EMA10、EMA20、EMA40 计算后的Y值
@property (nonatomic ,assign) float ema5_Y;
@property (nonatomic ,assign) float ema10_Y;
@property (nonatomic ,assign) float ema20_Y;
@property (nonatomic ,assign) float ema40_Y;

@end
