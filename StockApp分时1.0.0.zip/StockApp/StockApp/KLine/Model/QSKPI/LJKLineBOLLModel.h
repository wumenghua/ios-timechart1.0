//
//  LJKLineBOLLModel.h
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/5/31.
//  Copyright © 2018年 伍孟华. All rights reserved.
//  BOLL指标

#import "LJKLineBaseModel.h"

@interface LJKLineBOLLModel : LJKLineBaseModel

//MA、MD
@property (nonatomic, strong) NSString *boll_MA;
@property (nonatomic, strong) NSString *boll_MD;

//MB、UP、DN
@property (nonatomic, strong) NSString *boll_UP;
@property (nonatomic, strong) NSString *boll_MB;
@property (nonatomic, strong) NSString *boll_DN;

//MB、UP、DN 的Y值
@property (nonatomic, assign) float boll_MB_Y;
@property (nonatomic, assign) float boll_UP_Y;
@property (nonatomic, assign) float boll_DN_Y;


@end
