//
//  LJDrawRectModel.h
//  YiFu
//
//  Created by 伍孟华 on 2018/7/9.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreGraphics/CGGeometry.h>

@interface LJDrawRectModel : NSObject

@property (nonatomic,assign) CGRect rect;

@end
