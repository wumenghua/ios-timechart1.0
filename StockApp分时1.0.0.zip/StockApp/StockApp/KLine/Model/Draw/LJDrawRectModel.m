//
//  LJDrawRectModel.m
//  YiFu
//
//  Created by 伍孟华 on 2018/7/9.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "LJDrawRectModel.h"

@implementation LJDrawRectModel

@end
