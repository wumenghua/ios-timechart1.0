//
//  LJDrawModel.m
//  YiFu
//
//  Created by 伍孟华 on 2018/7/9.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "LJDrawModel.h"

@implementation LJDrawModel

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.lineType = LJ_ENUM_DrawModel_Lines;
        
        self.drawArray = [[NSMutableArray alloc] init];
    }
    return self;
}

@end
