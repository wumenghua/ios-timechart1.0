//
//  LJDrawPointModel.h
//  YiFu
//
//  Created by 伍孟华 on 2018/7/9.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreGraphics/CGGeometry.h>

@interface LJDrawPointModel : NSObject

@property (nonatomic,assign) CGPoint movePoint;

@property (nonatomic,assign) CGPoint toPoint;

@end
