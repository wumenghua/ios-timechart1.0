//
//  LJDrawModel.h
//  YiFu
//
//  Created by 伍孟华 on 2018/7/9.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreGraphics/CGGeometry.h>
#import <UIKit/UIColor.h>
#import "LJDrawPointModel.h"
#import "LJDrawRectModel.h"

// 条件单价格比较
typedef NS_ENUM(NSInteger, LJ_ENUM_DrawModelType) {
    
    LJ_ENUM_DrawModel_Line = 0,                // 单条线
    LJ_ENUM_DrawModel_Lines = 1,               // 连接线
    LJ_ENUM_DrawModel_Pillar = 2,              // 柱体
    LJ_ENUM_DrawModel_Dash = 3                 // 虚线
};

@interface LJDrawModel : NSObject

@property (nonatomic,assign) LJ_ENUM_DrawModelType lineType;

@property (nonatomic,assign) CGFloat lineWidth;

@property (nonatomic,strong) UIColor *fillColor;

@property (nonatomic,strong) UIColor *lineColor;

@property (nonatomic,strong) NSMutableArray *drawArray;

@end
