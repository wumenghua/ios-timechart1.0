//
//  LJDrawTextModel.h
//  YiFu
//
//  Created by 伍孟华 on 2018/8/21.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreGraphics/CGGeometry.h>
#import <UIKit/UIColor.h>
#import <UIKit/NSText.h>

@interface LJDrawTextModel : NSObject

//字符类
@property (nonatomic ,strong) NSString *text;

//字体颜色
@property (nonatomic ,retain) UIColor *textColor;

//时间字体坐标点
@property (nonatomic ,assign) CGRect textRect;

//字体大小
@property (nonatomic,assign) NSInteger fontSize;

//文字方向
@property (nonatomic,assign) NSTextAlignment textAlignment;

@end
