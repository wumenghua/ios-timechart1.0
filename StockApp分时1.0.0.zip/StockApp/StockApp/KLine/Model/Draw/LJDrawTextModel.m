//
//  LJDrawTextModel.m
//  YiFu
//
//  Created by 伍孟华 on 2018/8/21.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "LJDrawTextModel.h"

@implementation LJDrawTextModel

- (instancetype)init
{
    self = [super init];
    if (self)
    {
        self.fontSize = 14;
        
        self.textAlignment = NSTextAlignmentLeft;
    }
    return self;
}

@end
