//
//  LJKLineChartView+BasicsLayer.m
//  YiFu
//
//  Created by 伍孟华 on 2018/8/17.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "LJKLineChartView+BasicsLayer.h"
#import "LJKLineChartView+Basics.h"
#import "LJKLineContextUtil.h"
#import "LJDrawTextModel.h"
#import "CATextLayer+kLineTextLayer.h"

#import "LJKLineChartView+Candle.h"
#import "LJKLineChartView+MA.h"
#import "LJKLineChartView+EMA.h"
#import "LJKLineChartView+BOLL.h"

#import "LJKLineChartView+MV.h"

#import "LJKLineChartView+MACD.h"
#import "LJKLineChartView+KDJ.h"
#import "LJKLineChartView+RSI.h"

@implementation LJKLineChartView (BasicsLayer)

/**
 绘制边框
 */
- (void)calculateBorder:(NSMutableArray *)tempRectArray tempLayoutArray:(NSMutableArray *)tempLayoutArray
{
    LJDrawModel *lineModel = [[LJDrawModel alloc] init];
    lineModel.lineWidth = 0.8;
    lineModel.lineType = LJ_ENUM_DrawModel_Lines;
    lineModel.fillColor = [UIColor clearColor];
    lineModel.lineColor = LJ_Red_Color;
    [tempRectArray addObject:lineModel];
    
    float frameX = self.qsLayout.x;
    float frameY = self.qsLayout.innerY - self.qsLayout.topSpace;
    float frameW = self.qsLayout.w;
    float frameH = self.qsLayout.layoutHeight - self.qsLayout.layoutBottonHeight;
    
    LJDrawPointModel *drawPoint = [[LJDrawPointModel alloc] init];
    drawPoint.movePoint = CGPointMake(frameX, frameY);
    drawPoint.toPoint = CGPointMake(frameW, frameY);
    [lineModel.drawArray addObject:drawPoint];

    drawPoint = [[LJDrawPointModel alloc] init];
    drawPoint.movePoint = CGPointMake(frameW, frameY);
    drawPoint.toPoint = CGPointMake(frameW, frameH);
    [lineModel.drawArray addObject:drawPoint];

    drawPoint = [[LJDrawPointModel alloc] init];
    drawPoint.movePoint = CGPointMake(frameW, frameH);
    drawPoint.toPoint = CGPointMake(frameX, frameH);
    [lineModel.drawArray addObject:drawPoint];

    drawPoint = [[LJDrawPointModel alloc] init];
    drawPoint.movePoint = CGPointMake(frameX, frameH);
    drawPoint.toPoint = CGPointMake(frameX, frameY);
    [lineModel.drawArray addObject:drawPoint];
    
    if (self.lcLayout.layerScale > 0)
    {
        drawPoint = [[LJDrawPointModel alloc] init];
        drawPoint.movePoint = CGPointMake(frameX, self.lcLayout.y);
        drawPoint.toPoint = CGPointMake(frameW, self.lcLayout.y);
        [lineModel.drawArray addObject:drawPoint];
    }
    
    if (self.bdLayout.layerScale > 0)
    {
        drawPoint = [[LJDrawPointModel alloc] init];
        drawPoint.movePoint = CGPointMake(frameX, self.bdLayout.y);
        drawPoint.toPoint = CGPointMake(frameW, self.bdLayout.y);
        [lineModel.drawArray addObject:drawPoint];
    }
}

/**
 重新绘制所有KPI顶部值
 
 @param index 索引
 */
- (void)drawUpdateAllKPI:(NSInteger)index tempRectArray:(NSMutableArray *)tempRectArray tempLayoutArray:(NSMutableArray *)tempLayoutArray tempDrawChartArray:(NSMutableArray *)tempDrawChartArray tempKPIDrawArray:(NSMutableArray *)tempKPIDrawArray
{
    if (!tempKPIDrawArray) {
        tempKPIDrawArray = [[NSMutableArray alloc] init];
    }
    if (self.qsKPIModel && self.qsLayout.layerScale > 0)
    {
        if ([self.qsKPIModel isKindOfClass:[LJKLineCandleKPIModel class]])
        {
            //普K
        }else if ([self.qsKPIModel isKindOfClass:[LJKLineMAKPIModel class]])
        {
            // MA指标
            [self calculateMATopKPIHeight:[tempDrawChartArray objectAtIndex:index] isDraw:YES tempKPIDrawArray:tempKPIDrawArray];
        }else if ([self.qsKPIModel isKindOfClass:[LJKLineEMAKPIModel class]])
        {
            // EMA指标
            [self calculateEMATopKPIHeight:[tempDrawChartArray objectAtIndex:index] isDraw:YES tempKPIDrawArray:tempKPIDrawArray];
        }else if ([self.qsKPIModel isKindOfClass:[LJKLineBOLLKPIModel class]])
        {
            // BOLL指标
            [self calculateBOLLTopKPIHeight:[tempDrawChartArray objectAtIndex:index] isDraw:YES tempKPIDrawArray:tempKPIDrawArray];
        }
    }
    if (self.lcKPIModel && self.lcLayout.layerScale > 0)
    {
        if ([self.lcKPIModel isKindOfClass:[LJKLineMVKPIModel class]])
        {
            //MV 指标
            [self calculateMVTopKPIHeight:[tempDrawChartArray objectAtIndex:index] isDraw:YES tempKPIDrawArray:tempKPIDrawArray];
        }
    }
    if (self.bdKPIModel && self.bdLayout.layerScale > 0)
    {
        if ([self.bdKPIModel isKindOfClass:[LJKLineMACDKPIModel class]])
        {
            //MACD 指标
            [self calculateMACDTopKPIHeight:[tempDrawChartArray objectAtIndex:index] isDraw:YES tempKPIDrawArray:tempKPIDrawArray];
        }else if ([self.bdKPIModel isKindOfClass:[LJKLineKDJKPIModel class]])
        {
            //KDJ 指标
            [self calculateKDJTopKPIHeight:[tempDrawChartArray objectAtIndex:index] isDraw:YES tempKPIDrawArray:tempKPIDrawArray];
        }else if ([self.bdKPIModel isKindOfClass:[LJKLineRSIKPIModel class]])
        {
            //RSI 指标
            [self calculateRSITopKPIHeight:[tempDrawChartArray objectAtIndex:index] isDraw:YES tempKPIDrawArray:tempKPIDrawArray];
        }
    }
    [self drawKPILayout:tempKPIDrawArray];
}

/**
 设置最右边箭头图标
 
 @param index 数据索引
 */
- (void)drawRightArrowImageView:(NSInteger)index
{
    if (index < 0 || index > self.kLineChartArray.count) {
        return;
    }
    if (!self.rightArrowImage) {
        self.rightArrowImage = [[UIImageView alloc] init];
        self.rightArrowImage.image = [UIImage imageNamed:@"lj_kline_right_yellow"];
        [self addSubview:self.rightArrowImage];
    }
    LJKLineModel *klineModel = [self.kLineChartArray objectAtIndex:index];
    self.rightArrowImage.frame = CGRectMake(self.qsLayout.layoutWidth-self.qsLayout.rightSpace, self.qsLayout.innerY + klineModel.candleModel.pillarY + (klineModel.candleModel.pillarHeight/2) - 3, 12, 7);
}

- (void)draw
{
    //画线
    for (int i = 0; i < self.drawRectArray.count; i++)
    {
        LJDrawModel *drawModel = self.drawRectArray[i];
        if (drawModel.drawArray.count > 0)
        {
            if (drawModel.lineType == LJ_ENUM_DrawModel_Line)
            {
                //实线
                for (int j = 0; j < drawModel.drawArray.count; j++)
                {
                    LJDrawPointModel *pointModel = drawModel.drawArray[j];
                    if (!isnan(pointModel.movePoint.x) && !isnan(pointModel.movePoint.y)) {
                        [LJKLineContextUtil lj_AddLineToPoint:drawModel.lineWidth lineColorRef:drawModel.lineColor.CGColor movePoint:pointModel.movePoint toPoint:pointModel.toPoint];
                    }
                }
            }else if (drawModel.lineType == LJ_ENUM_DrawModel_Dash)
            {
                //虚线
                for (int j = 0; j < drawModel.drawArray.count; j++)
                {
                    LJDrawPointModel *pointModel = drawModel.drawArray[j];
                    if (!isnan(pointModel.movePoint.x) && !isnan(pointModel.movePoint.y)) {
                        CGFloat lengths[] = {4,2};
                        [LJKLineContextUtil lj_addLineDash:drawModel.lineWidth lineColorRef:drawModel.lineColor.CGColor lengths:lengths length:2 movePoint:pointModel.movePoint toPoint:pointModel.toPoint];
                    }
                }
            }else if (drawModel.lineType == LJ_ENUM_DrawModel_Lines)
            {
                //连线
                [LJKLineContextUtil lj_AddLineToPointsOff:drawModel.lineWidth lineColorRef:drawModel.lineColor.CGColor movePoints:drawModel.drawArray];
            }else if (drawModel.lineType == LJ_ENUM_DrawModel_Pillar)
            {
                //蜡烛
                for (int j = 0; j < drawModel.drawArray.count; j++)
                {
                    LJDrawRectModel *rectModel = drawModel.drawArray[j];
                    [LJKLineContextUtil lj_AddRect:drawModel.lineWidth fillColorRef:drawModel.fillColor.CGColor strokeColorRef:drawModel.lineColor.CGColor rect:rectModel.rect alpha:1];
                }
            }
        }
    }
    
    //文字
    for (int i = 0; i < self.kLineLayoutArray.count; i++)
    {
        LJDrawTextModel *textModel = self.kLineLayoutArray[i];
        if ([textModel isKindOfClass:[LJDrawTextModel class]])
        {
            [LJKLineContextUtil lj_AddText:textModel.text font:[UIFont systemFontOfSize:(textModel.fontSize)] fontColor:textModel.textColor alignment:textModel.textAlignment rect:textModel.textRect];
        }
    }
}

- (void)drawKPILayout:(NSMutableArray *)tempKPIDrawArray
{
    [self clearLayerArray:self.kpiLayoutArray];
    self.kpiLayoutArray = [[NSMutableArray alloc] init];
    
    for (LJDrawTextModel *textModel in tempKPIDrawArray)
    {
        CATextLayer *textLayer = [CATextLayer lj_kLineTextLayerWithString:textModel.text textColor:textModel.textColor fontSize:textModel.fontSize backgroundColor:[UIColor clearColor] frame:textModel.textRect];
        [self.layer addSublayer:textLayer];
        [self.kpiLayoutArray addObject:textLayer];
    }
}

/**
 重新修改倒计时UILabel
 */
- (void)updateIntervalCount
{
    if (self.intervalCount == INT_MAX) {
        dispatch_async(dispatch_get_main_queue(), ^{
            self.intervalLabel.hidden = YES;
        });
    }else{
        NSString *lineChar = @"";
        // 小时
        NSInteger house = self.intervalCount / 3600 % 3600;
        // 分
        NSInteger minute = self.intervalCount /60 % 60;
        // 秒
        NSInteger second = self.intervalCount %60;
        if (house !=0) {
            lineChar = [NSString stringWithFormat:@"%ld小时%ld分%ld秒",house,minute,second];
        } else if (house==0 && minute > 0) {
            lineChar = [NSString stringWithFormat:@"%ld分%ld秒",minute,second];
        } else{
            lineChar = [NSString stringWithFormat:@"%ld秒",second];
        }
        CGRect rect = [NSString jk_rectOfNSString:lineChar attribute:@{NSFontAttributeName:[UIFont systemFontOfSize:13]}];
        rect.size.width += 5;
        rect = CGRectMake(self.qsLayout.layoutWidth-rect.size.width-1, self.qsLayout.layoutHeight-self.qsLayout.layoutBottonHeight-rect.size.height-1, rect.size.width, rect.size.height);
        
        dispatch_async(dispatch_get_main_queue(), ^{
            self.intervalLabel.hidden = NO;
            self.intervalLabel.frame = rect;
            self.intervalLabel.text = lineChar;
            [self bringSubviewToFront:self.intervalLabel];
        });
    }
}


@end
