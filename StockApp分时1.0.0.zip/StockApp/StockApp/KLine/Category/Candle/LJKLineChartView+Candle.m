//
//  LJKLineChartView+Candle.m
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/5/31.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "LJKLineChartView+Candle.h"
#import "NSMutableArray+MaxMin.h"
#import "CATextLayer+kLineTextLayer.h"
#import "LJDrawTextModel.h"
#import "NSDate+JKUtilities.h"

@implementation LJKLineChartView (Candle)

- (void)calculateLJKLineCandleKPIModelPoint:(NSMutableArray *)tempRectArray tempLayoutArray:(NSMutableArray *)tempLayoutArray tempDrawChartArray:(NSMutableArray *)tempDrawChartArray
{
    //蜡烛图 最高价、最低价
    NSDictionary *maxMinDic = [tempDrawChartArray calculateCandleMaxMin];
    
    float kpiMax = [[maxMinDic objectForKey:LJ_KPI_Max] floatValue];
    float kpiMin = [[maxMinDic objectForKey:LJ_KPI_Min] floatValue];
    
    float maxHip = [[maxMinDic objectForKey:LJ_Max_Hip] floatValue];
    float minLop = [[maxMinDic objectForKey:LJ_Min_Lop] floatValue];
    
    [self calculateLJKLineCandleKPIModelPoint:kpiMax kpiMin:kpiMin maxHip:maxHip minLop:minLop tempRectArray:tempRectArray tempLayoutArray:tempLayoutArray tempDrawChartArray:tempDrawChartArray];
}

- (void)calculateLJKLineCandleKPIModelPoint:(float)kpiMax kpiMin:(float)kpiMin maxHip:(float)maxHip minLop:(float)minLop tempRectArray:(NSMutableArray *)tempRectArray tempLayoutArray:(NSMutableArray *)tempLayoutArray tempDrawChartArray:(NSMutableArray *)tempDrawChartArray{
    
    LJKLineModel *_maxModel = nil;
    LJKLineModel *_minModel = nil;
    
    float dotHeight = self.qsLayout.innerH / (kpiMax - kpiMin);
    if (isnan(dotHeight) || isinf(dotHeight)) {
        return;
    }
    
    for (int i = 0; i < tempDrawChartArray.count; i++) {
        LJKLineModel *model = [tempDrawChartArray objectAtIndex:i];
        model.candleModel.isMaxValue = model.candleModel.isMinValue = NO;
        
        //获得最大值 与 最小值
        if (!_maxModel && [model.hip floatValue] >= maxHip) {
            model.candleModel.isMaxValue = YES;
            _maxModel = model;
        }
        
        if (!_minModel && [model.lop floatValue] <= minLop) {
            model.candleModel.isMinValue = YES;
            _minModel = model;
        }
        //计算蜡烛图 位置
        if ([model.clp floatValue] > [model.op floatValue])
        {
            //上涨
            model.candleModel.upY = (kpiMax - [model.hip floatValue]) * dotHeight;
            model.candleModel.upHeight = (kpiMax - [model.clp floatValue]) * dotHeight - model.candleModel.upY;
            
            model.candleModel.pillarY = (kpiMax - [model.clp floatValue]) * dotHeight;
            model.candleModel.pillarHeight = (kpiMax - [model.op floatValue]) * dotHeight - model.candleModel.pillarY;
            
            model.candleModel.downY = (kpiMax - [model.op floatValue]) * dotHeight;
            model.candleModel.downHeight = (kpiMax - [model.lop floatValue]) * dotHeight - model.candleModel.downY;
            
            model.candleModel.kLineType = LJ_KLine_UP_Type;
        }else if ([model.clp floatValue] < [model.op floatValue])
        {
            //下跌
            
            model.candleModel.upY = (kpiMax - [model.hip floatValue]) * dotHeight;
            model.candleModel.upHeight = (kpiMax - [model.op floatValue]) * dotHeight - model.candleModel.upY;
            
            model.candleModel.pillarY = (kpiMax - [model.op floatValue]) * dotHeight;
            model.candleModel.pillarHeight = (kpiMax - [model.clp floatValue]) * dotHeight - model.candleModel.pillarY;
            
            model.candleModel.downY = (kpiMax - [model.clp floatValue]) * dotHeight;
            model.candleModel.downHeight = (kpiMax - [model.lop floatValue]) * dotHeight - model.candleModel.downY;
            
            model.candleModel.kLineType = LJ_KLine_Down_Type;
        }else{
            //等于
            
            model.candleModel.upY = (kpiMax - [model.hip floatValue]) * dotHeight;
            model.candleModel.upHeight = (kpiMax - [model.op floatValue]) * dotHeight - model.candleModel.upY;
            
            model.candleModel.pillarY = (kpiMax - [model.op floatValue]) * dotHeight;
            model.candleModel.pillarHeight = (kpiMax - [model.clp floatValue]) * dotHeight - model.candleModel.pillarY;
            
            model.candleModel.downY = (kpiMax - [model.clp floatValue]) * dotHeight;
            model.candleModel.downHeight = (kpiMax - [model.lop floatValue]) * dotHeight - model.candleModel.downY;
            
            model.candleModel.kLineType = LJ_KLine_Equality_Type;
        }
    }
    //绿色蜡烛图
    LJDrawModel *greeyCancelModel = [[LJDrawModel alloc] init];
    greeyCancelModel.lineWidth = self.kLineWidth <= 0.5 ? 0.4 : 0.8;
    greeyCancelModel.lineType = LJ_ENUM_DrawModel_Pillar;
    greeyCancelModel.fillColor = LJ_Blue_Color;
    greeyCancelModel.lineColor = LJ_Blue_Color;
    [tempRectArray addObject:greeyCancelModel];
    //红色蜡烛图
    LJDrawModel *redCancelModel = [[LJDrawModel alloc] init];
    redCancelModel.lineWidth = self.kLineWidth <= 0.5 ? 0.4 : 0.8;
    redCancelModel.lineType = LJ_ENUM_DrawModel_Pillar;
    redCancelModel.fillColor = [UIColor clearColor];
    redCancelModel.lineColor = LJ_Red_Color;
    [tempRectArray addObject:redCancelModel];
    //白色蜡烛图
    LJDrawModel *whiteCancelModel = [[LJDrawModel alloc] init];
    whiteCancelModel.lineWidth = self.kLineWidth <= 0.5 ? 0.4 : 0.8;
    whiteCancelModel.lineType = LJ_ENUM_DrawModel_Pillar;
    whiteCancelModel.fillColor = LJ_White_Color;
    whiteCancelModel.lineColor = LJ_White_Color;
    [tempRectArray addObject:whiteCancelModel];
    
    //绿色线
    LJDrawModel *greeyLineModel = [[LJDrawModel alloc] init];
    greeyLineModel.lineWidth = self.kLineWidth <= 0.5 ? 0.4 : 0.8;
    greeyLineModel.lineType = LJ_ENUM_DrawModel_Line;
    greeyLineModel.fillColor = [UIColor clearColor];
    greeyLineModel.lineColor = LJ_Blue_Color;
    [tempRectArray addObject:greeyLineModel];
    //红色线
    LJDrawModel *redLineModel = [[LJDrawModel alloc] init];
    redLineModel.lineWidth = self.kLineWidth <= 0.5 ? 0.4 : 0.8;
    redLineModel.lineType = LJ_ENUM_DrawModel_Line;
    redLineModel.fillColor = [UIColor clearColor];
    redLineModel.lineColor = LJ_Red_Color;
    [tempRectArray addObject:redLineModel];
    //白色线
    LJDrawModel *whiteLineModel = [[LJDrawModel alloc] init];
    whiteLineModel.lineWidth = self.kLineWidth <= 0.5 ? 0.4 : 0.8;
    whiteLineModel.lineType = LJ_ENUM_DrawModel_Line;
    whiteLineModel.fillColor = [UIColor clearColor];
    whiteLineModel.lineColor = LJ_White_Color;
    [tempRectArray addObject:whiteLineModel];
    
    float tempX = self.qsLayout.innerW;
    // 从上 至 下绘制，与其他绘图方式不一样；
    for(NSInteger idx = tempDrawChartArray.count-1; idx >= 0; idx--){
        
        tempX -= self.kLineWidth;
        
        LJKLineModel *model = [tempDrawChartArray objectAtIndex:idx];
        //蜡烛图 控件位置
        float x , y , w , h;
        x = tempX + (self.kLineWidth * self.kLineInterval);
        y = self.qsLayout.innerY + model.candleModel.pillarY;
        w = self.kLineWidth - ((self.kLineWidth * self.kLineInterval) * 2);
        h = model.candleModel.pillarHeight;
        
        //蜡烛X位置
        float centerLineX = tempX + (self.kLineWidth / 2);
        model.candleModel.candleX = centerLineX;
        
        LJDrawPointModel *upPointModel = nil;
        LJDrawPointModel *downPointModel = nil;
        //蜡烛图 上影线位置
        if (self.qsLayout.innerY + model.candleModel.upY < self.qsLayout.innerY + model.candleModel.pillarY) {
            
            CGPoint movePoint = CGPointMake(centerLineX, self.qsLayout.innerY + model.candleModel.upY);
            CGPoint toPoint = CGPointMake(centerLineX, self.qsLayout.innerY + model.candleModel.upY + model.candleModel.upHeight);
            
            upPointModel = [[LJDrawPointModel alloc] init];
            upPointModel.movePoint = movePoint;
            upPointModel.toPoint = toPoint;
        }
        //蜡烛图 下影线位置
        if ((self.qsLayout.innerY + model.candleModel.downY + model.candleModel.downHeight) > (self.qsLayout.innerY + model.candleModel.pillarY + model.candleModel.pillarHeight)) {
            
            CGPoint movePoint = CGPointMake(centerLineX, self.qsLayout.innerY + model.candleModel.downY);
            CGPoint toPoint = CGPointMake(centerLineX, self.qsLayout.innerY + model.candleModel.downY + model.candleModel.downHeight);
            
            downPointModel = [[LJDrawPointModel alloc] init];
            downPointModel.movePoint = movePoint;
            downPointModel.toPoint = toPoint;
        }
        LJDrawRectModel *rectModel = [[LJDrawRectModel alloc] init];
        rectModel.rect = CGRectMake(x, y, w, h);
        
        //定义线条颜色
        if (model.candleModel.kLineType == LJ_KLine_UP_Type)
        {
            if (upPointModel) {
                [redLineModel.drawArray addObject:upPointModel];
            }
            if (downPointModel) {
                [redLineModel.drawArray addObject:downPointModel];
            }
            [redCancelModel.drawArray addObject:rectModel];
        }else if (model.candleModel.kLineType == LJ_KLine_Down_Type)
        {
            if (upPointModel) {
                [greeyLineModel.drawArray addObject:upPointModel];
            }
            if (downPointModel) {
                [greeyLineModel.drawArray addObject:downPointModel];
            }
            [greeyCancelModel.drawArray addObject:rectModel];
        }else{
            if (upPointModel) {
                [whiteLineModel.drawArray addObject:upPointModel];
            }
            if (downPointModel) {
                [whiteLineModel.drawArray addObject:downPointModel];
            }
            [whiteCancelModel.drawArray addObject:rectModel];
        }
        //--------绘制最大值
        if (model.candleModel.isMaxValue) {
            NSString *blockFormat = [@"--->" stringByAppendingString:self.format];
            NSString *maxValue = [NSString stringWithFormat:blockFormat, [model.hip floatValue]];
            CGRect maxValueRect = [NSString jk_rectOfNSString:maxValue attribute:self.attribute];
            
            CGRect drawMaxRect = CGRectMake(0, 0, 0, 0);
            if (x - maxValueRect.size.width > 2) {
                blockFormat = [self.format stringByAppendingString:@"<---"];
                maxValue = [NSString stringWithFormat:blockFormat, [model.hip floatValue]];
                
                maxValueRect = [NSString jk_rectOfNSString:maxValue attribute:self.attribute];
                drawMaxRect.origin.x = x - maxValueRect.size.width;
            }else{
                drawMaxRect.origin.x = x + self.kLineWidth/2;
            }
            drawMaxRect.origin.y = self.qsLayout.innerY + model.candleModel.upY;
            drawMaxRect.size.width = maxValueRect.size.width;
            drawMaxRect.size.height = maxValueRect.size.height;
            
            
            LJDrawTextModel *textModel = [[LJDrawTextModel alloc] init];
            textModel.text = maxValue;
            textModel.textColor = LJ_Red_Color;
            textModel.textRect = drawMaxRect;
            [tempLayoutArray addObject:textModel];
        }
        //--------绘制最小值
        if (model.candleModel.isMinValue) {
            NSString *blockFormat = [@"--->" stringByAppendingString:self.format];
            NSString *minValue = [NSString stringWithFormat:blockFormat, [model.lop floatValue]];
            CGRect minValueRect = [NSString jk_rectOfNSString:minValue attribute:self.attribute];
            
            CGRect drawMinRect = CGRectMake(0, 0, 0, 0);
            if (x - minValueRect.size.width > 2) {
                
                blockFormat = [self.format stringByAppendingString:@"<---"];
                minValue = [NSString stringWithFormat:blockFormat, [model.lop floatValue]];
                
                minValueRect = [NSString jk_rectOfNSString:minValue attribute:self.attribute];
                drawMinRect.origin.x = x - minValueRect.size.width;
            }else{
                drawMinRect.origin.x = x + self.kLineWidth/2;
            }
            drawMinRect.origin.y = self.qsLayout.innerY + model.candleModel.downY + model.candleModel.downHeight - minValueRect.size.height;
            drawMinRect.size.width = minValueRect.size.width;
            drawMinRect.size.height = minValueRect.size.height;
            
            LJDrawTextModel *textModel = [[LJDrawTextModel alloc] init];
            textModel.text = minValue;
            textModel.textColor = LJ_Blue_Color;
            textModel.textRect = drawMinRect;
            [tempLayoutArray addObject:textModel];
        }
    };
    //绘制K线 横线 及 金额
    [self drawCandleHorLayer:kpiMax kpiMin:kpiMin tempRectArray:tempRectArray tempLayoutArray:tempLayoutArray tempDrawChartArray:tempDrawChartArray];
}

/**
 绘制蜡烛图横线
 
 @param kpiMax 最高价
 @param kpiMin 最低价
 */
- (void)drawCandleHorLayer:(float)kpiMax kpiMin:(float)kpiMin tempRectArray:(NSMutableArray *)tempRectArray tempLayoutArray:(NSMutableArray *)tempLayoutArray tempDrawChartArray:(NSMutableArray *)tempDrawChartArray {
    
    //生成 单位价格
    float unitPrice = (kpiMax - kpiMin) / self.kLineHorCount;
    float unitHeight = self.qsLayout.innerH / self.kLineHorCount;
    
    NSString *kpiMaxStr = [NSString stringWithFormat:self.format, kpiMax];
    //求得价格和百分比的rect
    CGRect textRect = [NSString jk_rectOfNSString:kpiMaxStr attribute:self.attribute];
    textRect.size.width += 4;
    
    LJDrawModel *lineDashModel = [[LJDrawModel alloc] init];
    lineDashModel.lineWidth = 0.2;
    lineDashModel.lineType = LJ_ENUM_DrawModel_Dash;
    lineDashModel.fillColor = [UIColor clearColor];
    lineDashModel.lineColor = LJ_Red_Color;
    [tempRectArray addObject:lineDashModel];
    
    for (int i = 0; i <= self.kLineHorCount; i++)
    {
        CGPoint startPoint = CGPointMake(self.qsLayout.x, self.qsLayout.innerY + unitHeight * i);
        CGPoint endPoint   = CGPointMake(self.qsLayout.x + self.qsLayout.w, self.qsLayout.innerY + unitHeight * i);
        
        float textRectY = i * unitHeight - textRect.size.height + self.qsLayout.innerY;
        if (i == 0) {
            textRectY += textRect.size.height;
        }
        CGRect leftRect = CGRectMake(self.qsLayout.innerX, textRectY, textRect.size.width, textRect.size.height);
        
        //设置第一根、最后一根线 不显示
        if (i != 0 && i != self.kLineHorCount)
        {
            LJDrawPointModel *lineModel = [[LJDrawPointModel alloc] init];
            lineModel.movePoint = startPoint;
            lineModel.toPoint = endPoint;
            [lineDashModel.drawArray addObject:lineModel];
        }
        LJDrawTextModel *textModel = [[LJDrawTextModel alloc] init];
        textModel.text = [NSString stringWithFormat:self.format, kpiMax - (i * unitPrice)];
        textModel.textColor = LJ_Red_Color;
        textModel.textRect = leftRect;
        [tempLayoutArray addObject:textModel];
    }
    if (tempDrawChartArray.count > 0) {
        [self drawCandleVerLayer:tempRectArray tempLayoutArray:tempLayoutArray tempDrawChartArray:tempDrawChartArray];
    }
}

- (void)drawCandleVerLayer:(NSMutableArray *)tempRectArray tempLayoutArray:(NSMutableArray *)tempLayoutArray tempDrawChartArray:(NSMutableArray *)tempDrawChartArray
{
    LJDrawModel *lineDashModel = [[LJDrawModel alloc] init];
    lineDashModel.lineWidth = 0.2;
    lineDashModel.lineType = LJ_ENUM_DrawModel_Dash;
    lineDashModel.fillColor = [UIColor clearColor];
    lineDashModel.lineColor = LJ_Red_Color;
    [tempRectArray addObject:lineDashModel];
    
    //------计算竖线位置 or 时间
    float verLatticeWidth = self.qsLayout.innerW / self.kLineVerCount;
    
    for (int i = 0; i <= self.kLineVerCount; i++)
    {
        LJDrawPointModel *lineModel = [[LJDrawPointModel alloc] init];
        lineModel.movePoint = CGPointMake(i * verLatticeWidth, self.qsLayout.innerY-self.qsLayout.topSpace);
        lineModel.toPoint = CGPointMake(i * verLatticeWidth, self.qsLayout.layoutHeight - self.qsLayout.layoutBottonHeight);
        
        if (i != 0 && i != self.kLineVerCount)
        {
            [lineDashModel.drawArray addObject:lineModel];
        }
        
        BOOL blg = true;
        int sumCount = self.qsLayout.innerW / self.kLineWidth;
        NSInteger index = floor(lineModel.movePoint.x / self.kLineWidth);
        if (sumCount > tempDrawChartArray.count) {
            
            if (index < sumCount-tempDrawChartArray.count) {
                blg = false;
            }else{
                index = index - (sumCount - tempDrawChartArray.count);
            }
        }
        if (blg)
        {
            index = index < 0 ? 0 : index;
            if (index >= tempDrawChartArray.count){
                index = tempDrawChartArray.count - 1;
            }
            LJKLineModel *kLineModel = [tempDrawChartArray objectAtIndex:index];
            
            //当前K线周期的日期格式
            NSString *periodYMH = @"HH:mm";//[LJSettingManager getKLinePeriodIndexYMD];
            //计算日期格式字符串width
            CGRect strRect = [NSString jk_rectOfNSString:periodYMH attribute:self.attribute];
            strRect.size.width += 1;
            float layoutBotton = self.qsLayout.layoutHeight - self.qsLayout.layoutBottonHeight;
        
            LJDrawTextModel *textModel = [[LJDrawTextModel alloc] init];
            CGRect chartRect;
            if (i == 0) {
                chartRect = CGRectMake(0, layoutBotton + 2, strRect.size.width, strRect.size.height);
                textModel.textAlignment = NSTextAlignmentLeft;
            }else if (i == self.kLineVerCount){
                chartRect = CGRectMake(self.qsLayout.w - strRect.size.width, layoutBotton + 2, strRect.size.width, strRect.size.height);
                textModel.textAlignment = NSTextAlignmentRight;
            }else{
                chartRect = CGRectMake(lineModel.movePoint.x - strRect.size.width/2, layoutBotton + 2, strRect.size.width, strRect.size.height);
                textModel.textAlignment = NSTextAlignmentCenter;
            }
            NSString *timeStr = [NSDate jk_timeStringWithFormat:@"yyyy-MM-dd HH:mm:ss" targetFormat:periodYMH strValue:kLineModel.dateChar];
            textModel.text = timeStr;
            textModel.textColor = LJ_Red_Color;
            textModel.textRect = chartRect;
            [tempLayoutArray addObject:textModel];
        }
    }
}

/**
 计算Candle 移动至X轴的值
 
 @param y y
 @return string
 */
- (NSString *)calculateCandleTickY:(float)y
{
    //Candle 最高价、最低价
    NSDictionary *maxMinDic = [self.drawChartArray calculateCandleMaxMin];
    float kpiMax = [[maxMinDic objectForKey:LJ_KPI_Max] floatValue];
    float kpiMin = [[maxMinDic objectForKey:LJ_KPI_Min] floatValue];
    
    double dotHeight = (kpiMax - kpiMin) / self.qsLayout.innerH;
    
    float value = kpiMax - ((y - self.qsLayout.innerY) * dotHeight);
    
    if (value > kpiMax) {
        value = kpiMax;
    }
    if (value < kpiMin) {
        value = kpiMin;
    }
    return [NSString jk_reviseString:value];
}


@end
