//
//  LJKLineChartView+Candle.h
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/5/31.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "LJKLineChartView.h"

@interface LJKLineChartView (Candle)

//绘制普K
- (void)calculateLJKLineCandleKPIModelPoint:(NSMutableArray *)tempRectArray tempLayoutArray:(NSMutableArray *)tempLayoutArray tempDrawChartArray:(NSMutableArray *)tempDrawChartArray;

- (void)calculateLJKLineCandleKPIModelPoint:(float)kpiMax kpiMin:(float)kpiMin maxHip:(float)maxHip minLop:(float)minLop tempRectArray:(NSMutableArray *)tempRectArray tempLayoutArray:(NSMutableArray *)tempLayoutArray tempDrawChartArray:(NSMutableArray *)tempDrawChartArray;

//绘制主图竖线 + 时间
- (void)drawCandleVerLayer:(NSMutableArray *)tempRectArray tempLayoutArray:(NSMutableArray *)tempLayoutArray tempDrawChartArray:(NSMutableArray *)tempDrawChartArray;

/**
 计算Candle 移动至X轴的值
 
 @param y y
 @return string
 */
- (NSString *)calculateCandleTickY:(float)y;

@end
