//
//  LJKLineChartView+Basics.m
//  YiFu
//
//  Created by 伍孟华 on 2018/8/16.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "LJKLineChartView+Basics.h"
#import "NSMutableArray+MaxMin.h"

#import "LJKLineChartView+Candle.h"
#import "LJKLineChartView+MA.h"
#import "LJKLineChartView+EMA.h"
#import "LJKLineChartView+BOLL.h"

#import "LJKLineChartView+MV.h"

#import "LJKLineChartView+MACD.h"
#import "LJKLineChartView+KDJ.h"
#import "LJKLineChartView+RSI.h"

#import "LJSettingManager.h"

@implementation LJKLineChartView (Basics)


/**
 初始化趋势指标
 */
- (void)setupQSLayer
{
    if (!self.qsLayout) {
        self.qsLayout = [[LJKLineLayoutModel alloc] init];
        self.qsLayout.layerScale = 0.5;
    }
    self.qsLayout.kpiArray = [[NSMutableArray alloc] init];
    //普K
    LJKLineCandleKPIModel *candleKPIModel = [[LJKLineCandleKPIModel alloc] init];
    candleKPIModel.kpiType = LJ_KLine_QS_K_Type;
    [self.qsLayout.kpiArray addObject:candleKPIModel];
    
    NSMutableArray *kpiArray = [LJSettingManager getKLineKPITreeList];
    
    LJKLineKPITreeModel *maKPITreeModel = [self findKLineKPITreeType:kpiArray treeType:LJKLineKPITreeType_QS kpiName:@"MA"];
    if (maKPITreeModel && maKPITreeModel.isShow == 1) {
        //MA指标
        LJKLineMAKPIModel *maKPIModel = [[LJKLineMAKPIModel alloc] init];
        maKPIModel.kpiType = LJ_KLine_QS_MA_Type;
        
        NSArray *paramArray = maKPITreeModel.paramArray;
        maKPIModel.ma5 = [[self findKLineKPITreeStairName:paramArray paramName:@"MA5"].paramValue floatValue];
        maKPIModel.ma10 = [[self findKLineKPITreeStairName:paramArray paramName:@"MA10"].paramValue floatValue];
        maKPIModel.ma20 = [[self findKLineKPITreeStairName:paramArray paramName:@"MA20"].paramValue floatValue];
        maKPIModel.ma40 = [[self findKLineKPITreeStairName:paramArray paramName:@"MA40"].paramValue floatValue];
        
        maKPIModel.ma5Hex = @"#ffffff";
        maKPIModel.ma10Hex = @"#ffc400";
        maKPIModel.ma20Hex = @"#5015be";
        maKPIModel.ma40Hex = @"#3bff00";
        [self.qsLayout.kpiArray addObject:maKPIModel];
    }
    
    LJKLineKPITreeModel *emaKPITreeModel = [self findKLineKPITreeType:kpiArray treeType:LJKLineKPITreeType_QS kpiName:@"EMA"];
    if (emaKPITreeModel && emaKPITreeModel.isShow == 1) {
        //EMA指标
        LJKLineEMAKPIModel *emaKPIModel = [[LJKLineEMAKPIModel alloc] init];
        emaKPIModel.kpiType = LJ_KLine_QS_EMA_Type;
        
        NSArray *paramArray = emaKPITreeModel.paramArray;
        emaKPIModel.ema5 = [[self findKLineKPITreeStairName:paramArray paramName:@"EMA5"].paramValue floatValue];
        emaKPIModel.ema10 = [[self findKLineKPITreeStairName:paramArray paramName:@"EMA10"].paramValue floatValue];
        emaKPIModel.ema20 = [[self findKLineKPITreeStairName:paramArray paramName:@"EMA20"].paramValue floatValue];
        emaKPIModel.ema40 = [[self findKLineKPITreeStairName:paramArray paramName:@"EMA40"].paramValue floatValue];
        
        emaKPIModel.ema5Hex = @"#ffffff";
        emaKPIModel.ema10Hex = @"#ffc400";
        emaKPIModel.ema20Hex = @"#5f00d3";
        emaKPIModel.ema40Hex = @"#3bff00";
        [self.qsLayout.kpiArray addObject:emaKPIModel];
    }
    
    LJKLineKPITreeModel *bollKPITreeModel = [self findKLineKPITreeType:kpiArray treeType:LJKLineKPITreeType_QS kpiName:@"BOLL"];
    if (bollKPITreeModel && bollKPITreeModel.isShow == 1) {
        //BOLL 指标
        LJKLineBOLLKPIModel *bollKPIModel = [[LJKLineBOLLKPIModel alloc] init];
        bollKPIModel.kpiType = LJ_KLine_QS_BOLL_Type;
        
        NSArray *paramArray = bollKPITreeModel.paramArray;
        bollKPIModel.bollMa = [[self findKLineKPITreeStairName:paramArray paramName:@"N"].paramValue floatValue];
        bollKPIModel.bollMb = [[self findKLineKPITreeStairName:paramArray paramName:@"M"].paramValue floatValue];
        bollKPIModel.bollP = [[self findKLineKPITreeStairName:paramArray paramName:@"P"].paramValue floatValue];
        
        bollKPIModel.bollUpHex = @"#9400D3";
        bollKPIModel.bollMbHex = @"#ffffff";
        bollKPIModel.bollDnHex = @"#ffc400";
        [self.qsLayout.kpiArray addObject:bollKPIModel];
    }
        
    self.qsLayout.layoutWidth = self.width;
    self.qsLayout.layoutHeight = self.height;
    
    self.qsLayout.leftSpace = 0;
    self.qsLayout.rightSpace = 10;
    self.qsLayout.topSpace = 1;
    self.qsLayout.bottonSpace = 1;
    [self.qsLayout calculateLayerModel];
}

- (void)setupQSLayerHeight:(float)kpiHeight
{
    self.qsLayout.kpiHeight = kpiHeight;
    [self.qsLayout calculateLayerModel];
}

- (void)setupQSHide:(BOOL)hide
{
    self.qsLayout.isHide = hide;
    [self setupLayerScale];
}

/**
 初始化量仓指标
 */
- (void)setupLCLayer
{
    if (!self.lcLayout) {
        self.lcLayout = [[LJKLineLayoutModel alloc] init];
        self.lcLayout.layerScale = 0.2;
    }
    self.lcLayout.kpiArray = [[NSMutableArray alloc] init];
    
//    LJKLineKPITreeModel *kpiTreeModel = [[LJKLineKPITreeModel alloc] init];
//    kpiTreeModel.treeType = LJKLineKPITreeType_LC;
//    NSMutableArray *lcKPIArray = [LJSQLManager findKLineKPITreeModel:kpiTreeModel];
    NSMutableArray *kpiArray = [LJSettingManager getKLineKPITreeList];
    
    LJKLineKPITreeModel *mvKPITreeModel = [self findKLineKPITreeType:kpiArray treeType:LJKLineKPITreeType_LC kpiName:@"MV"];
    if (mvKPITreeModel && mvKPITreeModel.isShow == 1)
    {
        //MV 指标
        LJKLineMVKPIModel *mvKPIModel = [[LJKLineMVKPIModel alloc] init];
        mvKPIModel.kpiType = LJ_KLine_LC_MV_Type;
        
        NSArray *paramArray = mvKPITreeModel.paramArray;
        mvKPIModel.mv5 = [[self findKLineKPITreeStairName:paramArray paramName:@"N"].paramValue floatValue];
        mvKPIModel.mv5Hex = @"#ffffff";
        
        mvKPIModel.mv10 = [[self findKLineKPITreeStairName:paramArray paramName:@"M"].paramValue floatValue];
        mvKPIModel.mv10Hex = @"#ffc400";
        [self.lcLayout.kpiArray addObject:mvKPIModel];
    }
    self.lcLayout.layoutWidth = self.width;
    self.lcLayout.layoutHeight = self.height;
    
    self.lcLayout.leftSpace = 0;
    self.lcLayout.rightSpace = 10;
    self.lcLayout.topSpace = 0;
    self.lcLayout.bottonSpace = 1;
    
    self.lcLayout.y = self.qsLayout.y + self.qsLayout.h;
    [self.lcLayout calculateLayerModel];
}

- (void)setupLCLayerHeight:(float)kpiHeight
{
    self.lcLayout.kpiHeight = kpiHeight;
    [self.lcLayout calculateLayerModel];
}

- (void)setupLCHide:(BOOL)hide
{
    self.lcLayout.isHide = hide;
    [self setupLayerScale];
}

/**
 初始化摆动指标
 */
- (void)setupBDLayer
{
    if (!self.bdLayout)
    {
        self.bdLayout = [[LJKLineLayoutModel alloc] init];
        self.bdLayout.layerScale = 0.3;
    }
    self.bdLayout.kpiArray = [[NSMutableArray alloc] init];
    
//    LJKLineKPITreeModel *kpiTreeModel = [[LJKLineKPITreeModel alloc] init];
//    kpiTreeModel.treeType = LJKLineKPITreeType_BD;
//    NSMutableArray *bdKPIArray = [LJSQLManager findKLineKPITreeModel:kpiTreeModel];
    NSMutableArray *kpiArray = [LJSettingManager getKLineKPITreeList];
    
    LJKLineKPITreeModel *macdKPITreeModel = [self findKLineKPITreeType:kpiArray treeType:LJKLineKPITreeType_BD kpiName:@"MACD"];
    if (macdKPITreeModel && macdKPITreeModel.isShow == 1)
    {
        //MACD 指标
        LJKLineMACDKPIModel *macdKPIModel = [[LJKLineMACDKPIModel alloc] init];
        macdKPIModel.kpiType = LJ_KLine_BD_MACD_Type;
        
        NSArray *paramArray = macdKPITreeModel.paramArray;
        macdKPIModel.shortEMA = [[self findKLineKPITreeStairName:paramArray paramName:@"SHORT"].paramValue floatValue];
        macdKPIModel.longEMA = [[self findKLineKPITreeStairName:paramArray paramName:@"LONG"].paramValue floatValue];
        macdKPIModel.m = [[self findKLineKPITreeStairName:paramArray paramName:@"M"].paramValue floatValue];
        
        //dif、dea 颜色值
        macdKPIModel.difHex = @"#ffffff";
        macdKPIModel.deaHex = @"#ffc400";
        macdKPIModel.macdHex = @"#9400D3";
        
        //macd上涨、macd下跌 颜色值
        macdKPIModel.macdUpHex = @"#ff1400";
        macdKPIModel.macdDNHex = @"#00FBFF";
        [self.bdLayout.kpiArray addObject:macdKPIModel];
    }
    
    LJKLineKPITreeModel *kdjKPITreeModel = [self findKLineKPITreeType:kpiArray treeType:LJKLineKPITreeType_BD kpiName:@"KDJ"];
    if (kdjKPITreeModel && kdjKPITreeModel.isShow == 1)
    {
        //KDJ 指标
        LJKLineKDJKPIModel *kdjKPIModel = [[LJKLineKDJKPIModel alloc] init];
        kdjKPIModel.kpiType = LJ_KLine_BD_KDJ_Type;
        
        NSArray *paramArray = kdjKPITreeModel.paramArray;
        kdjKPIModel.n = [[self findKLineKPITreeStairName:paramArray paramName:@"N"].paramValue floatValue];
        kdjKPIModel.m1 = [[self findKLineKPITreeStairName:paramArray paramName:@"M1"].paramValue floatValue];
        kdjKPIModel.m2 = [[self findKLineKPITreeStairName:paramArray paramName:@"M2"].paramValue floatValue];
        
        //n、m1、m2 颜色值
        kdjKPIModel.nHex = @"#ffffff";
        kdjKPIModel.m1Hex = @"#ffc400";
        kdjKPIModel.m2Hex = @"#f200ff";
        [self.bdLayout.kpiArray addObject:kdjKPIModel];
    }
    
    LJKLineKPITreeModel *rsiKPITreeModel = [self findKLineKPITreeType:kpiArray treeType:LJKLineKPITreeType_BD kpiName:@"RSI"];
    if (rsiKPITreeModel && rsiKPITreeModel.isShow == 1)
    {
        //RSI 指标
        LJKLineRSIKPIModel *rsiKPIModel = [[LJKLineRSIKPIModel alloc] init];
        rsiKPIModel.kpiType = LJ_KLine_BD_RSI_Type;
        
        NSArray *paramArray = rsiKPITreeModel.paramArray;
        rsiKPIModel.n1 = [[self findKLineKPITreeStairName:paramArray paramName:@"N1"].paramValue floatValue];
        rsiKPIModel.n2 = [[self findKLineKPITreeStairName:paramArray paramName:@"N2"].paramValue floatValue];
        rsiKPIModel.n3 = [[self findKLineKPITreeStairName:paramArray paramName:@"N3"].paramValue floatValue];
        
        rsiKPIModel.n1Hex = @"#ffffff";
        rsiKPIModel.n2Hex = @"#ffc400";
        rsiKPIModel.n3Hex = @"#f200ff";
        [self.bdLayout.kpiArray addObject:rsiKPIModel];
    }
    self.bdLayout.layoutWidth = self.width;
    self.bdLayout.layoutHeight = self.height;
    
    self.bdLayout.leftSpace = 0;
    self.bdLayout.rightSpace = 10;
    self.bdLayout.topSpace = 8;
    self.bdLayout.bottonSpace = 8;
    
    self.bdLayout.y = self.lcLayout.y + self.lcLayout.h;
    [self.bdLayout calculateLayerModel];
}

- (void)setupBDLayerHeight:(float)kpiHeight
{
    self.bdLayout.kpiHeight = kpiHeight;
    [self.bdLayout calculateLayerModel];
}

- (void)setupBDHide:(BOOL)hide
{
    self.bdLayout.isHide = hide;
    [self setupLayerScale];
}

- (void)setupLayerScale
{
    //趋势指标永不隐藏
    BOOL isLCHide = NO;
    BOOL isBDHide = NO;
    
    //量仓指标---
    if (self.lcLayout.isHide) {
        isLCHide = YES;
    }else{
        isLCHide = NO;
    }
    if (!self.lcLayout.kpiArray || self.lcLayout.kpiArray.count == 0) {
        //如果不包含量仓指标也需要隐藏
        isLCHide = YES;
    }
    
    //摆动指标---
    if (self.bdLayout.isHide) {
        isBDHide = YES;
    }else{
        isBDHide = NO;
    }
    if (!self.bdLayout.kpiArray || self.bdLayout.kpiArray.count == 0) {
        //如果不包含摆动指标也需要隐藏
        isBDHide = YES;
    }
    if (isLCHide && isBDHide) {
        //量仓 or 摆动 都隐藏
        self.qsLayout.layerScale = 1;
        self.lcLayout.layerScale = 0;
        self.bdLayout.layerScale = 0;
    }else if (!isLCHide && isBDHide) {
        //显示量仓，隐藏摆动
        self.qsLayout.layerScale = 0.7;
        self.lcLayout.layerScale = 0.3;
        self.bdLayout.layerScale = 0;
    }else if (isLCHide && !isBDHide) {
        //隐藏量仓，摆动显示
        self.qsLayout.layerScale = 0.7;
        self.lcLayout.layerScale = 0;
        self.bdLayout.layerScale = 0.3;
    }else{
        //正常显示
        self.qsLayout.layerScale = 0.6;
        self.lcLayout.layerScale = 0.17;
        self.bdLayout.layerScale = 0.23;
    }
    if (self.qsLayout) {
        //重置趋势高度
        [self.qsLayout calculateLayerModel];
    }
    if (self.lcLayout) {
        //重置量仓位置
        self.lcLayout.y = self.qsLayout.y + self.qsLayout.h;
        [self.lcLayout calculateLayerModel];
    }
    if (self.bdLayout) {
        //重置摆动位置
        self.bdLayout.y = self.lcLayout.y + self.lcLayout.h;
        [self.bdLayout calculateLayerModel];
    }
}

//趋势
-(NSInteger)qsKPIIndex
{
    NSString *qsKPI = [[NSUserDefaults standardUserDefaults] stringForKey:LJ_QSKPIIndex];
    if (qsKPI.length == 0) {
        //默认为1， 1=MA5
        return 1;
    }else{
        return qsKPI.integerValue;
    }
}
- (void)setQsKPIIndex:(NSInteger)qsKPIIndex
{
    [[NSUserDefaults standardUserDefaults] setObject:@(qsKPIIndex).stringValue forKey:LJ_QSKPIIndex];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

//量仓
-(NSInteger)lcKPIIndex
{
    NSString *lcKPI = [[NSUserDefaults standardUserDefaults] stringForKey:LJ_LCKPIIndex];
    if (lcKPI.length == 0) {
        return 0;
    }else{
        return lcKPI.integerValue;
    }
}
- (void)setLcKPIIndex:(NSInteger)lcKPIIndex
{
    [[NSUserDefaults standardUserDefaults] setObject:@(lcKPIIndex).stringValue forKey:LJ_LCKPIIndex];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

//摆动
-(NSInteger)bdKPIIndex
{
    NSString *bdKPI = [[NSUserDefaults standardUserDefaults] stringForKey:LJ_BDKPIIndex];
    if (bdKPI.length == 0) {
        return 0;
    }else{
        return bdKPI.integerValue;
    }
}
- (void)setBdKPIIndex:(NSInteger)bdKPIIndex
{
    [[NSUserDefaults standardUserDefaults] setObject:@(bdKPIIndex).stringValue forKey:LJ_BDKPIIndex];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

/**
 计算K线移动值X轴趋势指标对应值
 
 @param y y
 @return string
 */
- (NSString *)calculateKLine_QSKPI:(float)y
{
    NSString *kpiValue = @"0";
    if (self.qsKPIModel)
    {
        if ([self.qsKPIModel isKindOfClass:[LJKLineCandleKPIModel class]])
        {
            //普K
            kpiValue = [self calculateCandleTickY:y];
        }else if ([self.qsKPIModel isKindOfClass:[LJKLineMAKPIModel class]])
        {
            // MA指标
            kpiValue = [self calculateMATickY:y];
        }else if ([self.qsKPIModel isKindOfClass:[LJKLineEMAKPIModel class]])
        {
            // EMA指标
            kpiValue = [self calculateEMATickY:y];
        }else if ([self.qsKPIModel isKindOfClass:[LJKLineBOLLKPIModel class]])
        {
            // BOLL指标
            kpiValue = [self calculateBOLLTickY:y];
        } 
    }
    return kpiValue;
}

#pragma mark - 画线分析
//----------------------------------------------------------------
/**
 根据价格计算Y轴位置
 
 @param price 价格
 @return Y轴
 */
- (float)findTImeLayerAtWill_Price_Clp:(float)price
{
    NSDictionary *maxMinDic = [self calculateKLine_QSMaxMinKPI];
    float kpiMax = [[maxMinDic objectForKey:LJ_KPI_Max] floatValue];
    float kpiMin = [[maxMinDic objectForKey:LJ_KPI_Min] floatValue];
    double dotHeight = self.qsLayout.innerH / (kpiMax - kpiMin);
    return ((kpiMax - price) * dotHeight);
}

/**
 根据K线 X轴位置获缩影
 
 @param x X轴位置
 @return 缩影对应对象
 */
- (LJKLineModel *)getKLinePointModel:(CGFloat)x
{
    NSInteger index = floor(x / self.kLineWidth);
    if (index >= self.drawChartArray.count){
        index = self.drawChartArray.count - 1;
    }
    index = index < 0 ? 0 : index;
    return [self.drawChartArray objectAtIndex:index];
}

/**
 返回趋势指标最大值、最小值

 @return NSDictionary
 */
- (NSDictionary *)calculateKLine_QSMaxMinKPI
{
    if ([self.qsKPIModel isKindOfClass:[LJKLineCandleKPIModel class]])
    {
        //普K
        return [self.drawChartArray calculateCandleMaxMin];
    }else if ([self.qsKPIModel isKindOfClass:[LJKLineMAKPIModel class]])
    {
        // MA指标
        return [self.drawChartArray calculateMAMaxMin];
    }else if ([self.qsKPIModel isKindOfClass:[LJKLineEMAKPIModel class]])
    {
        // EMA指标
        return [self.drawChartArray calculateEMAMaxMin];
    }else if ([self.qsKPIModel isKindOfClass:[LJKLineBOLLKPIModel class]])
    {
        // BOLL指标
        return [self.drawChartArray calculateBOLLMaxMin];
    }
    return nil;
}


/**
 根据Y值计算价格

 @param y Y
 @return 价格
 */
- (CGFloat)calculateKLine_QS_Y_Price:(CGFloat)y
{
    //Candle 最高价、最低价
    NSDictionary *maxMinDic = [self calculateKLine_QSMaxMinKPI];
    float kpiMax = [[maxMinDic objectForKey:LJ_KPI_Max] floatValue];
    float kpiMin = [[maxMinDic objectForKey:LJ_KPI_Min] floatValue];
    
    double dotHeight = (kpiMax - kpiMin) / self.qsLayout.innerH;
    
    CGFloat value = kpiMax - (y * dotHeight);
    return value;
}

//----------------------------------------------------------------

/**
 计算K线移动值X轴趋势指标对应值
 
 @param y y
 @return string
 */
- (NSString *)calculateKLine_LCKPI:(float)y
{
    NSString *kpiValue = @"0";
    if (self.lcKPIModel) {
        
        if ([self.lcKPIModel isKindOfClass:[LJKLineMVKPIModel class]]){
            //MV 指标
            kpiValue = [self calculateMVTickY:y];
        }
    }
    return kpiValue;
}
/**
 计算K线移动值X轴趋势指标对应值or价格
 
 @param y y
 @return string
 */
- (NSString *)calculateKLine_BDKPI:(float)y
{
    NSString *kpiValue = @"0";
    if (self.bdKPIModel) {
        
        if ([self.bdKPIModel isKindOfClass:[LJKLineMACDKPIModel class]])
        {
            //MACD 指标
            kpiValue = [self calculateMACDTickY:y];
        }else if ([self.bdKPIModel isKindOfClass:[LJKLineKDJKPIModel class]])
        {
            //KDJ 指标
            kpiValue = [self calculateKDJTickY:y];
        }else if ([self.bdKPIModel isKindOfClass:[LJKLineRSIKPIModel class]])
        {
            //RSI 指标
            kpiValue = [self calculateRSITickY:y];
        }
    }
    return kpiValue;
}

- (LJKLineKPITreeStairModel *)findKLineKPITreeStairName:(NSArray *)treeStairArray paramName:(NSString *)paramName
{
    LJKLineKPITreeStairModel *paramModel = nil;
    if (treeStairArray && treeStairArray.count > 0) {
        for (int i = 0; i < treeStairArray.count; i++) {
            LJKLineKPITreeStairModel *stairModel = treeStairArray[i];
            if ([stairModel.paramName isEqualToString:paramName]) {
                paramModel = stairModel;
                break;
            }
        }
    }
    return paramModel;
}

- (LJKLineKPITreeModel *)findKLineKPITreeType:(NSMutableArray *)treeArray treeType:(NSInteger)treeType kpiName:(NSString *)kpiName
{
    LJKLineKPITreeModel *treeModel = nil;
    if (treeArray && treeArray.count > 0) {
        for (int i = 0; i < treeArray.count; i++) {
            LJKLineKPITreeModel *kpiTreeModel = treeArray[i];
            if (kpiTreeModel.treeType == treeType && [kpiTreeModel.kpiName isEqualToString:kpiName]) {
                treeModel = kpiTreeModel;
                break;
            }
        }
    }
    return treeModel;
}

/**
 清除画线

 @param layerArray layerArray
 */
- (void)clearLayerArray:(NSMutableArray *)layerArray
{
    if (layerArray) {
        [layerArray enumerateObjectsUsingBlock:^(CAShapeLayer * _Nonnull layer, NSUInteger idx, BOOL * _Nonnull stop) {
            if ([layer isKindOfClass:[CALayer class]]) {
                [layer removeFromSuperlayer];
                layer.sublayers = nil;
                layer = nil;
            }
        }];
    }
    [layerArray removeAllObjects];
    layerArray = nil;
}


@end
