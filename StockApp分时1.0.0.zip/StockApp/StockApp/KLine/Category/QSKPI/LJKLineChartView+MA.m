//
//  LJKLineChartView+MA.m
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/5/31.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "LJKLineChartView+MA.h"
#import "NSMutableArray+MaxMin.h"
#import "LJKLineChartView+Candle.h"
#import "UIColor+JKHEX.h"
#import "LJDrawTextModel.h"
#import "CATextLayer+kLineTextLayer.h"

@implementation LJKLineChartView (MA)

- (void)calculateLJKLineMAKPIModelPoint:(NSMutableArray *)tempRectArray tempLayoutArray:(NSMutableArray *)tempLayoutArray tempDrawChartArray:(NSMutableArray *)tempDrawChartArray
{
    
    //MA 最高价、最低价
    NSDictionary *maxMinDic = [tempDrawChartArray calculateMAMaxMin];
    
    float kpiMax = [[maxMinDic objectForKey:LJ_KPI_Max] floatValue];
    float kpiMin = [[maxMinDic objectForKey:LJ_KPI_Min] floatValue];
    
    float maxHip = [[maxMinDic objectForKey:LJ_Max_Hip] floatValue];
    float minLop = [[maxMinDic objectForKey:LJ_Min_Lop] floatValue];
    
    float dotHeight = self.qsLayout.innerH / (kpiMax - kpiMin);
    if (isinf(dotHeight) || isnan(dotHeight)) {
        return;
    }
    
    //计算蜡烛图坐标
    [self calculateLJKLineCandleKPIModelPoint:kpiMax kpiMin:kpiMin maxHip:maxHip minLop:minLop tempRectArray:tempRectArray tempLayoutArray:tempLayoutArray tempDrawChartArray:tempDrawChartArray];
    
    if (![self.qsKPIModel isKindOfClass:[LJKLineMAKPIModel class]]){
        return;
    }
    
    //计算MA坐标
    for (int i = 0; i < tempDrawChartArray.count; i++) {
        LJKLineModel *model = [tempDrawChartArray objectAtIndex:i];
        LJKLineMAModel *maModel = (LJKLineMAModel *)model.qsModel;
        if ([model.qsModel isKindOfClass:[LJKLineMAModel class]]) {
            if (maModel.ma5.length > 0) {
                maModel.ma5_Y = (kpiMax - [maModel.ma5 floatValue]) * dotHeight;
            }
            if (maModel.ma10.length > 0) {
                maModel.ma10_Y = (kpiMax - [maModel.ma10 floatValue]) * dotHeight;
            }
            if (maModel.ma20.length > 0) {
                maModel.ma20_Y = (kpiMax - [maModel.ma20 floatValue]) * dotHeight;
            }
            if (maModel.ma40.length > 0) {
                maModel.ma40_Y = (kpiMax - [maModel.ma40 floatValue]) * dotHeight;
            }
        }
    }
    LJKLineMAKPIModel *maKPIModel = ((LJKLineMAKPIModel *)self.qsKPIModel);
    //
    LJDrawModel *ma5LineModel = [[LJDrawModel alloc] init];
    ma5LineModel.lineWidth = 1.0;
    ma5LineModel.fillColor = [UIColor clearColor];
    ma5LineModel.lineColor = [UIColor jk_colorWithHexString:maKPIModel.ma5Hex];
    [tempRectArray addObject:ma5LineModel];
    
    LJDrawModel *ma10LineModel = [[LJDrawModel alloc] init];
    ma10LineModel.lineWidth = 1.0;
    ma10LineModel.fillColor = [UIColor clearColor];
    ma10LineModel.lineColor = [UIColor jk_colorWithHexString:maKPIModel.ma10Hex];
    [tempRectArray addObject:ma10LineModel];
    
    LJDrawModel *ma20LineModel = [[LJDrawModel alloc] init];
    ma20LineModel.lineWidth = 1.0;
    ma20LineModel.fillColor = [UIColor clearColor];
    ma20LineModel.lineColor = [UIColor jk_colorWithHexString:maKPIModel.ma20Hex];
    [tempRectArray addObject:ma20LineModel];
    
    LJDrawModel *ma40LineModel = [[LJDrawModel alloc] init];
    ma40LineModel.lineWidth = 1.0;
    ma40LineModel.fillColor = [UIColor clearColor];
    ma40LineModel.lineColor = [UIColor jk_colorWithHexString:maKPIModel.ma40Hex];
    [tempRectArray addObject:ma40LineModel];
    
    float tempX = self.qsLayout.innerW;
    float downTempX = tempX;
    // 从上 至 下绘制，与其他绘图方式不一样；
    for(NSInteger idx = tempDrawChartArray.count-1; idx >= 0; idx--){
        
        tempX -= self.kLineWidth;
        
        LJKLineModel *model = [tempDrawChartArray objectAtIndex:idx];
        LJKLineMAModel *maModel = (LJKLineMAModel *)model.qsModel;
        if ([model.qsModel isKindOfClass:[LJKLineMAModel class]]) {
            LJKLineModel *downModel = nil;
            LJKLineMAModel *downMAModel = nil;
            if (idx - 1 >= 0) {
                downModel = [tempDrawChartArray objectAtIndex:idx - 1];
                downMAModel = (LJKLineMAModel *)downModel.qsModel;
                
                downTempX = tempX - self.kLineWidth;
            }
            
            //绘制MA5均线
            if (maModel.ma5.length > 0 && downMAModel.ma5.length > 0) {
                
                CGPoint moveToPoint = CGPointMake(tempX + (self.kLineWidth/2), self.qsLayout.innerY + maModel.ma5_Y);
                CGPoint toPoint = CGPointMake(downTempX + (self.kLineWidth/2), self.qsLayout.innerY + downMAModel.ma5_Y);
                
                LJDrawPointModel *drawPoint = [[LJDrawPointModel alloc] init];
                drawPoint.movePoint = moveToPoint;
                drawPoint.toPoint = toPoint;
                [ma5LineModel.drawArray addObject:drawPoint];
            }
            
            //绘制MA10均线
            if (maModel.ma10.length > 0 && downMAModel.ma10.length > 0) {
                
                CGPoint moveToPoint = CGPointMake(tempX + (self.kLineWidth/2), self.qsLayout.innerY + maModel.ma10_Y);
                CGPoint toPoint = CGPointMake(downTempX + (self.kLineWidth/2), self.qsLayout.innerY + downMAModel.ma10_Y);
                
                LJDrawPointModel *drawPoint = [[LJDrawPointModel alloc] init];
                drawPoint.movePoint = moveToPoint;
                drawPoint.toPoint = toPoint;
                [ma10LineModel.drawArray addObject:drawPoint];
            }
            
            //绘制MA20均线
            if (maModel.ma20.length > 0 && downMAModel.ma20.length > 0) {
                
                CGPoint moveToPoint = CGPointMake(tempX + (self.kLineWidth/2), self.qsLayout.innerY + maModel.ma20_Y);
                CGPoint toPoint = CGPointMake(downTempX + (self.kLineWidth/2), self.qsLayout.innerY + downMAModel.ma20_Y);
                
                LJDrawPointModel *drawPoint = [[LJDrawPointModel alloc] init];
                drawPoint.movePoint = moveToPoint;
                drawPoint.toPoint = toPoint;
                [ma20LineModel.drawArray addObject:drawPoint];
            }
            
            //绘制MA40均线
            if (maModel.ma40.length > 0 && downMAModel.ma40.length > 0) {
                
                CGPoint moveToPoint = CGPointMake(tempX + (self.kLineWidth/2), self.qsLayout.innerY + maModel.ma40_Y);
                CGPoint toPoint = CGPointMake(downTempX + (self.kLineWidth/2), self.qsLayout.innerY + downMAModel.ma40_Y);
                
                LJDrawPointModel *drawPoint = [[LJDrawPointModel alloc] init];
                drawPoint.movePoint = moveToPoint;
                drawPoint.toPoint = toPoint;
                [ma40LineModel.drawArray addObject:drawPoint];
            }
        }
    };
}

/**
 计算MA顶部高度
 */
- (float )calculateMATopKPIHeight:(LJKLineModel *)lineModel isDraw:(BOOL)isDraw tempKPIDrawArray:(NSMutableArray *)tempKPIDrawArray
{
    LJKLineMAKPIModel *maKPIModel = ((LJKLineMAKPIModel *)self.qsKPIModel);
    if (![lineModel.qsModel isKindOfClass:[LJKLineMAModel class]]) {
        return 0;
    }
    LJKLineMAModel *maModel = (LJKLineMAModel *)lineModel.qsModel;
    
    LJDrawTextModel *fontModelMA = [[LJDrawTextModel alloc] init];
    fontModelMA.text = [NSString stringWithFormat:@"MA(%d,%d,%d,%d)",(int)maKPIModel.ma5,(int)maKPIModel.ma10,(int)maKPIModel.ma20,(int)maKPIModel.ma40];
    fontModelMA.textColor = [UIColor jk_colorWithHexString:maKPIModel.ma10Hex];
    fontModelMA.fontSize = self.attfontSize;
    LJDrawTextModel *fontModelMA5 = [[LJDrawTextModel alloc] init];
    fontModelMA5.text = [NSString stringWithFormat:@"MA%ld:%@",(NSInteger)maKPIModel.ma5,[NSString stringWithFormat:self.format, [maModel.ma5 floatValue]]];
    fontModelMA5.textColor = [UIColor jk_colorWithHexString:maKPIModel.ma5Hex];
    fontModelMA5.fontSize = self.attfontSize;
    
    LJDrawTextModel *fontModelMA10 = [[LJDrawTextModel alloc] init];
    fontModelMA10.text = [NSString stringWithFormat:@"MA%ld:%@",(NSInteger)maKPIModel.ma10,[NSString stringWithFormat:self.format, [maModel.ma10 floatValue]]];
    fontModelMA10.textColor = [UIColor jk_colorWithHexString:maKPIModel.ma10Hex];
    fontModelMA10.fontSize = self.attfontSize;
    
    LJDrawTextModel *fontModelMA20 = [[LJDrawTextModel alloc] init];
    fontModelMA20.text = [NSString stringWithFormat:@"MA%ld:%@",(NSInteger)maKPIModel.ma20,[NSString stringWithFormat:self.format, [maModel.ma20 floatValue]]];
    //[@"MA20:" stringByAppendingString:[NSString stringWithFormat:self.format, [maModel.ma20 floatValue]]];
    fontModelMA20.textColor = [UIColor jk_colorWithHexString:maKPIModel.ma20Hex];
    fontModelMA20.fontSize = self.attfontSize;
    
    LJDrawTextModel *fontModelMA40 = [[LJDrawTextModel alloc] init];
    fontModelMA40.text = [NSString stringWithFormat:@"MA%ld:%@",(NSInteger)maKPIModel.ma40,[NSString stringWithFormat:self.format, [maModel.ma40 floatValue]]];
    //[@"MA40:" stringByAppendingString:[NSString stringWithFormat:self.format, [maModel.ma40 floatValue]]];
    fontModelMA40.textColor = [UIColor jk_colorWithHexString:maKPIModel.ma40Hex];
    fontModelMA40.fontSize = self.attfontSize;
    
    NSMutableArray *layerArray = [CATextLayer lj_calculateTextPoint:@[fontModelMA,fontModelMA5,fontModelMA10,fontModelMA20,fontModelMA40] maxWidth:self.qsLayout.innerW drawY:self.qsLayout.kpiY reservedWidth:2];
    float height = [layerArray.lastObject floatValue];
    [layerArray removeObject:layerArray.lastObject];
    
    if (isDraw) {
        for (LJDrawTextModel *layerModel in layerArray) {
            [tempKPIDrawArray addObject:layerModel];
        }
    }
    return height;
}

/**
 计算Candle 移动至X轴的值
 
 @param y y
 @return string
 */
- (NSString *)calculateMATickY:(float)y
{
    //Candle 最高价、最低价
    NSDictionary *maxMinDic = [self.drawChartArray calculateMAMaxMin];
    float kpiMax = [[maxMinDic objectForKey:LJ_KPI_Max] floatValue];
    float kpiMin = [[maxMinDic objectForKey:LJ_KPI_Min] floatValue];
    
    double dotHeight = (kpiMax - kpiMin) / self.qsLayout.innerH;
    
    float value = kpiMax - ((y - self.qsLayout.innerY) * dotHeight);
    
    if (value > kpiMax) {
        value = kpiMax;
    }
    if (value < kpiMin) {
        value = kpiMin;
    }
    return [NSString jk_reviseString:value];
}

@end
