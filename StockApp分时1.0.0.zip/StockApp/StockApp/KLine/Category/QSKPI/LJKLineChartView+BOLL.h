//
//  LJKLineChartView+BOLL.h
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/5/31.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "LJKLineChartView.h"


@interface LJKLineChartView (BOLL)

- (void)calculateLJKLineBOLLKPIModelPoint:(NSMutableArray *)tempRectArray tempLayoutArray:(NSMutableArray *)tempLayoutArray tempDrawChartArray:(NSMutableArray *)tempDrawChartArray;

/**
 计算BOLL顶部高度
 */
- (float )calculateBOLLTopKPIHeight:(LJKLineModel *)lineModel isDraw:(BOOL)isDraw tempKPIDrawArray:(NSMutableArray *)tempKPIDrawArray;

/**
 计算Candle 移动至X轴的值
 
 @param y y
 @return string
 */
- (NSString *)calculateBOLLTickY:(float)y;

@end
