//
//  LJKLineChartView+BOLL.m
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/5/31.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "LJKLineChartView+BOLL.h"
#import "NSMutableArray+MaxMin.h"
#import "LJKLineChartView+Candle.h"
#import "UIColor+JKHEX.h"
#import "LJDrawTextModel.h"
#import "CATextLayer+kLineTextLayer.h"

@implementation LJKLineChartView (BOLL)

- (void)calculateLJKLineBOLLKPIModelPoint:(NSMutableArray *)tempRectArray tempLayoutArray:(NSMutableArray *)tempLayoutArray tempDrawChartArray:(NSMutableArray *)tempDrawChartArray
{
    
    //BOLL 最高价、最低价
    NSDictionary *maxMinDic = [tempDrawChartArray calculateBOLLMaxMin];
    
    float kpiMax = [[maxMinDic objectForKey:LJ_KPI_Max] floatValue];
    float kpiMin = [[maxMinDic objectForKey:LJ_KPI_Min] floatValue];
    
    float maxHip = [[maxMinDic objectForKey:LJ_Max_Hip] floatValue];
    float minLop = [[maxMinDic objectForKey:LJ_Min_Lop] floatValue];
    
    float dotHeight = self.qsLayout.innerH / (kpiMax - kpiMin);
    if (isinf(dotHeight) || isnan(dotHeight)) {
       return;
    }
    
    //计算蜡烛图坐标
    [self calculateLJKLineCandleKPIModelPoint:kpiMax kpiMin:kpiMin maxHip:maxHip minLop:minLop tempRectArray:tempRectArray tempLayoutArray:tempLayoutArray tempDrawChartArray:tempDrawChartArray];
    
    if (![self.qsKPIModel isKindOfClass:[LJKLineBOLLKPIModel class]]){
        return;
    }
    
    //计算MA坐标
    for (int i = 0; i < tempDrawChartArray.count; i++)
    {
        LJKLineModel *model = [tempDrawChartArray objectAtIndex:i];
        LJKLineBOLLModel *bollModel = (LJKLineBOLLModel *)model.qsModel;
        if ([model.qsModel isKindOfClass:[LJKLineBOLLModel class]]) {
            if (bollModel.boll_UP.length > 0) {
                bollModel.boll_UP_Y = (kpiMax - [bollModel.boll_UP floatValue]) * dotHeight;
            }
            if (bollModel.boll_MB.length > 0) {
                bollModel.boll_MB_Y = (kpiMax - [bollModel.boll_MB floatValue]) * dotHeight;
            }
            if (bollModel.boll_DN.length > 0) {
                bollModel.boll_DN_Y = (kpiMax - [bollModel.boll_DN floatValue]) * dotHeight;
            }
        }
    }
    LJKLineBOLLKPIModel *bollKPIModel = ((LJKLineBOLLKPIModel *)self.qsKPIModel);
    
    LJDrawModel *boll_UPLineModel = [[LJDrawModel alloc] init];
    boll_UPLineModel.lineWidth = 1.0;
    boll_UPLineModel.fillColor = [UIColor clearColor];
    boll_UPLineModel.lineColor = [UIColor jk_colorWithHexString:bollKPIModel.bollUpHex];
    [tempRectArray addObject:boll_UPLineModel];
    
    LJDrawModel *boll_MBLineModel = [[LJDrawModel alloc] init];
    boll_MBLineModel.lineWidth = 1.0;
    boll_MBLineModel.fillColor = [UIColor clearColor];
    boll_MBLineModel.lineColor = [UIColor jk_colorWithHexString:bollKPIModel.bollMbHex];
    [tempRectArray addObject:boll_MBLineModel];
    
    LJDrawModel *boll_DNLineModel = [[LJDrawModel alloc] init];
    boll_DNLineModel.lineWidth = 1.0;
    boll_DNLineModel.fillColor = [UIColor clearColor];
    boll_DNLineModel.lineColor = [UIColor jk_colorWithHexString:bollKPIModel.bollDnHex];
    [tempRectArray addObject:boll_DNLineModel];
    
    
    
    float tempX = self.qsLayout.innerW;
    float downTempX = tempX;
    // 从上 至 下绘制，与其他绘图方式不一样；
    for(NSInteger idx = tempDrawChartArray.count-1; idx >= 0; idx--){
        
        tempX -= self.kLineWidth;
        
        LJKLineModel *model = [tempDrawChartArray objectAtIndex:idx];
        LJKLineBOLLModel *bollModel = (LJKLineBOLLModel *)model.qsModel;
        if ([model.qsModel isKindOfClass:[LJKLineBOLLModel class]]) {
            LJKLineModel *downModel = nil;
            LJKLineBOLLModel *downBOLLModel = nil;
            if (idx - 1 >= 0) {
                downModel = [tempDrawChartArray objectAtIndex:idx - 1];
                downBOLLModel = (LJKLineBOLLModel *)downModel.qsModel;
                
                downTempX = tempX - self.kLineWidth;
            }
            
            //绘制boll_UP
            if (bollModel.boll_UP.length > 0 && downBOLLModel.boll_UP.length > 0) {
                CGPoint moveToPoint = CGPointMake(tempX + (self.kLineWidth/2), self.qsLayout.innerY + bollModel.boll_UP_Y);
                CGPoint toPoint = CGPointMake(downTempX + (self.kLineWidth/2), self.qsLayout.innerY + downBOLLModel.boll_UP_Y);
                
                LJDrawPointModel *drawPoint = [[LJDrawPointModel alloc] init];
                drawPoint.movePoint = moveToPoint;
                drawPoint.toPoint = toPoint;
                [boll_UPLineModel.drawArray addObject:drawPoint];
            }
            
            //绘制boll_MB
            if (bollModel.boll_MB.length > 0 && downBOLLModel.boll_MB.length > 0) {
                CGPoint moveToPoint = CGPointMake(tempX + (self.kLineWidth/2), self.qsLayout.innerY + bollModel.boll_MB_Y);
                CGPoint toPoint = CGPointMake(downTempX + (self.kLineWidth/2), self.qsLayout.innerY + downBOLLModel.boll_MB_Y);
                
                LJDrawPointModel *drawPoint = [[LJDrawPointModel alloc] init];
                drawPoint.movePoint = moveToPoint;
                drawPoint.toPoint = toPoint;
                [boll_MBLineModel.drawArray addObject:drawPoint];
            }
            
            //绘制boll_DN
            if (bollModel.boll_DN.length > 0 && downBOLLModel.boll_DN.length > 0) {
                CGPoint moveToPoint = CGPointMake(tempX + (self.kLineWidth/2), self.qsLayout.innerY + bollModel.boll_DN_Y);
                CGPoint toPoint = CGPointMake(downTempX + (self.kLineWidth/2), self.qsLayout.innerY + downBOLLModel.boll_DN_Y);
                
                LJDrawPointModel *drawPoint = [[LJDrawPointModel alloc] init];
                drawPoint.movePoint = moveToPoint;
                drawPoint.toPoint = toPoint;
                [boll_DNLineModel.drawArray addObject:drawPoint];
            }
        }
    };
}

/**
 计算BOLL顶部高度
 */
- (float )calculateBOLLTopKPIHeight:(LJKLineModel *)lineModel isDraw:(BOOL)isDraw tempKPIDrawArray:(NSMutableArray *)tempKPIDrawArray
{
    
    LJKLineBOLLKPIModel *bollKPIModel = ((LJKLineBOLLKPIModel *)self.qsKPIModel);
    if (![lineModel.qsModel isKindOfClass:[LJKLineBOLLModel class]]) {
        return 0;
    }
    LJKLineBOLLModel *bollModel = (LJKLineBOLLModel *)lineModel.qsModel;
    
    LJDrawTextModel *fontModelBOLL = [[LJDrawTextModel alloc] init];
    fontModelBOLL.text = [NSString stringWithFormat:@"BOLL(%d,%d,%d)",(int)bollKPIModel.bollMa,(int)bollKPIModel.bollMb,(int)bollKPIModel.bollP];
    fontModelBOLL.textColor = [UIColor jk_colorWithHexString:bollKPIModel.bollUpHex];
    fontModelBOLL.fontSize = self.attfontSize;
    
    LJDrawTextModel *fontModelMB = [[LJDrawTextModel alloc] init];
    fontModelMB.text = [@"M:" stringByAppendingString:[NSString stringWithFormat:self.format, [bollModel.boll_MB floatValue]]];
    fontModelMB.textColor = [UIColor jk_colorWithHexString:bollKPIModel.bollMbHex];
    fontModelMB.fontSize = self.attfontSize;
    
    LJDrawTextModel *fontModelUP = [[LJDrawTextModel alloc] init];
    fontModelUP.text = [@"T:" stringByAppendingString:[NSString stringWithFormat:self.format, [bollModel.boll_DN floatValue]]];
    fontModelUP.textColor = [UIColor jk_colorWithHexString:bollKPIModel.bollDnHex];
    fontModelUP.fontSize = self.attfontSize;
    
    LJDrawTextModel *fontModelDN = [[LJDrawTextModel alloc] init];
    fontModelDN.text = [@"B:" stringByAppendingString:[NSString stringWithFormat:self.format, [bollModel.boll_UP floatValue]]];
    fontModelDN.textColor = [UIColor jk_colorWithHexString:bollKPIModel.bollUpHex];
    fontModelDN.fontSize = self.attfontSize;
    
    NSMutableArray *layerArray = [CATextLayer lj_calculateTextPoint:@[fontModelBOLL,fontModelMB,fontModelUP,fontModelDN] maxWidth:self.qsLayout.innerW drawY:self.qsLayout.kpiY reservedWidth:2];
    float height = [layerArray.lastObject floatValue];
    [layerArray removeObject:layerArray.lastObject];
    
    if (isDraw) {
        for (LJDrawTextModel *layerModel in layerArray) {
            [tempKPIDrawArray addObject:layerModel];
        }
    }
    return height;
}

/**
 计算Candle 移动至X轴的值
 
 @param y y
 @return string
 */
- (NSString *)calculateBOLLTickY:(float)y
{
    //Candle 最高价、最低价
    NSDictionary *maxMinDic = [self.drawChartArray calculateBOLLMaxMin];
    float kpiMax = [[maxMinDic objectForKey:LJ_KPI_Max] floatValue];
    float kpiMin = [[maxMinDic objectForKey:LJ_KPI_Min] floatValue];
    
    double dotHeight = (kpiMax - kpiMin) / self.qsLayout.innerH;
    
    float value = kpiMax - ((y - self.qsLayout.innerY) * dotHeight);
    
    if (value > kpiMax) {
        value = kpiMax;
    }
    if (value < kpiMin) {
        value = kpiMin;
    }
    return [NSString jk_reviseString:value];
}

@end
