//
//  LJKLineChartView+EMA.m
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/5/31.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "LJKLineChartView+EMA.h"
#import "NSMutableArray+MaxMin.h"
#import "LJKLineChartView+Candle.h"
#import "UIColor+JKHEX.h"
#import "LJDrawTextModel.h"
#import "CATextLayer+kLineTextLayer.h"

@implementation LJKLineChartView (EMA)

- (void)calculateLJKLineEMAKPIModelPoint:(NSMutableArray *)tempRectArray tempLayoutArray:(NSMutableArray *)tempLayoutArray tempDrawChartArray:(NSMutableArray *)tempDrawChartArray
{
    
    //EMA 最高价、最低价
    NSDictionary *maxMinDic = [tempDrawChartArray calculateEMAMaxMin];
    
    float kpiMax = [[maxMinDic objectForKey:LJ_KPI_Max] floatValue];
    float kpiMin = [[maxMinDic objectForKey:LJ_KPI_Min] floatValue];
    
    float maxHip = [[maxMinDic objectForKey:LJ_Max_Hip] floatValue];
    float minLop = [[maxMinDic objectForKey:LJ_Min_Lop] floatValue];
    
    float dotHeight = self.qsLayout.innerH / (kpiMax - kpiMin);
    if (isinf(dotHeight) || isnan(dotHeight)) {
        return;
    }
    
    //计算蜡烛图坐标
    [self calculateLJKLineCandleKPIModelPoint:kpiMax kpiMin:kpiMin maxHip:maxHip minLop:minLop tempRectArray:tempRectArray tempLayoutArray:tempLayoutArray tempDrawChartArray:tempDrawChartArray];
    
    if (![self.qsKPIModel isKindOfClass:[LJKLineEMAKPIModel class]]){
        return;
    }
    
    //计算MA坐标
    for (int i = 0; i < tempDrawChartArray.count; i++) {
        LJKLineModel *model = [tempDrawChartArray objectAtIndex:i];
        LJKLineEMAModel *emaModel = (LJKLineEMAModel *)model.qsModel;
        if ([model.qsModel isKindOfClass:[LJKLineEMAModel class]]) {
            if (emaModel.ema5.length > 0) {
                emaModel.ema5_Y = (kpiMax - [emaModel.ema5 floatValue]) * dotHeight;
            }
            if (emaModel.ema10.length > 0) {
                emaModel.ema10_Y = (kpiMax - [emaModel.ema10 floatValue]) * dotHeight;
            }
            if (emaModel.ema20.length > 0) {
                emaModel.ema20_Y = (kpiMax - [emaModel.ema20 floatValue]) * dotHeight;
            }
            if (emaModel.ema40.length > 0) {
                emaModel.ema40_Y = (kpiMax - [emaModel.ema40 floatValue]) * dotHeight;
            }
        }
    }
    LJKLineEMAKPIModel *emaKPIModel = ((LJKLineEMAKPIModel *)self.qsKPIModel);
    //
    LJDrawModel *ema5LineModel = [[LJDrawModel alloc] init];
    ema5LineModel.lineWidth = 1.0;
    ema5LineModel.fillColor = [UIColor clearColor];
    ema5LineModel.lineColor = [UIColor jk_colorWithHexString:emaKPIModel.ema5Hex];
    [tempRectArray addObject:ema5LineModel];
    
    LJDrawModel *ema10LineModel = [[LJDrawModel alloc] init];
    ema10LineModel.lineWidth = 1.0;
    ema10LineModel.fillColor = [UIColor clearColor];
    ema10LineModel.lineColor = [UIColor jk_colorWithHexString:emaKPIModel.ema10Hex];
    [tempRectArray addObject:ema10LineModel];
    
    LJDrawModel *ema20LineModel = [[LJDrawModel alloc] init];
    ema20LineModel.lineWidth = 1.0;
    ema20LineModel.fillColor = [UIColor clearColor];
    ema20LineModel.lineColor = [UIColor jk_colorWithHexString:emaKPIModel.ema20Hex];
    [tempRectArray addObject:ema20LineModel];
    
    LJDrawModel *ema40LineModel = [[LJDrawModel alloc] init];
    ema40LineModel.lineWidth = 1.0;
    ema40LineModel.fillColor = [UIColor clearColor];
    ema40LineModel.lineColor = [UIColor jk_colorWithHexString:emaKPIModel.ema40Hex];
    [tempRectArray addObject:ema40LineModel];
    
    float tempX = self.qsLayout.innerW;
    float downTempX = tempX;
    // 从上 至 下绘制，与其他绘图方式不一样；
    for(NSInteger idx = tempDrawChartArray.count-1; idx >= 0; idx--){
        
        tempX -= self.kLineWidth;
        
        LJKLineModel *model = [tempDrawChartArray objectAtIndex:idx];
        LJKLineEMAModel *emaModel = (LJKLineEMAModel *)model.qsModel;
        if ([model.qsModel isKindOfClass:[LJKLineEMAModel class]]) {
            LJKLineModel *downModel = nil;
            LJKLineEMAModel *downEMAModel = nil;
            if (idx - 1 >= 0) {
                downModel = [tempDrawChartArray objectAtIndex:idx - 1];
                downEMAModel = (LJKLineEMAModel *)downModel.qsModel;
                
                downTempX = tempX - self.kLineWidth;
            }
            
            //绘制EMA5均线
            if (emaModel.ema5.length > 0 && downEMAModel.ema5.length > 0) {
                CGPoint moveToPoint = CGPointMake(tempX + (self.kLineWidth/2), self.qsLayout.innerY + emaModel.ema5_Y);
                CGPoint toPoint = CGPointMake(downTempX + (self.kLineWidth/2), self.qsLayout.innerY + downEMAModel.ema5_Y);
                
                LJDrawPointModel *drawPoint = [[LJDrawPointModel alloc] init];
                drawPoint.movePoint = moveToPoint;
                drawPoint.toPoint = toPoint;
                [ema5LineModel.drawArray addObject:drawPoint];
            }
            
            //绘制EMA10均线
            if (emaModel.ema10.length > 0 && downEMAModel.ema10.length > 0) {
                CGPoint moveToPoint = CGPointMake(tempX + (self.kLineWidth/2), self.qsLayout.innerY + emaModel.ema10_Y);
                CGPoint toPoint = CGPointMake(downTempX + (self.kLineWidth/2), self.qsLayout.innerY + downEMAModel.ema10_Y);
                
                LJDrawPointModel *drawPoint = [[LJDrawPointModel alloc] init];
                drawPoint.movePoint = moveToPoint;
                drawPoint.toPoint = toPoint;
                [ema10LineModel.drawArray addObject:drawPoint];
            }
            
            //绘制EMA20均线
            if (emaModel.ema20.length > 0 && downEMAModel.ema20.length > 0) {
                CGPoint moveToPoint = CGPointMake(tempX + (self.kLineWidth/2), self.qsLayout.innerY + emaModel.ema20_Y);
                CGPoint toPoint = CGPointMake(downTempX + (self.kLineWidth/2), self.qsLayout.innerY + downEMAModel.ema20_Y);
                
                LJDrawPointModel *drawPoint = [[LJDrawPointModel alloc] init];
                drawPoint.movePoint = moveToPoint;
                drawPoint.toPoint = toPoint;
                [ema20LineModel.drawArray addObject:drawPoint];
            }
            
            //绘制EMA40均线
            if (emaModel.ema40.length > 0 && downEMAModel.ema40.length > 0) {
                CGPoint moveToPoint = CGPointMake(tempX + (self.kLineWidth/2), self.qsLayout.innerY + emaModel.ema40_Y);
                CGPoint toPoint = CGPointMake(downTempX + (self.kLineWidth/2), self.qsLayout.innerY + downEMAModel.ema40_Y);
                
                LJDrawPointModel *drawPoint = [[LJDrawPointModel alloc] init];
                drawPoint.movePoint = moveToPoint;
                drawPoint.toPoint = toPoint;
                [ema40LineModel.drawArray addObject:drawPoint];
            }
        }
    };
}

/**
 计算EMA顶部高度
 */
- (float )calculateEMATopKPIHeight:(LJKLineModel *)lineModel isDraw:(BOOL)isDraw tempKPIDrawArray:(NSMutableArray *)tempKPIDrawArray
{
    LJKLineEMAKPIModel *emaKPIModel = ((LJKLineEMAKPIModel *)self.qsKPIModel);
    if (![lineModel.qsModel isKindOfClass:[LJKLineEMAModel class]]) {
        return 0;
    }
    LJKLineEMAModel *emaModel = (LJKLineEMAModel *)lineModel.qsModel;
    
    LJDrawTextModel *fontModelEMA = [[LJDrawTextModel alloc] init];
    fontModelEMA.text = [NSString stringWithFormat:@"EMA(%d,%d,%d,%d)",(int)emaKPIModel.ema5,(int)emaKPIModel.ema10,(int)emaKPIModel.ema20,(int)emaKPIModel.ema40];
    fontModelEMA.textColor = [UIColor jk_colorWithHexString:emaKPIModel.ema10Hex];
    fontModelEMA.fontSize = self.attfontSize;
    
    LJDrawTextModel *fontModelEMA5 = [[LJDrawTextModel alloc] init];
    fontModelEMA5.text = [NSString stringWithFormat:@"EMA%ld:%@",(NSInteger)emaKPIModel.ema5,[NSString stringWithFormat:self.format, [emaModel.ema5 floatValue]]];
    //[@"EMA5:" stringByAppendingString:[NSString stringWithFormat:self.format, [emaModel.ema5 floatValue]]];
    fontModelEMA5.textColor = [UIColor jk_colorWithHexString:emaKPIModel.ema5Hex];
    fontModelEMA5.fontSize = self.attfontSize;
    
    LJDrawTextModel *fontModelEMA10 = [[LJDrawTextModel alloc] init];
    fontModelEMA10.text = [NSString stringWithFormat:@"EMA%ld:%@",(NSInteger)emaKPIModel.ema10,[NSString stringWithFormat:self.format, [emaModel.ema10 floatValue]]];
    //[@"EMA10:" stringByAppendingString:[NSString stringWithFormat:self.format, [emaModel.ema10 floatValue]]];
    fontModelEMA10.textColor = [UIColor jk_colorWithHexString:emaKPIModel.ema10Hex];
    fontModelEMA10.fontSize = self.attfontSize;
    
    LJDrawTextModel *fontModelEMA20 = [[LJDrawTextModel alloc] init];
    fontModelEMA20.text = [NSString stringWithFormat:@"EMA%ld:%@",(NSInteger)emaKPIModel.ema20,[NSString stringWithFormat:self.format, [emaModel.ema20 floatValue]]];
    //[@"EMA20:" stringByAppendingString:[NSString stringWithFormat:self.format, [emaModel.ema20 floatValue]]];
    fontModelEMA20.textColor = [UIColor jk_colorWithHexString:emaKPIModel.ema20Hex];
    fontModelEMA20.fontSize = self.attfontSize;
    
    LJDrawTextModel *fontModelEMA40 = [[LJDrawTextModel alloc] init];
    fontModelEMA40.text = [NSString stringWithFormat:@"EMA%ld:%@",(NSInteger)emaKPIModel.ema40,[NSString stringWithFormat:self.format, [emaModel.ema40 floatValue]]];
    //[@"EMA40:" stringByAppendingString:[NSString stringWithFormat:self.format, [emaModel.ema40 floatValue]]];
    fontModelEMA40.textColor = [UIColor jk_colorWithHexString:emaKPIModel.ema40Hex];
    fontModelEMA40.fontSize = self.attfontSize;
    
    NSMutableArray *layerArray = [CATextLayer lj_calculateTextPoint:@[fontModelEMA,fontModelEMA5,fontModelEMA10,fontModelEMA20,fontModelEMA40] maxWidth:self.qsLayout.innerW drawY:self.qsLayout.kpiY reservedWidth:2];
    float height = [layerArray.lastObject floatValue];
    [layerArray removeObject:layerArray.lastObject];
    
    if (isDraw) {
        for (LJDrawTextModel *layerModel in layerArray) {
            [tempKPIDrawArray addObject:layerModel];
        }
    }
    return height;
}

/**
 计算Candle 移动至X轴的值
 
 @param y y
 @return string
 */
- (NSString *)calculateEMATickY:(float)y
{
    //Candle 最高价、最低价
    NSDictionary *maxMinDic = [self.drawChartArray calculateEMAMaxMin];
    float kpiMax = [[maxMinDic objectForKey:LJ_KPI_Max] floatValue];
    float kpiMin = [[maxMinDic objectForKey:LJ_KPI_Min] floatValue];
    
    double dotHeight = (kpiMax - kpiMin) / self.qsLayout.innerH;
    
    float value = kpiMax - ((y - self.qsLayout.innerY) * dotHeight);
    
    if (value > kpiMax) {
        value = kpiMax;
    }
    if (value < kpiMin) {
        value = kpiMin;
    }
    return [NSString jk_reviseString:value];
}

@end
