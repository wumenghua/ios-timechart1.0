//
//  LJKLineChartView+EMA.h
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/5/31.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "LJKLineChartView.h"

@interface LJKLineChartView (EMA)

- (void)calculateLJKLineEMAKPIModelPoint:(NSMutableArray *)tempRectArray tempLayoutArray:(NSMutableArray *)tempLayoutArray tempDrawChartArray:(NSMutableArray *)tempDrawChartArray;

/**
 计算EMA顶部高度
 */
- (float )calculateEMATopKPIHeight:(LJKLineModel *)lineModel isDraw:(BOOL)isDraw tempKPIDrawArray:tempKPIDrawArray;

/**
 计算Candle 移动至X轴的值
 
 @param y y
 @return string
 */
- (NSString *)calculateEMATickY:(float)y;

@end
