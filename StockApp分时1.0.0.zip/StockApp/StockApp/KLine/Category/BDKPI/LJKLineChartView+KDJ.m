//
//  LJKLineChartView+KDJ.m
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/5/31.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "LJKLineChartView+KDJ.h"
#import "NSMutableArray+MaxMin.h"
#import "UIColor+JKHEX.h"
#import "LJDrawTextModel.h"
#import "CATextLayer+kLineTextLayer.h"

@implementation LJKLineChartView (KDJ)

- (void)calculateLJKLineKDJKPIModelPoint:(NSMutableArray *)tempRectArray tempLayoutArray:(NSMutableArray *)tempLayoutArray tempDrawChartArray:(NSMutableArray *)tempDrawChartArray
{
    //KDJ 最高价、最低价
    NSDictionary *maxMinDic = [tempDrawChartArray calculateKDJMaxMin];
    
    float kpiMax = [[maxMinDic objectForKey:LJ_KPI_Max] floatValue];
    float kpiMin = [[maxMinDic objectForKey:LJ_KPI_Min] floatValue];
    
    float dotHeight = self.bdLayout.innerH / (kpiMax - kpiMin);
    if (isinf(dotHeight) || isnan(dotHeight)) {
        return;
    }
    
    if (![self.bdKPIModel isKindOfClass:[LJKLineKDJKPIModel class]]){
        return;
    }
    
    for (NSInteger i = 0; i < tempDrawChartArray.count; i++) {
        LJKLineModel *model = [tempDrawChartArray objectAtIndex:i];
        if ([model.bdModel isKindOfClass:[LJKLineKDJModel class]]) {
            LJKLineKDJModel *kdjModel = (LJKLineKDJModel *)model.bdModel;
            
            kdjModel.kdj_K_Y = ([kdjModel.kdj_K doubleValue] - kpiMin) * dotHeight;
            kdjModel.kdj_D_Y = ([kdjModel.kdj_D doubleValue] - kpiMin) * dotHeight;
            kdjModel.kdj_J_Y = ([kdjModel.kdj_J doubleValue] - kpiMin) * dotHeight;
        }
    }
    LJKLineKDJKPIModel *kdjKPIModel = ((LJKLineKDJKPIModel *)self.bdKPIModel);
    
    LJDrawModel *nLineModel = [[LJDrawModel alloc] init];
    nLineModel.lineWidth = 1.0;
    nLineModel.fillColor = [UIColor clearColor];
    nLineModel.lineColor = [UIColor jk_colorWithHexString:kdjKPIModel.nHex];
    [tempRectArray addObject:nLineModel];
    
    LJDrawModel *m1LineModel = [[LJDrawModel alloc] init];
    m1LineModel.lineWidth = 1.0;
    m1LineModel.fillColor = [UIColor clearColor];
    m1LineModel.lineColor = [UIColor jk_colorWithHexString:kdjKPIModel.m1Hex];
    [tempRectArray addObject:m1LineModel];
    
    LJDrawModel *m2LineModel = [[LJDrawModel alloc] init];
    m2LineModel.lineWidth = 1.0;
    m2LineModel.fillColor = [UIColor clearColor];
    m2LineModel.lineColor = [UIColor jk_colorWithHexString:kdjKPIModel.m2Hex];
    [tempRectArray addObject:m2LineModel];
    
    float tempX = self.bdLayout.innerW;
    float downTempX = tempX;
    // 从上 至 下绘制，与其他绘图方式不一样；
    for(NSInteger idx = tempDrawChartArray.count-1; idx >= 0; idx--){
        
        tempX -= self.kLineWidth;
        
        LJKLineModel *model = [tempDrawChartArray objectAtIndex:idx];
        LJKLineKDJModel *kdjModel = (LJKLineKDJModel *)model.bdModel;
        if ([model.bdModel isKindOfClass:[LJKLineKDJModel class]]) {
            LJKLineModel *downModel = nil;
            LJKLineKDJModel *downKDJModel = nil;
            if (idx - 1 >= 0) {
                downModel = [tempDrawChartArray objectAtIndex:idx - 1];
                downKDJModel = (LJKLineKDJModel *)downModel.bdModel;
                
                downTempX = tempX - self.kLineWidth;
            }
            
            //绘制 kdj_k
            if (kdjModel.kdj_K.length > 0 && downKDJModel.kdj_K.length > 0) {
                CGPoint moveToPoint = CGPointMake(tempX + (self.kLineWidth/2), self.bdLayout.botton - kdjModel.kdj_K_Y);
                CGPoint toPoint = CGPointMake(downTempX + (self.kLineWidth/2), self.bdLayout.botton - downKDJModel.kdj_K_Y);
                
                LJDrawPointModel *pointModel = [[LJDrawPointModel alloc] init];
                pointModel.movePoint = moveToPoint;
                pointModel.toPoint = toPoint;
                [nLineModel.drawArray addObject:pointModel];
            }
            
            //绘制 kdj_d
            if (kdjModel.kdj_D.length > 0 && downKDJModel.kdj_D.length > 0) {
                CGPoint moveToPoint = CGPointMake(tempX + (self.kLineWidth/2), self.bdLayout.botton - kdjModel.kdj_D_Y);
                CGPoint toPoint = CGPointMake(downTempX + (self.kLineWidth/2), self.bdLayout.botton - downKDJModel.kdj_D_Y);
                
                LJDrawPointModel *pointModel = [[LJDrawPointModel alloc] init];
                pointModel.movePoint = moveToPoint;
                pointModel.toPoint = toPoint;
                [m1LineModel.drawArray addObject:pointModel];
            }
            
            //绘制 kdj_j
            if (kdjModel.kdj_J.length > 0 && downKDJModel.kdj_J.length > 0) {
                CGPoint moveToPoint = CGPointMake(tempX + (self.kLineWidth/2), self.bdLayout.botton - kdjModel.kdj_J_Y);
                CGPoint toPoint = CGPointMake(downTempX + (self.kLineWidth/2), self.bdLayout.botton - downKDJModel.kdj_J_Y);
                
                LJDrawPointModel *pointModel = [[LJDrawPointModel alloc] init];
                pointModel.movePoint = moveToPoint;
                pointModel.toPoint = toPoint;
                [m2LineModel.drawArray addObject:pointModel];
            }
        }
    }
    if (tempDrawChartArray.count > 0) {
        //绘制KDJ横线
        [self drawKDJHorLayer:kpiMax kpiMin:kpiMin tempRectArray:tempRectArray tempLayoutArray:tempLayoutArray];
    }
}

/**
 绘制KDJ横线
 
 @param kpiMax 最高价
 @param kpiMin 最低价
 */
- (void)drawKDJHorLayer:(float)kpiMax kpiMin:(float)kpiMin tempRectArray:(NSMutableArray *)tempRectArray tempLayoutArray:(NSMutableArray *)tempLayoutArray
{
    LJDrawModel *lineDashModel = [[LJDrawModel alloc] init];
    lineDashModel.lineWidth = 0.2;
    lineDashModel.lineType = LJ_ENUM_DrawModel_Dash;
    lineDashModel.fillColor = [UIColor clearColor];
    lineDashModel.lineColor = LJ_Red_Color;
    [tempRectArray addObject:lineDashModel];
    
    //求得价格和百分比的rect
    CGRect textRect = [NSString jk_rectOfNSString:[NSString stringWithFormat:@"000"] attribute:self.attribute];
    float dotHeight = self.bdLayout.innerH / (kpiMax - kpiMin);
    
    NSArray *kpiArray = @[@(0),@(20),@(50),@(80),@(100)];
    for (int i = 0; i < kpiArray.count; i++) {
        int value = [kpiArray[i] intValue];
        if (value > kpiMin && value < kpiMax) {
            
            float pointY = (value - kpiMin) * dotHeight;
            LJDrawPointModel *lineModel = [[LJDrawPointModel alloc] init];
            lineModel.movePoint = CGPointMake(self.bdLayout.x, self.bdLayout.botton - pointY);
            lineModel.toPoint = CGPointMake(self.bdLayout.w, self.bdLayout.botton - pointY);
            [lineDashModel.drawArray addObject:lineModel];
            
            if (i < kpiArray.count-1)
            {
                CGRect textFrame = CGRectMake(self.bdLayout.innerX, self.bdLayout.botton - pointY - textRect.size.height, textRect.size.width, textRect.size.height);
                LJDrawTextModel *textModel = [[LJDrawTextModel alloc] init];
                textModel.text = [NSString stringWithFormat:@"%d",value];
                textModel.textColor = LJ_Red_Color;
                textModel.textRect = textFrame;
                [tempLayoutArray addObject:textModel];
            }
        }
    }
}

/**
 计算KDJ顶部高度
 
 @param lineModel 需要计算的Model
 @param isDraw 是否绘制
 
 @return kpi高度
 */
- (float )calculateKDJTopKPIHeight:(LJKLineModel *)lineModel isDraw:(BOOL)isDraw tempKPIDrawArray:(NSMutableArray *)tempKPIDrawArray{
    
    LJKLineKDJKPIModel *kdjKPIModel = ((LJKLineKDJKPIModel *)self.bdKPIModel);
    if (![lineModel.bdModel isKindOfClass:[LJKLineKDJModel class]]) {
        return 0;
    }
    LJKLineKDJModel *kdjModel = (LJKLineKDJModel *)lineModel.bdModel;
    
    LJDrawTextModel *fontModelKDJ = [[LJDrawTextModel alloc] init];
    fontModelKDJ.text = [NSString stringWithFormat:@"KDJ(%d,%d,%d)",(int)kdjKPIModel.n,(int)kdjKPIModel.m1,(int)kdjKPIModel.m2];
    fontModelKDJ.textColor = [UIColor jk_colorWithHexString:kdjKPIModel.m1Hex];
    fontModelKDJ.fontSize = self.attfontSize;
    
    LJDrawTextModel *fontModelK = [[LJDrawTextModel alloc] init];
    fontModelK.text = [@"K:" stringByAppendingString:[NSString stringWithFormat:self.format, [kdjModel.kdj_K floatValue]]];
    fontModelK.textColor = [UIColor jk_colorWithHexString:kdjKPIModel.nHex];
    fontModelK.fontSize = self.attfontSize;
    
    LJDrawTextModel *fontModelD = [[LJDrawTextModel alloc] init];
    fontModelD.text = [@"D:" stringByAppendingString:[NSString stringWithFormat:self.format, [kdjModel.kdj_D floatValue]]];
    fontModelD.textColor = [UIColor jk_colorWithHexString:kdjKPIModel.m1Hex];
    fontModelD.fontSize = self.attfontSize;
    
    LJDrawTextModel *fontModelJ = [[LJDrawTextModel alloc] init];
    fontModelJ.text = [@"J:" stringByAppendingString:[NSString stringWithFormat:self.format, [kdjModel.kdj_J floatValue]]];
    fontModelJ.textColor = [UIColor jk_colorWithHexString:kdjKPIModel.m2Hex];
    fontModelJ.fontSize = self.attfontSize;
    
    
    NSMutableArray *layerArray = [CATextLayer lj_calculateTextPoint:@[fontModelKDJ,fontModelK,fontModelD,fontModelJ] maxWidth:self.bdLayout.innerW drawY:self.bdLayout.y + self.bdLayout.kpiY reservedWidth:2];
    float height = [layerArray.lastObject floatValue];
    [layerArray removeObject:layerArray.lastObject];
    
    if (isDraw) {
        for (LJDrawTextModel *layerModel in layerArray) {
            [tempKPIDrawArray addObject:layerModel];
        }
    }
    return height;
}

/**
 计算KDJ 移动至X轴的值
 
 @param y y
 @return string
 */
- (NSString *)calculateKDJTickY:(float)y
{
    //KDJ 最高价、最低价
    NSDictionary *maxMinDic = [self.drawChartArray calculateKDJMaxMin];
    float kpiMax = [[maxMinDic objectForKey:LJ_KPI_Max] floatValue];
    float kpiMin = [[maxMinDic objectForKey:LJ_KPI_Min] floatValue];
    
    double dotHeight = (kpiMax - kpiMin) / self.bdLayout.innerH;
    
    float value = kpiMax - ((y - self.bdLayout.innerY) * dotHeight);
    
    if (value > kpiMax) {
        value = kpiMax;
    }
    if (value < kpiMin) {
        value = kpiMin;
    }
    return [NSString jk_reviseString:value];
}

@end
