//
//  LJKLineChartView+RSI.m
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/5/31.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "LJKLineChartView+RSI.h"
#import "NSMutableArray+MaxMin.h"
#import "UIColor+JKHEX.h"
#import "LJDrawTextModel.h"
#import "CATextLayer+kLineTextLayer.h"

@implementation LJKLineChartView (RSI)

- (void)calculateLJKLineRSIKPIModelPoint:(NSMutableArray *)tempRectArray tempLayoutArray:(NSMutableArray *)tempLayoutArray tempDrawChartArray:(NSMutableArray *)tempDrawChartArray
{
    //RSI 最高价、最低价
    NSDictionary *maxMinDic = [tempDrawChartArray calculateRSIMaxMin];
    
    float kpiMax = [[maxMinDic objectForKey:LJ_KPI_Max] floatValue];
    float kpiMin = [[maxMinDic objectForKey:LJ_KPI_Min] floatValue];
    
    float dotHeight = self.bdLayout.innerH / (kpiMax - kpiMin);
    if (isinf(dotHeight) || isnan(dotHeight)) {
        return;
    }
    
    if (![self.bdKPIModel isKindOfClass:[LJKLineRSIKPIModel class]]){
        return;
    }
    
    for (NSInteger i = 0; i < tempDrawChartArray.count; i++) {
        LJKLineModel *model = [tempDrawChartArray objectAtIndex:i];
        if ([model.bdModel isKindOfClass:[LJKLineRSIModel class]]) {
            LJKLineRSIModel *rsiModel = (LJKLineRSIModel *)model.bdModel;
            
            rsiModel.rsi_6_Y = ([rsiModel.rsi_6 doubleValue] - kpiMin) * dotHeight;
            rsiModel.rsi_12_Y = ([rsiModel.rsi_12 doubleValue] - kpiMin) * dotHeight;
            rsiModel.rsi_24_Y = ([rsiModel.rsi_24 doubleValue] - kpiMin) * dotHeight;
        }
    }
    LJKLineRSIKPIModel *rsiKPIModel = ((LJKLineRSIKPIModel *)self.bdKPIModel);
    
    LJDrawModel *n1LineModel = [[LJDrawModel alloc] init];
    n1LineModel.lineWidth = 1.0;
    n1LineModel.fillColor = [UIColor clearColor];
    n1LineModel.lineColor = [UIColor jk_colorWithHexString:rsiKPIModel.n1Hex];
    [tempRectArray addObject:n1LineModel];
    
    LJDrawModel *n2LineModel = [[LJDrawModel alloc] init];
    n2LineModel.lineWidth = 1.0;
    n2LineModel.fillColor = [UIColor clearColor];
    n2LineModel.lineColor = [UIColor jk_colorWithHexString:rsiKPIModel.n2Hex];
    [tempRectArray addObject:n2LineModel];
    
    LJDrawModel *n3LineModel = [[LJDrawModel alloc] init];
    n3LineModel.lineWidth = 1.0;
    n3LineModel.fillColor = [UIColor clearColor];
    n3LineModel.lineColor = [UIColor jk_colorWithHexString:rsiKPIModel.n3Hex];
    [tempRectArray addObject:n3LineModel];
    
    float tempX = self.bdLayout.innerW;
    float downTempX = tempX;
    // 从上 至 下绘制，与其他绘图方式不一样；
    for(NSInteger idx = tempDrawChartArray.count-1; idx >= 0; idx--){
        
        tempX -= self.kLineWidth;
        
        LJKLineModel *model = [tempDrawChartArray objectAtIndex:idx];
        LJKLineRSIModel *rsiModel = (LJKLineRSIModel *)model.bdModel;
        if ([model.bdModel isKindOfClass:[LJKLineRSIModel class]]) {
            LJKLineModel *downModel = nil;
            LJKLineRSIModel *downRSIModel = nil;
            if (idx - 1 >= 0) {
                downModel = [tempDrawChartArray objectAtIndex:idx - 1];
                downRSIModel = (LJKLineRSIModel *)downModel.bdModel;
                
                downTempX = tempX - self.kLineWidth;
            }
            
            //绘制 rsi_6
            if (rsiModel.rsi_6.length > 0 && downRSIModel.rsi_6.length > 0) {
                CGPoint moveToPoint = CGPointMake(tempX + (self.kLineWidth/2), self.bdLayout.botton - rsiModel.rsi_6_Y);
                CGPoint toPoint = CGPointMake(downTempX + (self.kLineWidth/2), self.bdLayout.botton - downRSIModel.rsi_6_Y);
                
                LJDrawPointModel *pointModel = [[LJDrawPointModel alloc] init];
                pointModel.movePoint = moveToPoint;
                pointModel.toPoint = toPoint;
                [n1LineModel.drawArray addObject:pointModel];
            }
            
            //绘制 rsi_12 均线
            if (rsiModel.rsi_12.length > 0 && downRSIModel.rsi_12.length > 0) {
                CGPoint moveToPoint = CGPointMake(tempX + (self.kLineWidth/2), self.bdLayout.botton - rsiModel.rsi_12_Y);
                CGPoint toPoint = CGPointMake(downTempX + (self.kLineWidth/2), self.bdLayout.botton - downRSIModel.rsi_12_Y);
                
                LJDrawPointModel *pointModel = [[LJDrawPointModel alloc] init];
                pointModel.movePoint = moveToPoint;
                pointModel.toPoint = toPoint;
                [n2LineModel.drawArray addObject:pointModel];
            }
            
            //绘制 rsi_24 均线
            if (rsiModel.rsi_24.length > 0 && downRSIModel.rsi_24.length > 0) {
                CGPoint moveToPoint = CGPointMake(tempX + (self.kLineWidth/2), self.bdLayout.botton - rsiModel.rsi_24_Y);
                CGPoint toPoint = CGPointMake(downTempX + (self.kLineWidth/2), self.bdLayout.botton - downRSIModel.rsi_24_Y);
                
                LJDrawPointModel *pointModel = [[LJDrawPointModel alloc] init];
                pointModel.movePoint = moveToPoint;
                pointModel.toPoint = toPoint;
                [n3LineModel.drawArray addObject:pointModel];
            }
        }
    }
    
    if (tempDrawChartArray.count > 0) {
        //绘制RSI横线
        [self drawRSIHorLayer:kpiMax kpiMin:kpiMin tempRectArray:tempRectArray tempLayoutArray:tempLayoutArray];
    }
}

/**
 绘制RSI横线
 
 @param kpiMax 最高价
 @param kpiMin 最低价
 */
- (void)drawRSIHorLayer:(float)kpiMax kpiMin:(float)kpiMin tempRectArray:(NSMutableArray *)tempRectArray tempLayoutArray:(NSMutableArray *)tempLayoutArray
{
    LJDrawModel *lineDashModel = [[LJDrawModel alloc] init];
    lineDashModel.lineWidth = 0.2;
    lineDashModel.lineType = LJ_ENUM_DrawModel_Dash;
    lineDashModel.fillColor = [UIColor clearColor];
    lineDashModel.lineColor = LJ_Red_Color;
    [tempRectArray addObject:lineDashModel];
    
    //求得价格和百分比的rect
    CGRect textRect = [NSString jk_rectOfNSString:[NSString stringWithFormat:@"000"] attribute:self.attribute];
    
    float dotHeight = self.bdLayout.innerH / (kpiMax - kpiMin);
    
    NSArray *kpiArray = @[@(20),@(50),@(80)];
    for (int i = 0; i < kpiArray.count; i++) {
        int value = [kpiArray[i] intValue];
        if (value > kpiMin && value < kpiMax) {
            
            float pointY = (value - kpiMin) * dotHeight;
            LJDrawPointModel *lineModel = [[LJDrawPointModel alloc] init];
            lineModel.movePoint = CGPointMake(self.bdLayout.x, self.bdLayout.botton - pointY);
            lineModel.toPoint = CGPointMake(self.bdLayout.w, self.bdLayout.botton - pointY);
            [lineDashModel.drawArray addObject:lineModel];
            
            CGRect textFrame = CGRectMake(self.bdLayout.innerX, self.bdLayout.botton - pointY - textRect.size.height, textRect.size.width, textRect.size.height);
            LJDrawTextModel *textModel = [[LJDrawTextModel alloc] init];
            textModel.text = [NSString stringWithFormat:@"%d",value];
            textModel.textColor = LJ_Red_Color;
            textModel.textRect = textFrame;
            [tempLayoutArray addObject:textModel];
        }
    }
}

/**
 计算RSI顶部高度
 
 @param lineModel 需要计算的Model
 @param isDraw 是否绘制
 
 @return kpi高度
 */
- (float )calculateRSITopKPIHeight:(LJKLineModel *)lineModel isDraw:(BOOL)isDraw tempKPIDrawArray:(NSMutableArray *)tempKPIDrawArray
{
    LJKLineRSIKPIModel *rsiKPIModel = ((LJKLineRSIKPIModel *)self.bdKPIModel);
    if (![lineModel.bdModel isKindOfClass:[LJKLineRSIModel class]]) {
        return 0;
    }
    LJKLineRSIModel *rsiModel = (LJKLineRSIModel *)lineModel.bdModel;
    
    LJDrawTextModel *fontModelRSI = [[LJDrawTextModel alloc] init];
    fontModelRSI.text = [NSString stringWithFormat:@"RSI(%d,%d,%d)",(int)rsiKPIModel.n1,(int)rsiKPIModel.n2,(int)rsiKPIModel.n3];
    fontModelRSI.textColor = [UIColor jk_colorWithHexString:rsiKPIModel.n2Hex];
    fontModelRSI.fontSize = self.attfontSize;
    
    LJDrawTextModel *fontModelN1 = [[LJDrawTextModel alloc] init];
    fontModelN1.text = [@"RSI1:" stringByAppendingString:[NSString stringWithFormat:self.format, [rsiModel.rsi_6 floatValue]]];
    fontModelN1.textColor = [UIColor jk_colorWithHexString:rsiKPIModel.n1Hex];
    fontModelN1.fontSize = self.attfontSize;
    
    LJDrawTextModel *fontModelN2 = [[LJDrawTextModel alloc] init];
    fontModelN2.text = [@"RSI2:" stringByAppendingString:[NSString stringWithFormat:self.format, [rsiModel.rsi_12 floatValue]]];
    fontModelN2.textColor = [UIColor jk_colorWithHexString:rsiKPIModel.n2Hex];
    fontModelN2.fontSize = self.attfontSize;
    
    LJDrawTextModel *fontModelN3 = [[LJDrawTextModel alloc] init];
    fontModelN3.text = [@"RSI3:" stringByAppendingString:[NSString stringWithFormat:self.format, [rsiModel.rsi_24 floatValue]]];
    fontModelN3.textColor = [UIColor jk_colorWithHexString:rsiKPIModel.n3Hex];
    fontModelN3.fontSize = self.attfontSize;
    
    
    NSMutableArray *layerArray = [CATextLayer lj_calculateTextPoint:@[fontModelRSI,fontModelN1,fontModelN2,fontModelN3] maxWidth:self.bdLayout.innerW drawY:self.bdLayout.y + self.bdLayout.kpiY reservedWidth:2];
    float height = [layerArray.lastObject floatValue];
    [layerArray removeObject:layerArray.lastObject];
    
    if (isDraw) {
        for (LJDrawTextModel *layerModel in layerArray) {
            [tempKPIDrawArray addObject:layerModel];
        }
    }
    return height;
}

/**
 计算RSI 移动至X轴的值
 
 @param y y
 @return string
 */
- (NSString *)calculateRSITickY:(float)y
{
    //RSI 最高价、最低价
    NSDictionary *maxMinDic = [self.drawChartArray calculateRSIMaxMin];
    float kpiMax = [[maxMinDic objectForKey:LJ_KPI_Max] floatValue];
    float kpiMin = [[maxMinDic objectForKey:LJ_KPI_Min] floatValue];
    
    double dotHeight = (kpiMax - kpiMin) / self.bdLayout.innerH;
    
    float value = kpiMax - ((y - self.bdLayout.innerY) * dotHeight);
    
    if (value > kpiMax) {
        value = kpiMax;
    }
    if (value < kpiMin) {
        value = kpiMin;
    }
    return [NSString jk_reviseString:value];
}

@end
