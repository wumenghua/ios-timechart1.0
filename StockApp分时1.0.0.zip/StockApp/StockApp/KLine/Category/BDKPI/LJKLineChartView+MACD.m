//
//  LJKLineChartView+MACD.m
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/5/31.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "LJKLineChartView+MACD.h"
#import "NSMutableArray+MaxMin.h"
#import "UIColor+JKHEX.h"
#import "LJDrawTextModel.h"
#import "CATextLayer+kLineTextLayer.h"

@implementation LJKLineChartView (MACD)

- (void)calculateLJKLineMACDKPIModelPoint:(NSMutableArray *)tempRectArray tempLayoutArray:(NSMutableArray *)tempLayoutArray tempDrawChartArray:(NSMutableArray *)tempDrawChartArray
{
    //MACD 最高价、最低价
    NSDictionary *maxMinDic = [tempDrawChartArray calculateMACDMaxMin];
    
    float kpiMax = [[maxMinDic objectForKey:LJ_KPI_Max] floatValue];
    float kpiMin = [[maxMinDic objectForKey:LJ_KPI_Min] floatValue];
    
    float center = kpiMin > 0 ? (kpiMax-kpiMin)/2 : 0;
    
    float dotHeight = self.bdLayout.innerH / (kpiMax - kpiMin);
    if (isinf(dotHeight) || isnan(dotHeight)) {
        return;
    }
    
    if (![self.bdKPIModel isKindOfClass:[LJKLineMACDKPIModel class]]){
        return;
    }
    
    for (NSInteger i = 0; i < tempDrawChartArray.count; i++) {
        LJKLineModel *model = [tempDrawChartArray objectAtIndex:i];
        LJKLineMACDModel *macdModel = (LJKLineMACDModel *)model.bdModel;
        if ([model.bdModel isKindOfClass:[LJKLineMACDModel class]])
        {
            macdModel.dif_Y = ([macdModel.dif doubleValue] - kpiMin) * dotHeight;
            macdModel.dea_Y = ([macdModel.dea doubleValue] - kpiMin) * dotHeight;
            
            macdModel.macd_centerY = (center - kpiMin) * dotHeight;
            macdModel.macd_Y = ([macdModel.macd doubleValue] - kpiMin) * dotHeight;
        }
    }
    LJKLineMACDKPIModel *macdKPIModel = ((LJKLineMACDKPIModel *)self.bdKPIModel);
    
    LJDrawModel *macdUpLineModel = [[LJDrawModel alloc] init];
    macdUpLineModel.lineWidth = 1.0;
    macdUpLineModel.fillColor = [UIColor clearColor];
    macdUpLineModel.lineColor = [UIColor jk_colorWithHexString:macdKPIModel.macdUpHex];
    [tempRectArray addObject:macdUpLineModel];
    
    LJDrawModel *macdDnLineModel = [[LJDrawModel alloc] init];
    macdDnLineModel.lineWidth = 1.0;
    macdDnLineModel.fillColor = [UIColor clearColor];
    macdDnLineModel.lineColor = [UIColor jk_colorWithHexString:macdKPIModel.macdDNHex];
    [tempRectArray addObject:macdDnLineModel];
    
    LJDrawModel *difLineModel = [[LJDrawModel alloc] init];
    difLineModel.lineWidth = 1.0;
    difLineModel.fillColor = [UIColor clearColor];
    difLineModel.lineColor = [UIColor jk_colorWithHexString:macdKPIModel.difHex];
    [tempRectArray addObject:difLineModel];
    
    LJDrawModel *deaLineModel = [[LJDrawModel alloc] init];
    deaLineModel.lineWidth = 1.0;
    deaLineModel.fillColor = [UIColor clearColor];
    deaLineModel.lineColor = [UIColor jk_colorWithHexString:macdKPIModel.deaHex];
    [tempRectArray addObject:deaLineModel];
    
    
    float tempX = self.bdLayout.innerW;
    float downTempX = tempX;
    // 从上 至 下绘制，与其他绘图方式不一样；
    for(NSInteger idx = tempDrawChartArray.count-1; idx >= 0; idx--){
        
        tempX -= self.kLineWidth;
        
        LJKLineModel *model = [tempDrawChartArray objectAtIndex:idx];
        LJKLineMACDModel *macdModel = (LJKLineMACDModel *)model.bdModel;
        if ([model.bdModel isKindOfClass:[LJKLineMACDModel class]])
        {
            LJKLineModel *downModel = nil;
            LJKLineMACDModel *downMacdModel = nil;
            if (idx - 1 >= 0) {
                downModel = [tempDrawChartArray objectAtIndex:idx - 1];
                downMacdModel = (LJKLineMACDModel *)downModel.bdModel;
                
                downTempX = tempX - self.kLineWidth;
            }
            
            //绘制MACD
            if (macdModel.macd.length > 0) {
                
                float moveToY = self.bdLayout.botton - (macdModel.macd_centerY < macdModel.macd_Y ? macdModel.macd_Y : macdModel.macd_centerY);
                float addLineToY = self.bdLayout.botton - (macdModel.macd_centerY < macdModel.macd_Y ? macdModel.macd_centerY : macdModel.macd_Y);
                
                if (macdModel.macd_centerY < macdModel.macd_Y) {
                    //center以上
                    CGPoint moveToPoint = CGPointMake(tempX + (self.kLineWidth/2), moveToY);
                    CGPoint toPoint = CGPointMake(tempX + (self.kLineWidth/2), addLineToY);
                    
                    LJDrawPointModel *pointModel = [[LJDrawPointModel alloc] init];
                    pointModel.movePoint = moveToPoint;
                    pointModel.toPoint = toPoint;
                    [macdUpLineModel.drawArray addObject:pointModel];
                }else{
                    //center以下
                    CGPoint moveToPoint = CGPointMake(tempX + (self.kLineWidth/2), moveToY);
                    CGPoint toPoint = CGPointMake(tempX + (self.kLineWidth/2), addLineToY);
                    
                    LJDrawPointModel *pointModel = [[LJDrawPointModel alloc] init];
                    pointModel.movePoint = moveToPoint;
                    pointModel.toPoint = toPoint;
                    [macdDnLineModel.drawArray addObject:pointModel];
                }
            }
            
            //绘制 dif 均线
            if (macdModel.dif.length > 0 && downMacdModel.dif.length > 0) {
                CGPoint moveToPoint = CGPointMake(tempX + (self.kLineWidth/2), self.bdLayout.botton - macdModel.dif_Y);
                CGPoint toPoint = CGPointMake(downTempX + (self.kLineWidth/2), self.bdLayout.botton - downMacdModel.dif_Y);
                
                LJDrawPointModel *pointModel = [[LJDrawPointModel alloc] init];
                pointModel.movePoint = moveToPoint;
                pointModel.toPoint = toPoint;
                [difLineModel.drawArray addObject:pointModel];
            }
            
            //绘制 dea 均线
            if (macdModel.dea.length > 0 && downMacdModel.dea.length > 0) {
                CGPoint moveToPoint = CGPointMake(tempX + (self.kLineWidth/2), self.bdLayout.botton - macdModel.dea_Y);
                CGPoint toPoint = CGPointMake(downTempX + (self.kLineWidth/2), self.bdLayout.botton - downMacdModel.dea_Y);
                
                LJDrawPointModel *pointModel = [[LJDrawPointModel alloc] init];
                pointModel.movePoint = moveToPoint;
                pointModel.toPoint = toPoint;
                [deaLineModel.drawArray addObject:pointModel];
            }
        }
    }
    
    if (tempDrawChartArray.count > 0) {
        //绘制MACD横线
        [self drawMACDHorLayer:kpiMax kpiMin:kpiMin tempRectArray:tempRectArray tempLayoutArray:tempLayoutArray];
    }
}

/**
 绘制MACD横线
 
 @param kpiMax 最高价
 @param kpiMin 最低价
 */
- (void)drawMACDHorLayer:(float)kpiMax kpiMin:(float)kpiMin tempRectArray:(NSMutableArray *)tempRectArray tempLayoutArray:(NSMutableArray *)tempLayoutArray
{
    LJDrawModel *lineDashModel = [[LJDrawModel alloc] init];
    lineDashModel.lineWidth = 0.2;
    lineDashModel.lineType = LJ_ENUM_DrawModel_Dash;
    lineDashModel.fillColor = [UIColor clearColor];
    lineDashModel.lineColor = LJ_Red_Color;
    [tempRectArray addObject:lineDashModel];
    
    //生成 单位价格
    float unitPrice = (kpiMax - kpiMin) / 4.0;
    //求得价格和百分比的rect
    CGRect textRect = [NSString jk_rectOfNSString:[NSString stringWithFormat:@"%0.2f",unitPrice] attribute:self.attribute];
    
    if (isnan(textRect.origin.y) || isinf(textRect.origin.y)) {
    }
    float dotHeight = self.bdLayout.innerH / (kpiMax - kpiMin);
    
    float center = kpiMin > 0 ? (kpiMax-kpiMin)/2 : 0;
    float macd_centerY = (center - kpiMin) * dotHeight;
    if (isnan(macd_centerY) || isinf(macd_centerY)) {
        macd_centerY = 0;
    }
    
    if (kpiMax > 0+unitPrice) {
        //如果 最大值 > 1/4
        
        float pointY = (0+unitPrice) * dotHeight;
        
        LJDrawPointModel *lineModel = [[LJDrawPointModel alloc] init];
        lineModel.movePoint = CGPointMake(self.bdLayout.x, self.bdLayout.botton - macd_centerY - pointY);
        lineModel.toPoint = CGPointMake(self.bdLayout.w, self.bdLayout.botton - macd_centerY - pointY);
        [lineDashModel.drawArray addObject:lineModel];
        
        CGRect textFrame = CGRectMake(self.bdLayout.innerX, self.bdLayout.botton - macd_centerY - pointY - textRect.size.height, textRect.size.width, textRect.size.height);
        LJDrawTextModel *textModel = [[LJDrawTextModel alloc] init];
        textModel.text = [NSString stringWithFormat:@"%0.2f",unitPrice];
        textModel.textColor = LJ_Red_Color;
        textModel.textRect = textFrame;
        [tempLayoutArray addObject:textModel];
    }
    
    if (kpiMax > 0-unitPrice) {
        //如果 最大值 > 1/4
        
        float pointY = ABS((0-unitPrice) * dotHeight);
        if (self.bdLayout.botton > self.bdLayout.botton - macd_centerY + pointY) {
            
            LJDrawPointModel *lineModel = [[LJDrawPointModel alloc] init];
            lineModel.movePoint = CGPointMake(self.bdLayout.x, self.bdLayout.botton - macd_centerY + pointY);
            lineModel.toPoint = CGPointMake(self.bdLayout.w, self.bdLayout.botton - macd_centerY + pointY);
            [lineDashModel.drawArray addObject:lineModel];
            
            CGRect textFrame = CGRectMake(self.bdLayout.innerX, self.bdLayout.botton - macd_centerY + pointY - textRect.size.height, textRect.size.width, textRect.size.height);
            LJDrawTextModel *textModel = [[LJDrawTextModel alloc] init];
            textModel.text = [NSString stringWithFormat:@"%0.2f",unitPrice];
            textModel.textColor = LJ_Red_Color;
            textModel.textRect = textFrame;
            [tempLayoutArray addObject:textModel];
        }
    }
    //如果Left + 文字宽度 小于最大宽度，就代表可以继续写入
    CGRect textFrame = CGRectMake(self.bdLayout.innerX, self.bdLayout.botton - macd_centerY - textRect.size.height, textRect.size.width, textRect.size.height);
    LJDrawTextModel *textModel = [[LJDrawTextModel alloc] init];
    textModel.text = [NSString stringWithFormat:@"%0.2f",center];
    textModel.textColor = LJ_Red_Color;
    textModel.textRect = textFrame;
    [tempLayoutArray addObject:textModel];
}

/**
 计算MACD顶部高度
 
 @param lineModel 需要计算的Model
 @param isDraw 是否绘制
 
 @return kpi高度
 */
- (float )calculateMACDTopKPIHeight:(LJKLineModel *)lineModel isDraw:(BOOL)isDraw tempKPIDrawArray:(NSMutableArray *)tempKPIDrawArray
{
    LJKLineMACDKPIModel *macdKPIModel = ((LJKLineMACDKPIModel *)self.bdKPIModel);
    if (![lineModel.bdModel isKindOfClass:[LJKLineMACDModel class]]) {
        return 0;
    }
    LJKLineMACDModel *macdModel = (LJKLineMACDModel *)lineModel.bdModel;
    LJDrawTextModel *fontModelMACD = [[LJDrawTextModel alloc] init];
    fontModelMACD.text = [NSString stringWithFormat:@"MACD(%d,%d,%d)",(int)macdKPIModel.shortEMA,(int)macdKPIModel.longEMA,(int)macdKPIModel.m];
    fontModelMACD.textColor = [UIColor jk_colorWithHexString:macdKPIModel.deaHex];
    fontModelMACD.fontSize = self.attfontSize;
    
    LJDrawTextModel *fontModelDIF = [[LJDrawTextModel alloc] init];
    fontModelDIF.text = [@"DIFF:" stringByAppendingString:[NSString stringWithFormat:self.format, [macdModel.dif floatValue]]];
    fontModelDIF.textColor = [UIColor jk_colorWithHexString:macdKPIModel.difHex];
    fontModelDIF.fontSize = self.attfontSize;
    
    LJDrawTextModel *fontModelDEA = [[LJDrawTextModel alloc] init];
    fontModelDEA.text = [@"DEA:" stringByAppendingString:[NSString stringWithFormat:self.format, [macdModel.dea floatValue]]];
    fontModelDEA.textColor = [UIColor jk_colorWithHexString:macdKPIModel.deaHex];
    fontModelDEA.fontSize = self.attfontSize;
    
    LJDrawTextModel *fontModelSTICK = [[LJDrawTextModel alloc] init];
    fontModelSTICK.text = [@"STICK:" stringByAppendingString:[NSString stringWithFormat:self.format, [macdModel.macd floatValue]]];
    fontModelSTICK.textColor = [UIColor jk_colorWithHexString:macdKPIModel.macdHex];
    fontModelSTICK.fontSize = self.attfontSize;
    
    NSMutableArray *layerArray = [CATextLayer lj_calculateTextPoint:@[fontModelMACD,fontModelDIF,fontModelDEA,fontModelSTICK] maxWidth:self.bdLayout.innerW drawY:self.bdLayout.y + self.bdLayout.kpiY reservedWidth:2];
    float height = [layerArray.lastObject floatValue];
    [layerArray removeObject:layerArray.lastObject];
    
    if (isDraw) {
        for (LJDrawTextModel *layerModel in layerArray) {
            [tempKPIDrawArray addObject:layerModel];
        }
    }
    return height;
}

/**
 计算MACD 移动至X轴的值
 
 @param y y
 @return string
 */
- (NSString *)calculateMACDTickY:(float)y
{
    //MACD 最高价、最低价
    NSDictionary *maxMinDic = [self.drawChartArray calculateMACDMaxMin];
    float kpiMax = [[maxMinDic objectForKey:LJ_KPI_Max] floatValue];
    float kpiMin = [[maxMinDic objectForKey:LJ_KPI_Min] floatValue];
    
    double dotHeight = (kpiMax - kpiMin) / self.bdLayout.innerH;
    
    float value = kpiMax - ((y - self.bdLayout.innerY) * dotHeight);
    
    if (value > kpiMax) {
        value = kpiMax;
    }
    if (value < kpiMin) {
        value = kpiMin;
    }
    return [NSString jk_reviseString:value];
}


@end
