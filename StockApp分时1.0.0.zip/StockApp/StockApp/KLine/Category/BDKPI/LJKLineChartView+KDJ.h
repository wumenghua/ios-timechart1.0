//
//  LJKLineChartView+KDJ.h
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/5/31.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "LJKLineChartView.h"

@interface LJKLineChartView (KDJ)

- (void)calculateLJKLineKDJKPIModelPoint:(NSMutableArray *)tempRectArray tempLayoutArray:(NSMutableArray *)tempLayoutArray tempDrawChartArray:(NSMutableArray *)tempDrawChartArray;

/**
 计算KDJ顶部高度
 
 @param lineModel 需要计算的Model
 @param isDraw 是否绘制
 
 @return kpi高度
 */
- (float )calculateKDJTopKPIHeight:(LJKLineModel *)lineModel isDraw:(BOOL)isDraw tempKPIDrawArray:(NSMutableArray *)tempKPIDrawArray;

/**
 计算KDJ 移动至X轴的值
 
 @param y y
 @return string
 */
- (NSString *)calculateKDJTickY:(float)y;

@end
