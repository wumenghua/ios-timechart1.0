//
//  LJKLineChartView+MACD.h
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/5/31.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "LJKLineChartView.h"

@interface LJKLineChartView (MACD)

- (void)calculateLJKLineMACDKPIModelPoint:(NSMutableArray *)tempRectArray tempLayoutArray:(NSMutableArray *)tempLayoutArray tempDrawChartArray:(NSMutableArray *)tempDrawChartArray;

/**
 计算MACD顶部高度
 
 @param lineModel 需要计算的Model
 @param isDraw 是否绘制
 
 @return kpi高度
 */
- (float )calculateMACDTopKPIHeight:(LJKLineModel *)lineModel isDraw:(BOOL)isDraw tempKPIDrawArray:(NSMutableArray *)tempKPIDrawArray;

/**
 计算MACD 移动至X轴的值
 
 @param y y
 @return string
 */
- (NSString *)calculateMACDTickY:(float)y;

@end
