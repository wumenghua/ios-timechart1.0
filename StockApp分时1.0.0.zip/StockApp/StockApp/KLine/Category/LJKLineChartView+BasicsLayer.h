//
//  LJKLineChartView+BasicsLayer.h
//  YiFu
//
//  Created by 伍孟华 on 2018/8/17.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "LJKLineChartView.h"

@interface LJKLineChartView (BasicsLayer)


/**
 绘制边框
 */
- (void)calculateBorder:(NSMutableArray *)tempRectArray tempLayoutArray:(NSMutableArray *)tempLayoutArray;

/**
 重新绘制所有KPI顶部值
 
 @param index 索引
 */
- (void)drawUpdateAllKPI:(NSInteger)index tempRectArray:(NSMutableArray *)tempRectArray tempLayoutArray:(NSMutableArray *)tempLayoutArray tempDrawChartArray:(NSMutableArray *)tempDrawChartArray tempKPIDrawArray:(NSMutableArray *)tempKPIDrawArray;

/**
 设置最右边箭头图标
 
 @param index 数据索引
 */
- (void)drawRightArrowImageView:(NSInteger)index;

//
- (void)draw;

- (void)drawKPILayout:(NSMutableArray *)tempKPIDrawArray;

/**
 重新修改倒计时UILabel
 */
- (void)updateIntervalCount;

@end
