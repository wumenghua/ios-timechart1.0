//
//  LJKLineChartView+MV.m
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/5/31.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "LJKLineChartView+MV.h"
#import "NSMutableArray+MaxMin.h"
#import "UIColor+JKHEX.h"
#import "LJDrawTextModel.h"
#import "CATextLayer+kLineTextLayer.h"

@implementation LJKLineChartView (MV)

- (void)calculateLJKLineMVKPIModelPoint:(NSMutableArray *)tempRectArray tempLayoutArray:(NSMutableArray *)tempLayoutArray tempDrawChartArray:(NSMutableArray *)tempDrawChartArray
{
    //蜡烛图 最高价、最低价
    NSDictionary *maxMinDic = [tempDrawChartArray calculateMVMaxMin];
    
    float kpiMax = [[maxMinDic objectForKey:LJ_KPI_Max] floatValue];
    float kpiMin = [[maxMinDic objectForKey:LJ_KPI_Min] floatValue];
    
    float dotHeight = self.lcLayout.innerH / (kpiMax - kpiMin);
    if (isinf(dotHeight) || isnan(dotHeight)) {
        return;
    }
    
    if (![self.lcKPIModel isKindOfClass:[LJKLineMVKPIModel class]]){
        return;
    }
    for (int i = 0; i < tempDrawChartArray.count; i++) {
        LJKLineModel *model = [tempDrawChartArray objectAtIndex:i];
        if ([model.lcModel isKindOfClass:[LJKLineMVModel class]]) {
            LJKLineMVModel *maModel = (LJKLineMVModel *)model.lcModel;
            
            maModel.volHeight = ([model.vol floatValue] - kpiMin) * dotHeight;
            if (maModel.ma5.length > 0) {
                maModel.ma5_Y = ([maModel.ma5 floatValue] - kpiMin) * dotHeight;
            }
            if (maModel.ma10.length > 0) {
                maModel.ma10_Y = ([maModel.ma10 floatValue] - kpiMin) * dotHeight;
            }
        }
    }
    
    LJDrawModel *greeyCancelModel = [[LJDrawModel alloc] init];
    greeyCancelModel.lineWidth = 1.0;
    greeyCancelModel.lineType = LJ_ENUM_DrawModel_Pillar;
    greeyCancelModel.fillColor = LJ_Blue_Color;
    greeyCancelModel.lineColor = greeyCancelModel.fillColor;
    [tempRectArray addObject:greeyCancelModel];
    
    LJDrawModel *redCancelModel = [[LJDrawModel alloc] init];
    redCancelModel.lineWidth = 1.0;
    redCancelModel.lineType = LJ_ENUM_DrawModel_Pillar;
    redCancelModel.fillColor = [UIColor clearColor];
    redCancelModel.lineColor = LJ_Red_Color;
    [tempRectArray addObject:redCancelModel];
    
    //
    LJKLineMVKPIModel *mvKPIModel = ((LJKLineMVKPIModel *)self.lcKPIModel);
    
    LJDrawModel *ma5LineModel = [[LJDrawModel alloc] init];
    ma5LineModel.lineWidth = 1.0;
    ma5LineModel.fillColor = [UIColor clearColor];
    ma5LineModel.lineColor = [UIColor jk_colorWithHexString:mvKPIModel.mv5Hex];
    [tempRectArray addObject:ma5LineModel];
    
    LJDrawModel *ma10LineModel = [[LJDrawModel alloc] init];
    ma10LineModel.lineWidth = 1.0;
    ma10LineModel.fillColor = [UIColor clearColor];
    ma10LineModel.lineColor = [UIColor jk_colorWithHexString:mvKPIModel.mv10Hex];
    [tempRectArray addObject:ma10LineModel];
    
    float tempX = self.lcLayout.innerW;
    float downTempX = tempX;
    // 从上 至 下绘制，与其他绘图方式不一样；
    for(NSInteger idx = tempDrawChartArray.count-1; idx >= 0; idx--){
        
        tempX -= self.kLineWidth;
        
        LJKLineModel *model = [tempDrawChartArray objectAtIndex:idx];
        LJKLineMVModel *mvModel = (LJKLineMVModel *)model.lcModel;
        if ([model.lcModel isKindOfClass:[LJKLineMVModel class]]) {
            LJKLineModel *downModel = nil;
            LJKLineMVModel *downMvModel = nil;
            if (idx - 1 >= 0) {
                downModel = [tempDrawChartArray objectAtIndex:idx - 1];
                downMvModel = (LJKLineMVModel *)downModel.lcModel;
                
                downTempX = tempX - self.kLineWidth;
            }
            
            float x , y , w , h;
            x = tempX + (self.kLineWidth * self.kLineInterval);
            y = self.lcLayout.botton - mvModel.volHeight;
            w = self.kLineWidth - ((self.kLineWidth * self.kLineInterval) * 2);
            h = mvModel.volHeight;
            
            //绘制柱体
            LJDrawRectModel *rectModel = [[LJDrawRectModel alloc] init];
            rectModel.rect = CGRectMake(x, y, w, h);
            if (model.candleModel.kLineType == LJ_KLine_Down_Type) {
                [greeyCancelModel.drawArray addObject:rectModel];
            }else{
                [redCancelModel.drawArray addObject:rectModel];
            }
            
            //绘制MA5均线
            if ([downMvModel isKindOfClass:[LJKLineMVModel class]]) {
                if (mvModel.ma5.length > 0 &&  downMvModel.ma5.length > 0) {
                    CGPoint moveToPoint = CGPointMake(tempX + (self.kLineWidth/2), self.lcLayout.botton - mvModel.ma5_Y);
                    CGPoint toPoint = CGPointMake(downTempX + (self.kLineWidth/2), self.lcLayout.botton - downMvModel.ma5_Y);
                    
                    LJDrawPointModel *pointModle = [[LJDrawPointModel alloc] init];
                    pointModle.movePoint = moveToPoint;
                    pointModle.toPoint = toPoint;
                    [ma5LineModel.drawArray addObject:pointModle];
                }
            }
            
            //绘制MA10均线
            if ([downMvModel isKindOfClass:[LJKLineMVModel class]]) {
                if (mvModel.ma10.length > 0 && downMvModel.ma10.length > 0) {
                    CGPoint moveToPoint = CGPointMake(tempX + (self.kLineWidth/2), self.lcLayout.botton - mvModel.ma10_Y);
                    CGPoint toPoint = CGPointMake(downTempX + (self.kLineWidth/2), self.lcLayout.botton - downMvModel.ma10_Y);
                    
                    LJDrawPointModel *pointModle = [[LJDrawPointModel alloc] init];
                    pointModle.movePoint = moveToPoint;
                    pointModle.toPoint = toPoint;
                    [ma10LineModel.drawArray addObject:pointModle];
                }
            }
        }
    }
    
    
    if (tempDrawChartArray.count > 0) {
        //绘制MV左边价格
        [self drawKLineHorLayer:kpiMax kpiMin:kpiMin tempRectArray:tempRectArray tempLayoutArray:tempLayoutArray];
    }
}

/**
 绘制MV左边价格
 
 @param kpiMax 最高价
 @param kpiMin 最低价
 */
- (void)drawKLineHorLayer:(float)kpiMax kpiMin:(float)kpiMin tempRectArray:(NSMutableArray *)tempRectArray tempLayoutArray:(NSMutableArray *)tempLayoutArray
{
    LJDrawModel *lineDashModel = [[LJDrawModel alloc] init];
    lineDashModel.lineWidth = 0.2;
    lineDashModel.lineType = LJ_ENUM_DrawModel_Dash;
    lineDashModel.fillColor = [UIColor clearColor];
    lineDashModel.lineColor = LJ_Red_Color;
    [tempRectArray addObject:lineDashModel];
    
    //生成 单位价格
    int unitPrice = (kpiMax - kpiMin) / 2;
    //求得价格和百分比的rect
    CGRect textRect = [NSString jk_rectOfNSString:[NSString stringWithFormat:@"%d",unitPrice] attribute:self.attribute];
    
    float dotHeight = self.lcLayout.innerH / (kpiMax - kpiMin);
    float pointY = (unitPrice - kpiMin) * dotHeight;
    if (isnan(pointY) || isinf(pointY)) {
        pointY = 0;
    }
    LJDrawPointModel *lineModel = [[LJDrawPointModel alloc] init];
    lineModel.movePoint = CGPointMake(self.lcLayout.x, self.lcLayout.botton - pointY);
    lineModel.toPoint = CGPointMake(self.lcLayout.w, self.lcLayout.botton - pointY);
    [lineDashModel.drawArray addObject:lineModel];
    
    CGRect textFrame = CGRectMake(self.lcLayout.innerX, self.lcLayout.botton - pointY - textRect.size.height, textRect.size.width, textRect.size.height);
    LJDrawTextModel *textModel = [[LJDrawTextModel alloc] init];
    textModel.text = [NSString stringWithFormat:@"%d",unitPrice];
    textModel.textColor = LJ_Red_Color;
    textModel.textRect = textFrame;
    [tempLayoutArray addObject:textModel];
}

/**
 计算MV顶部高度
 
 @param lineModel 需要计算的Model
 @param isDraw 是否绘制
 
 @return kpi高度
 */
- (float )calculateMVTopKPIHeight:(LJKLineModel *)lineModel isDraw:(BOOL)isDraw tempKPIDrawArray:(NSMutableArray *)tempKPIDrawArray
{
    
    LJKLineMVKPIModel *mvKPIModel = ((LJKLineMVKPIModel *)self.lcKPIModel);
    if (![lineModel.lcModel isKindOfClass:[LJKLineMVModel class]]) {
        return 0;
    }
    LJKLineMVModel *mvModel = (LJKLineMVModel *)lineModel.lcModel;
    
    LJDrawTextModel *fontModelMV = [[LJDrawTextModel alloc] init];
    fontModelMV.text = [NSString stringWithFormat:@"MV(%d,%d)",(int)mvKPIModel.mv5,(int)mvKPIModel.mv10];
    fontModelMV.textColor = [UIColor jk_colorWithHexString:mvKPIModel.mv10Hex];
    fontModelMV.fontSize = self.attfontSize;
    
    LJDrawTextModel *fontModelMA5 = [[LJDrawTextModel alloc] init];
    fontModelMA5.text = [NSString stringWithFormat:self.format, [mvModel.ma5 floatValue]];
    fontModelMA5.textColor = [UIColor jk_colorWithHexString:mvKPIModel.mv5Hex];
    fontModelMA5.fontSize = self.attfontSize;
    
    LJDrawTextModel *fontModelMA10 = [[LJDrawTextModel alloc] init];
    fontModelMA10.text = [NSString stringWithFormat:self.format, [mvModel.ma10 floatValue]];
    fontModelMA10.textColor = [UIColor jk_colorWithHexString:mvKPIModel.mv10Hex];
    fontModelMA10.fontSize = self.attfontSize;
    
    NSMutableArray *layerArray = [CATextLayer lj_calculateTextPoint:@[fontModelMV,fontModelMA5,fontModelMA10] maxWidth:self.lcLayout.innerW drawY:self.lcLayout.y + self.lcLayout.kpiY reservedWidth:2];
    float height = [layerArray.lastObject floatValue];
    [layerArray removeObject:layerArray.lastObject];
    
    if (isDraw) {
        for (LJDrawTextModel *layerModel in layerArray) {
            [tempKPIDrawArray addObject:layerModel];
        }
    }
    return height;
}

/**
 计算MV 移动至X轴的值
 
 @param y y
 @return string
 */
- (NSString *)calculateMVTickY:(float)y
{
    //MV 最高价、最低价
    NSDictionary *maxMinDic = [self.drawChartArray calculateMVMaxMin];
    float kpiMax = [[maxMinDic objectForKey:LJ_KPI_Max] floatValue];
    float kpiMin = [[maxMinDic objectForKey:LJ_KPI_Min] floatValue];
    
    double dotHeight = (kpiMax - kpiMin) / self.lcLayout.innerH;
    
    float value = kpiMax - ((y - self.lcLayout.innerY) * dotHeight);
    
    if (value > kpiMax) {
        value = kpiMax;
    }
    if (value < kpiMin) {
        value = kpiMin;
    }
    return [NSString jk_reviseString:value];
}

@end
