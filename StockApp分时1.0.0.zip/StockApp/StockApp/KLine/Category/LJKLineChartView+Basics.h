//
//  LJKLineChartView+Basics.h
//  YiFu
//
//  Created by 伍孟华 on 2018/8/16.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "LJKLineChartView.h"

@interface LJKLineChartView (Basics)

/**
 初始化趋势指标
 */
- (void)setupQSLayer;
- (void)setupQSLayerHeight:(float)kpiHeight;
- (void)setupQSHide:(BOOL)hide;

/**
 初始化量仓指标
 */
- (void)setupLCLayer;
- (void)setupLCLayerHeight:(float)kpiHeight;
- (void)setupLCHide:(BOOL)hide;

/**
 初始化摆动指标
 */
- (void)setupBDLayer;
- (void)setupBDLayerHeight:(float)kpiHeight;
- (void)setupBDHide:(BOOL)hide;

//趋势
-(NSInteger)qsKPIIndex;
- (void)setQsKPIIndex:(NSInteger)qsKPIIndex;

//量仓
-(NSInteger)lcKPIIndex;
- (void)setLcKPIIndex:(NSInteger)lcKPIIndex;

//摆动
-(NSInteger)bdKPIIndex;
- (void)setBdKPIIndex:(NSInteger)bdKPIIndex;

//重置比例
- (void)setupLayerScale;

/**
 计算K线移动值X轴趋势指标对应值
 
 @param y y
 @return string
 */
- (NSString *)calculateKLine_QSKPI:(float)y;


#pragma mark - 画线分析
//----------------------------------------------------------------
/**
 根据K线 X轴位置获缩影
 
 @param x X轴位置
 @return 缩影对应对象
 */
- (LJKLineModel *)getKLinePointModel:(CGFloat)x;
/**
 根据价格计算Y轴位置

 @param price 价格
 @return Y轴
 */
- (float)findTImeLayerAtWill_Price_Clp:(float)price;
/**
 根据Y值计算价格
 
 @param y Y
 @return 价格
 */
- (CGFloat)calculateKLine_QS_Y_Price:(CGFloat)y;

/**
 返回趋势指标最大值、最小值
 
 @return NSDictionary
 */
- (NSDictionary *)calculateKLine_QSMaxMinKPI;

//----------------------------------------------------------------

/**
 计算K线移动值X轴趋势指标对应值
 
 @param y y
 @return string
 */
- (NSString *)calculateKLine_LCKPI:(float)y;

/**
 计算K线移动值X轴趋势指标对应值
 
 @param y y
 @return string
 */
- (NSString *)calculateKLine_BDKPI:(float)y;


/**
 清除画线
 
 @param layerArray layerArray
 */
- (void)clearLayerArray:(NSMutableArray *)layerArray;


@end
