//
//  LJKLineRSIKPIModel.m
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/5/31.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "LJKLineRSIKPIModel.h"
#import "NSString+Decimal.h"
#import "LJKLineRSIModel.h"

@implementation LJKLineRSIKPIModel

-(void)calculateKLineKPIModel:(NSMutableArray *)kLineArray
{
    LJKLineModel *firstKlineModel = kLineArray.firstObject;
    if ([firstKlineModel.bdModel isKindOfClass:[LJKLineRSIModel class]]) {
        LJKLineModel *lastkLineModel = kLineArray.lastObject;
        if (lastkLineModel && ![lastkLineModel.bdModel isKindOfClass:[LJKLineRSIModel class]]) {
            lastkLineModel.bdModel = [[LJKLineRSIModel alloc] init];
        }
        //如果最后一条存在，那么就计算最后一条bar的数据
        [self calculateRSILastModel:kLineArray];
    }else{
        //最后一条不为空，那么代表整条数据全部为空，重新计算
        for (int i = 0; i < kLineArray.count; i++) {
            LJKLineModel *klineModel = kLineArray[i];
            if (![klineModel.bdModel isKindOfClass:[LJKLineRSIModel class]]) {
                klineModel.bdModel = [[LJKLineRSIModel alloc] init];
            }
            if (i == 0)
            {
                LJKLineRSIModel *rsiModel = (LJKLineRSIModel *)klineModel.bdModel;
                
                rsiModel.rsi_6_A = [klineModel.clp doubleValue];
                rsiModel.rsi_6_B = [klineModel.clp doubleValue];
                
                rsiModel.rsi_12_A = [klineModel.clp doubleValue];
                rsiModel.rsi_12_B = [klineModel.clp doubleValue];
                
                rsiModel.rsi_24_A = [klineModel.clp doubleValue];
                rsiModel.rsi_24_B = [klineModel.clp doubleValue];
            }else {
                [self calculateRSIModel:kLineArray model:klineModel idx:i];
            }
        }
    }
}

/**
 计算RSI基础数据 最后一条数据
 */
- (void)calculateRSILastModel:(NSMutableArray *)kLineArray
{
    LJKLineModel *model = kLineArray.lastObject;
    if (kLineArray.count > 0) {
        [self calculateRSIModel:kLineArray model:model idx:kLineArray.count-1];
    }
}

- (void)calculateRSIModel:(NSMutableArray *)kLineArray model:(LJKLineModel *)model idx:(NSUInteger)idx
{
    
    __block float rsi_6_num = self.n1;
    __block float rsi_12_num = self.n2;
    __block float rsi_24_num = self.n3;
    
    LJKLineRSIModel *rsiModel = (LJKLineRSIModel *)model.bdModel;
    
    LJKLineModel *upModel = kLineArray[idx - 1];
    LJKLineRSIModel *upRSIModel = (LJKLineRSIModel *)upModel.bdModel;
    if (![rsiModel isKindOfClass:[LJKLineRSIModel class]] || ![upRSIModel isKindOfClass:[LJKLineRSIModel class]]) {
        return;
    }
    //清空重置数据
    double max = MAX(([model.clp doubleValue] - [upModel.clp doubleValue]), 0);
    double abs = fabs([model.clp doubleValue] - [upModel.clp doubleValue]);
    rsiModel.rsi_6_A = (1 * max + (rsi_6_num - 1) * upRSIModel.rsi_6_A) / rsi_6_num;
    rsiModel.rsi_6_B = (1 * abs + (rsi_6_num - 1) * upRSIModel.rsi_6_B) / rsi_6_num;
    rsiModel.rsi_6 = [NSString jk_reviseString:rsiModel.rsi_6_A * 100 / rsiModel.rsi_6_B];
    
    rsiModel.rsi_12_A = (1 * max + (rsi_12_num - 1) * upRSIModel.rsi_12_A) / rsi_12_num;
    rsiModel.rsi_12_B = (1 * abs + (rsi_12_num - 1) * upRSIModel.rsi_12_B) / rsi_12_num;
    rsiModel.rsi_12 = [NSString jk_reviseString:rsiModel.rsi_12_A * 100 / rsiModel.rsi_12_B];
    
    rsiModel.rsi_24_A = (1 * max + (rsi_24_num - 1) * upRSIModel.rsi_24_A) / rsi_24_num;
    rsiModel.rsi_24_B = (1 * abs + (rsi_24_num - 1) * upRSIModel.rsi_24_B) / rsi_24_num;
    rsiModel.rsi_24 = [NSString jk_reviseString:rsiModel.rsi_24_A * 100 / rsiModel.rsi_24_B];
    
}

@end
