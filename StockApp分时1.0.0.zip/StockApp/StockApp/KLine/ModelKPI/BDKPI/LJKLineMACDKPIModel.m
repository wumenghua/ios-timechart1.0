//
//  LJKLineMACDKPIModel.m
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/5/31.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "LJKLineMACDKPIModel.h"
#import "LJKLineMACDModel.h"
#import "NSString+Decimal.h"

@implementation LJKLineMACDKPIModel

-(void)calculateKLineKPIModel:(NSMutableArray *)kLineArray
{
//    LJKLineModel *lastkLineModel = kLineArray.lastObject;
//    if (lastkLineModel && ![lastkLineModel.bdModel isKindOfClass:[LJKLineMACDModel class]]) {
//        lastkLineModel.bdModel = [[LJKLineMACDModel alloc] init];
//        if (kLineArray.count-1 > 0) {
//            lastkLineModel = [kLineArray objectAtIndex:kLineArray.count-1];
//        }
//    }
//    LJKLineMACDModel *macdModel = (LJKLineMACDModel *)lastkLineModel.bdModel;
//    if (macdModel.ema12.length > 0 && macdModel.ema26 > 0) {
//        [self calculateMACDLastModel:kLineArray];
//    }
    
    LJKLineModel *firstKlineModel = kLineArray.firstObject;
    if ([firstKlineModel.bdModel isKindOfClass:[LJKLineMACDModel class]]) {
        LJKLineModel *lastkLineModel = kLineArray.lastObject;
        if (lastkLineModel && ![lastkLineModel.bdModel isKindOfClass:[LJKLineMACDModel class]]) {
            lastkLineModel.bdModel = [[LJKLineMACDModel alloc] init];
        }
        //如果最后一条存在，那么就计算最后一条bar的数据
        [self calculateMACDLastModel:kLineArray];
    }else{
        //最后一条不为空，那么代表整条数据全部为空，重新计算
        for (int i = 0; i < kLineArray.count; i++) {
            LJKLineModel *klineModel = kLineArray[i];
            if (![klineModel.bdModel isKindOfClass:[LJKLineMACDModel class]]) {
                klineModel.bdModel = [[LJKLineMACDModel alloc] init];
            }
            if (i == 0) {
                LJKLineMACDModel *macdModel = (LJKLineMACDModel *)klineModel.bdModel;
                macdModel.ema12 = klineModel.clp;
                macdModel.ema26 = klineModel.clp;
                macdModel.dif = @"";
                macdModel.dea = @"";
                macdModel.macd = @"";
            }else{
                [self calculateMACDModel:kLineArray model:klineModel idx:i];
            }
        }
    }
}

/**
 计算MACD基础数据 最后一条数据
 */
- (void)calculateMACDLastModel:(NSMutableArray *)kLineArray
{
    LJKLineModel *model = kLineArray.lastObject;
    if (kLineArray.count > 0) {
        [self calculateMACDModel:kLineArray model:model idx:kLineArray.count-1];
    }
}

- (void)calculateMACDModel:(NSMutableArray *)kLineArray model:(LJKLineModel *)model idx:(NSUInteger)idx
{
    
    float shortEMA = self.shortEMA;
    float longEMA = self.longEMA;
    float m = self.m;
    
    LJKLineModel *upKLineModel = [kLineArray objectAtIndex:idx-1];
    
    LJKLineMACDModel *macdModel = (LJKLineMACDModel *)model.bdModel;
    LJKLineMACDModel *upMacdModel = (LJKLineMACDModel *)upKLineModel.bdModel;
    if ([upKLineModel.bdModel isKindOfClass:[LJKLineMACDModel class]]) {
        
        macdModel.ema12 = (@((2.0 * model.clp.doubleValue + (shortEMA-1.0) * upMacdModel.ema12.doubleValue)/(shortEMA+1.0))).stringValue;
        macdModel.ema26 = (@((2.0 * model.clp.doubleValue + (longEMA-1.0) * upMacdModel.ema26.doubleValue)/(longEMA+1.0))).stringValue;
        
        macdModel.dif = (@(macdModel.ema12.doubleValue - macdModel.ema26.doubleValue)).stringValue;
        macdModel.dea = (@(upMacdModel.dea.doubleValue * ((m-1.0)/(m+1.0)) + (2/(m+1.0)) * macdModel.dif.doubleValue)).stringValue;
        
        macdModel.macd = (@(2*(macdModel.dif.doubleValue - macdModel.dea.doubleValue))).stringValue;
    }
}

@end
