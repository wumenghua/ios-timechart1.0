//
//  LJKLineKDJKPIModel.m
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/5/31.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "LJKLineKDJKPIModel.h"
#import "NSString+Decimal.h"
#import "LJKLineKDJModel.h"

@implementation LJKLineKDJKPIModel

-(void)calculateKLineKPIModel:(NSMutableArray *)kLineArray
{
    LJKLineModel *firstKlineModel = kLineArray.firstObject;
    if ([firstKlineModel.bdModel isKindOfClass:[LJKLineKDJModel class]]) {
        LJKLineModel *lastkLineModel = kLineArray.lastObject;
        if (lastkLineModel && ![lastkLineModel.bdModel isKindOfClass:[LJKLineKDJModel class]]) {
            lastkLineModel.bdModel = [[LJKLineKDJModel alloc] init];
        }
        //如果最后一条存在，那么就计算最后一条bar的数据
        [self calculateKDJLastModel:kLineArray];
    }else{
        //最后一条不为空，那么代表整条数据全部为空，重新计算
        for (int i = 0; i < kLineArray.count; i++) {
            LJKLineModel *klineModel = kLineArray[i];
            if (![klineModel.bdModel isKindOfClass:[LJKLineKDJModel class]]) {
                klineModel.bdModel = [[LJKLineKDJModel alloc] init];
            }
            [self calculateKDJModel:kLineArray model:klineModel idx:i];
        }
    }
}

/**
 计算KDJ基础数据 最后一条数据
 */
- (void)calculateKDJLastModel:(NSMutableArray *)kLineArray {
    
    LJKLineModel *model = kLineArray.lastObject;
    if (kLineArray.count > 0) {
        [self calculateKDJModel:kLineArray model:model idx:kLineArray.count-1];
    }
}

- (void)calculateKDJModel:(NSMutableArray *)kLineArray model:(LJKLineModel *)model idx:(NSUInteger)idx
{
    
    float rsv_d_num = self.m1;
    float rsv_j_num = self.m2;
    float rsv_k_num = self.n;
    if (idx < rsv_k_num) {
        rsv_k_num = idx;
    }
    float maxHipValue;
    float minLopValue;
    if (idx > 0) {
        NSMutableArray *maxminArray = [NSMutableArray array];
        for (NSInteger i = idx-(rsv_k_num - 1); i <= idx; i++) {
            LJKLineModel *chartModel = [kLineArray objectAtIndex:i];
            [maxminArray addObject:chartModel.hip];
            [maxminArray addObject:chartModel.lop];
        }
        maxHipValue = [[maxminArray valueForKeyPath:@"@max.floatValue"] floatValue];
        minLopValue = [[maxminArray valueForKeyPath:@"@min.floatValue"] floatValue];
    }else{
        maxHipValue = [model.hip floatValue];
        minLopValue = [model.lop floatValue];
    }
    
    LJKLineKDJModel *kdjModel = (LJKLineKDJModel *)model.bdModel;
    
    kdjModel.rsv_9 = [NSString jk_reviseString:(([model.clp floatValue] - minLopValue)/(maxHipValue - minLopValue)*100)];
    
    LJKLineKDJModel *upKdjModel;
    if (idx > 0) {
        LJKLineModel *upChartModel = [kLineArray objectAtIndex:idx-1];
        upKdjModel = (LJKLineKDJModel *)upChartModel.bdModel;
    }
    
    double previousK = idx == 0 ? 50 : upKdjModel.kdj_K.doubleValue;
    kdjModel.kdj_K = [NSString jk_reviseString:(kdjModel.rsv_9.floatValue + (rsv_d_num-1) * previousK )/rsv_d_num];
    
    double previousD = idx == 0 ? 50 : upKdjModel.kdj_D.doubleValue;
    kdjModel.kdj_D = [NSString jk_reviseString:(kdjModel.kdj_K.floatValue + (rsv_j_num-1) * previousD)/rsv_j_num];
    
    kdjModel.kdj_J = [NSString jk_reviseString:3 * kdjModel.kdj_K.floatValue - 2 * kdjModel.kdj_D.floatValue];
}

@end
