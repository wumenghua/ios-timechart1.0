//
//  LJKLineKDJKPIModel.h
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/5/31.
//  Copyright © 2018年 伍孟华. All rights reserved.
//  KDJ指标 参数

#import "LJKLineKPIBaseModel.h"

@interface LJKLineKDJKPIModel : LJKLineKPIBaseModel

//n
@property(nonatomic ,assign) float n;
//m1
@property(nonatomic ,assign) float m1;
//m2
@property(nonatomic ,assign) float m2;


//nHex
@property(nonatomic ,strong) NSString *nHex;
//m1Hex
@property(nonatomic ,strong) NSString *m1Hex;
//m2Hex
@property(nonatomic ,strong) NSString *m2Hex;

@end
