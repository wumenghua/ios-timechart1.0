//
//  LJKLineMACDKPIModel.h
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/5/31.
//  Copyright © 2018年 伍孟华. All rights reserved.
//  MACD指标 参数

#import "LJKLineKPIBaseModel.h"

@interface LJKLineMACDKPIModel : LJKLineKPIBaseModel

@property(nonatomic ,assign) float shortEMA;

@property(nonatomic ,assign) float longEMA;

@property(nonatomic ,assign) float m;

//dif、dea 颜色值
@property(nonatomic ,strong) NSString *difHex;

@property(nonatomic ,strong) NSString *deaHex;

@property(nonatomic ,strong) NSString *macdHex;

//macd上涨、macd下跌 颜色值
@property(nonatomic ,strong) NSString *macdUpHex;

@property(nonatomic ,strong) NSString *macdDNHex;


@end
