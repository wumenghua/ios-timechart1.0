//
//  LJKLineRSIKPIModel.h
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/5/31.
//  Copyright © 2018年 伍孟华. All rights reserved.
//  RSI指标 参数

#import "LJKLineKPIBaseModel.h"

@interface LJKLineRSIKPIModel : LJKLineKPIBaseModel

//n1
@property(nonatomic ,assign) float n1;
//n2
@property(nonatomic ,assign) float n2;
//n3
@property(nonatomic ,assign) float n3;


//n1Hex
@property (nonatomic, strong) NSString *n1Hex;
//n2Hex
@property (nonatomic, strong) NSString *n2Hex;
//n3Hex
@property (nonatomic, strong) NSString *n3Hex;

@end
