//
//  LJKLineKPIBaseModel.h
//  YiFu
//
//  Created by 伍孟华 on 2018/8/16.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LJKLineModel.h"
#import "NSString+Decimal.h"

@interface LJKLineKPIBaseModel : NSObject

@property (nonatomic ,assign) int kpiType;


/**
 计算所有数据KPI

 @param kLineArray kLineArray
 */
-(void)calculateKLineKPIModel:(NSMutableArray *)kLineArray;



/**
 计算最后一条数据KPI

 @param kLineArray kLineArray
 */
- (void)calculateMALastModel:(NSMutableArray *)kLineArray;

@end
