//
//  LJKLineMVKPIModel.h
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/5/31.
//  Copyright © 2018年 伍孟华. All rights reserved.
//  MV指标 参数

#import "LJKLineKPIBaseModel.h"

@interface LJKLineMVKPIModel : LJKLineKPIBaseModel

@property(nonatomic ,assign) float mv5;
@property(nonatomic ,strong) NSString *mv5Hex;

@property(nonatomic ,assign) float mv10;
@property(nonatomic ,strong) NSString *mv10Hex;


@end
