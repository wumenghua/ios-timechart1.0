//
//  LJKLineMVKPIModel.m
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/5/31.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "LJKLineMVKPIModel.h"
#import "NSString+Decimal.h"
#import "LJKLineMVModel.h"

@implementation LJKLineMVKPIModel

-(void)calculateKLineKPIModel:(NSMutableArray *)kLineArray
{
    LJKLineModel *firstKlineModel = kLineArray.firstObject;
    if ([firstKlineModel.lcModel isKindOfClass:[LJKLineMVModel class]]) {
        LJKLineModel *lastkLineModel = kLineArray.lastObject;
        if (lastkLineModel && ![lastkLineModel.lcModel isKindOfClass:[LJKLineMVModel class]]) {
            lastkLineModel.lcModel = [[LJKLineMVModel alloc] init];
        }
        //如果最后一条存在，那么就计算最后一条bar的数据
        [self calculateMVLastModel:kLineArray];
    }else{
        //最后一条不为空，那么代表整条数据全部为空，重新计算
        for (int i = 0; i < kLineArray.count; i++) {
            LJKLineModel *klineModel = kLineArray[i];
            if (![klineModel.lcModel isKindOfClass:[LJKLineMVModel class]]) {
                klineModel.lcModel = [[LJKLineMVModel alloc] init];
            }
            if (i == 0) {
                LJKLineMVModel *mvModel = (LJKLineMVModel *)klineModel.lcModel;
                mvModel.ma5 = [NSString jk_reviseString:[klineModel.vol floatValue]];
                mvModel.ma10 = [NSString jk_reviseString:[klineModel.vol floatValue]];
            }else{
                [self calculateMVModel:kLineArray model:klineModel idx:i];
            }
        }
    }
}

/**
 计算基础数据 mv5 、 ma10 最后一条数据
 */
- (void)calculateMVLastModel:(NSMutableArray *)kLineArray
{
    LJKLineModel *model = kLineArray.lastObject;
    if (kLineArray.count > 0) {
        [self calculateMVModel:kLineArray model:model idx:kLineArray.count-1];
    }
}

- (void)calculateMVModel:(NSMutableArray *)kLineArray model:(LJKLineModel *)model idx:(NSUInteger)idx
{
    float mv5 = self.mv5;
    float mv10 = self.mv10;
    
    if (idx < mv5) {
        mv5 = idx;
    }
    if (idx < mv10) {
        mv10 = idx;
    }
    
    LJKLineMVModel *mvModel = (LJKLineMVModel *)model.lcModel;
    if (idx >= mv5) {
        float mv_MA5Total = 0.0f;
        //计算 10 日以内成交量平均值
        for (int i = (int)idx-mv5; i < idx; i++) {
            LJKLineModel *chartModel = [kLineArray objectAtIndex:i];
            mv_MA5Total += [chartModel.vol floatValue];
        }
        mvModel.ma5 = [NSString jk_reviseString:mv_MA5Total / mv5];
    }
    
    if (idx >= mv10) {
        float mv_MA10Total = 0.0f;
        //计算 20 日以内成交量平均值
        for (int i = (int)idx-mv10; i < idx; i++) {
            LJKLineModel *chartModel = [kLineArray objectAtIndex:i];
            mv_MA10Total += [chartModel.vol floatValue];
        }
        mvModel.ma10 = [NSString jk_reviseString:mv_MA10Total / mv10];
    }
}


@end
