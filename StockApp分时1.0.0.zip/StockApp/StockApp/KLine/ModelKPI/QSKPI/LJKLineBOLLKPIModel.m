//
//  LJKLineBOLLKPIModel.m
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/5/31.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "LJKLineBOLLKPIModel.h"
#import "LJKLineBOLLModel.h"
#import "NSString+Decimal.h"

@implementation LJKLineBOLLKPIModel

-(void)calculateKLineKPIModel:(NSMutableArray *)kLineArray
{
    LJKLineModel *lastkLineModel = kLineArray.lastObject;
    if (lastkLineModel && ![lastkLineModel.qsModel isKindOfClass:[LJKLineBOLLModel class]]) {
        lastkLineModel.qsModel = [[LJKLineBOLLModel alloc] init];
        if (kLineArray.count-1 > 0) {
            lastkLineModel = [kLineArray objectAtIndex:kLineArray.count-1];
        }
    }
    LJKLineBOLLModel *lastBollModel = (LJKLineBOLLModel *)lastkLineModel.qsModel;
    
    if (lastBollModel.boll_UP.length > 0 && lastBollModel.boll_MB.length > 0 && lastBollModel.boll_DN.length > 0) {
        [self calculateMALastModel:kLineArray];
    }else{
        //最后一条不为空，那么代表整条数据全部为空，重新计算
        for (int i = 0; i < kLineArray.count; i++) {
            LJKLineModel *klineModel = kLineArray[i];
            if (![klineModel.qsModel isKindOfClass:[LJKLineBOLLModel class]]) {
                klineModel.qsModel = [[LJKLineBOLLModel alloc] init];
            }
            //LJKLineBOLLModel *bollModel = (LJKLineBOLLModel *)klineModel.qsModel;
        
            NSInteger bollNum_P = self.bollP;
            NSInteger bollNum_MA = self.bollMa;
            NSInteger bollNum_MD = self.bollMb;
            [self calculateBOLLModel:kLineArray model:klineModel idx:i bollNum_P:bollNum_P bollNum_MA:bollNum_MA bollNum_MD:bollNum_MD];
            
//            if (i < bollNum_MA) {
//                bollNum_MA = i;
//            }
//            if (i < bollNum_MD) {
//                bollNum_MD = i;
//            }
//
//            if (i == 0) {
//                bollModel.boll_MA = klineModel.clp;
//
//                double powSumPrice = pow(([klineModel.clp floatValue] - bollModel.boll_MA.floatValue),2);
//                bollModel.boll_MD = [NSString jk_reviseString:sqrt(powSumPrice)];
//
//                bollModel.boll_MB = bollModel.boll_MA;
//                bollModel.boll_UP = [NSString jk_reviseString:bollModel.boll_MB.floatValue + bollNum_P * bollModel.boll_MD.floatValue];
//                bollModel.boll_DN = [NSString jk_reviseString:bollModel.boll_MB.floatValue - bollNum_P * bollModel.boll_MD.floatValue];
//            }else{
//                [self calculateBOLLModel:kLineArray model:klineModel idx:i bollNum_P:bollNum_P bollNum_MA:bollNum_MA bollNum_MD:bollNum_MD];
//            }
        }
    }
}

- (void)calculateMALastModel:(NSMutableArray *)kLineArray
{
    if (kLineArray.count > 0) {
        LJKLineModel *model = kLineArray.lastObject;
        
        float bollNum_P = self.bollP;
        float bollNum_MA = self.bollMa;
        float bollNum_MD = self.bollMb;
        [self calculateBOLLModel:kLineArray model:model idx:kLineArray.count-1 bollNum_P:bollNum_P bollNum_MA:bollNum_MA bollNum_MD:bollNum_MD];
    }
}

- (void)calculateBOLLModel:(NSMutableArray *)kLineArray model:(LJKLineModel *)model idx:(NSUInteger)idx bollNum_P:(NSInteger)bollNum_P bollNum_MA:(NSInteger)bollNum_MA bollNum_MD:(float)bollNum_MD
{
    
    LJKLineBOLLModel *bollModel = (LJKLineBOLLModel *)model.qsModel;
    
    // 计算MA
    double MA = [self getBOLLMA:kLineArray currentDay:idx aveDay:bollNum_MA];
    // 计算MD
    double MD = 0;
    double sum = 0;
    NSInteger k = idx - bollNum_MA + 1;
    if (k < 0) {
        k = 0;
    }
    for (NSInteger j=k; j <= idx; j++) {
        LJKLineModel *j_model = kLineArray[j];
        sum +=  pow([j_model.clp doubleValue] - MA, 2);
    }
    MD = sqrt(sum / bollNum_MA);
    // 计算MB
    double MB = [self getBOLLMA:kLineArray currentDay:idx aveDay:(bollNum_MD - 1)];
    // 计算UP
    double UP = MB - bollNum_P * MD;
    // 计算DN
    double DN = MB + bollNum_P * MD;
    //BOLL model 赋值
    bollModel.boll_MB = @(MB).stringValue;
    bollModel.boll_UP = @(UP).stringValue;
    bollModel.boll_DN = @(DN).stringValue;
    
    
//    double sum = 0;
//    for (NSInteger i = idx-(bollNum_MA-1); i<=idx; i++) {
//        if (i >= 0 && i < kLineArray.count) {
//            LJKLineModel *chartModel = kLineArray[i];
//            sum += [chartModel.clp floatValue];
//        }
//    }
//    bollModel.boll_MA = [NSString jk_reviseString:sum/bollNum_MA];
//
//    double powSumPrice = 0;
//    NSInteger j = idx - (bollNum_MD+1);
//    for (NSInteger i = j; i <= idx; i++) {
//        if (i >=0 && i < kLineArray.count) {
//            LJKLineModel *chartModel = kLineArray[i];
//            LJKLineBOLLModel *chartBollModel = (LJKLineBOLLModel *)chartModel.qsModel;
//            powSumPrice += pow(([chartModel.clp floatValue] - chartBollModel.boll_MA.floatValue), 2);
//        }
//    }
//    bollModel.boll_MD = [NSString jk_reviseString:sqrt(powSumPrice/bollNum_MD)];
//
//
//    LJKLineModel *upKLineModel = [kLineArray objectAtIndex:idx-1];
//    LJKLineBOLLModel *upBollModel = (LJKLineBOLLModel *)upKLineModel.qsModel;
//
//    bollModel.boll_MB = upBollModel.boll_MA;
//
//    bollModel.boll_UP = [NSString jk_reviseString:bollModel.boll_MB.doubleValue + bollNum_P*bollModel.boll_MD.doubleValue];
//    bollModel.boll_DN = [NSString jk_reviseString:bollModel.boll_MB.floatValue - bollNum_P*bollModel.boll_MD.floatValue];
}

/// 简单平滑移动平均线-MA
- (double)getBOLLMA:(NSMutableArray *)dataArray currentDay:(NSInteger)currentDay aveDay:(NSInteger)aveDay{
    double result = 0;
    if (currentDay < aveDay - 1) {
        for (NSInteger j = 0; j <= currentDay; j++) {
            LJKLineModel *detailModel = dataArray[j];
            result += [detailModel.clp doubleValue];
        }
        result = result / (currentDay + 1);
    } else {
        for (NSInteger j = currentDay - aveDay + 1; j <= currentDay; j++) {
            LJKLineModel *detailModel = dataArray[j];
            result += [detailModel.clp doubleValue];
        }
        result = result / aveDay;
    }
    return result;
}


@end
