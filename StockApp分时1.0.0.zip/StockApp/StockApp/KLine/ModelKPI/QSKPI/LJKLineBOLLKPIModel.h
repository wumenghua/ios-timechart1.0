//
//  LJKLineBOLLKPIModel.h
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/5/31.
//  Copyright © 2018年 伍孟华. All rights reserved.
//  BOLL指标 参数

#import "LJKLineKPIBaseModel.h"

@interface LJKLineBOLLKPIModel : LJKLineKPIBaseModel

@property(nonatomic ,assign) float bollMa;
@property(nonatomic ,assign) float bollMb;
@property(nonatomic ,assign) float bollP;

@property(nonatomic ,strong) NSString *bollUpHex;

@property(nonatomic ,strong) NSString *bollMbHex;

@property(nonatomic ,strong) NSString *bollDnHex;


@end
