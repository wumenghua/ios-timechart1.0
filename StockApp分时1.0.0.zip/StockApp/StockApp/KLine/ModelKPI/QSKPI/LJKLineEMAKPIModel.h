//
//  LJKLineEMAKPIModel.h
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/5/31.
//  Copyright © 2018年 伍孟华. All rights reserved.
//  EMA指标 参数

#import "LJKLineKPIBaseModel.h"

@interface LJKLineEMAKPIModel : LJKLineKPIBaseModel

@property(nonatomic ,assign) float ema5;
@property(nonatomic ,strong) NSString *ema5Hex;

@property(nonatomic ,assign) float ema10;
@property(nonatomic ,strong) NSString *ema10Hex;

@property(nonatomic ,assign) float ema20;
@property(nonatomic ,strong) NSString *ema20Hex;

@property(nonatomic ,assign) float ema40;
@property(nonatomic ,strong) NSString *ema40Hex;

@end
