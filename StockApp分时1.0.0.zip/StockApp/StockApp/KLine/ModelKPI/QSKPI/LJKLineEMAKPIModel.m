//
//  LJKLineEMAKPIModel.m
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/5/31.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "LJKLineEMAKPIModel.h"
#import "LJKLineEMAModel.h"
#import "NSString+Decimal.h"

@implementation LJKLineEMAKPIModel

-(void)calculateKLineKPIModel:(NSMutableArray *)kLineArray
{
    LJKLineModel *firstKlineModel = kLineArray.firstObject;
    if ([firstKlineModel.qsModel isKindOfClass:[LJKLineEMAModel class]]) {
        LJKLineModel *lastkLineModel = kLineArray.lastObject;
        if (lastkLineModel && ![lastkLineModel.qsModel isKindOfClass:[LJKLineEMAModel class]]) {
            lastkLineModel.qsModel = [[LJKLineEMAModel alloc] init];
        }
        //如果最后一条存在，那么就计算最后一条bar的数据
        [self calculateEMAModel:kLineArray model:lastkLineModel idx:kLineArray.count-1];
    }else{
        //最后一条为空，那么代表整条数据全部为空，重新计算
        for (int i = 0; i < kLineArray.count; i++) {
            LJKLineModel *klineModel = kLineArray[i];
            if (![klineModel.qsModel isKindOfClass:[LJKLineEMAModel class]]) {
                klineModel.qsModel = [[LJKLineEMAModel alloc] init];
            }
            LJKLineEMAModel *emaModel = (LJKLineEMAModel *)klineModel.qsModel;
            if (i == 0) {
                emaModel.ema5 = klineModel.clp;
                emaModel.ema10 = klineModel.clp;
                emaModel.ema20 = klineModel.clp;
                emaModel.ema40 = klineModel.clp;
            }else{
                [self calculateEMAModel:kLineArray model:klineModel idx:i];
            }
        }
    }
}

- (void)calculateEMAModel:(NSMutableArray *)kLineArray model:(LJKLineModel *)model idx:(NSUInteger)idx {
    
    LJKLineEMAModel *emaModel = (LJKLineEMAModel *)model.qsModel;
    float ema5 = self.ema5;
    float ema10 = self.ema10;
    float ema20 = self.ema20;
    float ema40 = self.ema40;
    
    LJKLineModel *upKlineModel = [kLineArray objectAtIndex:idx-1];
    LJKLineEMAModel *upEmaModel = (LJKLineEMAModel *)upKlineModel.qsModel;
    if ([upEmaModel isKindOfClass:[LJKLineEMAModel class]]) {
        float ema5Value = 2 * (model.clp.floatValue - upEmaModel.ema5.floatValue) / (ema5 + 1) + upEmaModel.ema5.floatValue;
        float ema10Value = 2 * (model.clp.floatValue - upEmaModel.ema10.floatValue) / (ema10 + 1) + upEmaModel.ema10.floatValue;
        float ema20Value = 2 * (model.clp.floatValue - upEmaModel.ema20.floatValue) / (ema20 + 1) + upEmaModel.ema20.floatValue;
        float ema40Value = 2 * (model.clp.floatValue - upEmaModel.ema40.floatValue) / (ema40 + 1) + upEmaModel.ema40.floatValue;
        
        emaModel.ema5 = [NSString jk_reviseString:ema5Value];
        emaModel.ema10 = [NSString jk_reviseString:ema10Value];
        emaModel.ema20 = [NSString jk_reviseString:ema20Value];
        emaModel.ema40 = [NSString jk_reviseString:ema40Value];
    }
}

@end
