//
//  LJKLineMAKPIModel.h
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/5/31.
//  Copyright © 2018年 伍孟华. All rights reserved.
//  MA指标 参数

#import "LJKLineKPIBaseModel.h"

@interface LJKLineMAKPIModel : LJKLineKPIBaseModel


@property(nonatomic ,assign) float ma5;
@property(nonatomic ,strong) NSString *ma5Hex;

@property(nonatomic ,assign) float ma10;
@property(nonatomic ,strong) NSString *ma10Hex;

@property(nonatomic ,assign) float ma20;
@property(nonatomic ,strong) NSString *ma20Hex;

@property(nonatomic ,assign) float ma40;
@property(nonatomic ,strong) NSString *ma40Hex;

@end
