//
//  LJKLineMAKPIModel.m
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/5/31.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "LJKLineMAKPIModel.h"
#import "LJKLineMAModel.h"

@implementation LJKLineMAKPIModel

-(void)calculateKLineKPIModel:(NSMutableArray *)kLineArray
{
    LJKLineModel *firstKlineModel = kLineArray.firstObject;
    if ([firstKlineModel.qsModel isKindOfClass:[LJKLineMAModel class]]) {
        LJKLineModel *lastkLineModel = kLineArray.lastObject;
        if (lastkLineModel && ![lastkLineModel.qsModel isKindOfClass:[LJKLineMAModel class]]) {
            lastkLineModel.qsModel = [[LJKLineMAModel alloc] init];
        }
        //如果最后一条存在，那么就计算最后一条bar的数据
        [self calculateMAModel:kLineArray model:lastkLineModel idx:kLineArray.count-1];
    }else{
        //最后一条不为空，那么代表整条数据全部为空，重新计算
        for (int i = 0; i < kLineArray.count; i++) {
            LJKLineModel *klineModel = kLineArray[i];
            if (![klineModel.qsModel isKindOfClass:[LJKLineMAModel class]]) {
                klineModel.qsModel = [[LJKLineMAModel alloc] init];
            }
            [self calculateMAModel:kLineArray model:klineModel idx:i];
        }
    }
}

- (void)calculateMAModel:(NSMutableArray *)kLineArray model:(LJKLineModel *)model idx:(NSUInteger)idx {
    
    LJKLineMAModel *maModel = (LJKLineMAModel *)model.qsModel;
    float MA5 = self.ma5;
    float MA10 = self.ma10;
    float MA20 = self.ma20;
    float MA40 = self.ma40;
    
    if (idx >= MA5) {
        float kline_MA5Total = 0.0f;
        //计算 5 日以收盘价平均值
        for (int i = (int)idx-MA5; i < idx; i++) {
            LJKLineModel *chartModel = [kLineArray objectAtIndex:i];
            kline_MA5Total += [chartModel.clp floatValue];
        }
        maModel.ma5 = [NSString jk_reviseString:kline_MA5Total / MA5];
    }
    if (idx >= MA10) {
        float kline_MA10Total = 0.0f;
        //计算 10 日以收盘价平均值
        for (int i = (int)idx-MA10; i < idx; i++) {
            LJKLineModel *chartModel = [kLineArray objectAtIndex:i];
            kline_MA10Total += [chartModel.clp floatValue];
        }
        maModel.ma10 = [NSString jk_reviseString:kline_MA10Total / MA10];
    }
    
    if (idx >= MA20) {
        float kline_MA20Total = 0.0f;
        //计算 20 日以收盘价平均值
        for (int i = (int)idx-MA20; i < idx; i++) {
            LJKLineModel *chartModel = [kLineArray objectAtIndex:i];
            kline_MA20Total += [chartModel.clp floatValue];
        }
        maModel.ma20 = [NSString jk_reviseString:kline_MA20Total / MA20];
    }
    
    if (idx >= MA40) {
        float kline_MA40Total = 0.0f;
        //计算 40 日以收盘价平均值
        for (int i = (int)idx - MA40; i < idx; i++) {
            LJKLineModel *chartModel = [kLineArray objectAtIndex:i];
            kline_MA40Total += [chartModel.clp floatValue];
        }
        maModel.ma40 = [NSString jk_reviseString:kline_MA40Total / MA40];
    }
}



@end
