//
//  LJKLineCandleKPIModel.m
//  KFY_FK_Dome
//
//  Created by 伍孟华 on 2018/5/31.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import "LJKLineCandleKPIModel.h"

@implementation LJKLineCandleKPIModel

-(void)calculateKLineKPIModel:(NSMutableArray *)kLineArray
{
    
}

@end
