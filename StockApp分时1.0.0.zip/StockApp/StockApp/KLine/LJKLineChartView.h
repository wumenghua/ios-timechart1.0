//
//  LJKLineChartView.h
//  YiFu
//
//  Created by 伍孟华 on 2018/8/16.
//  Copyright © 2018年 伍孟华. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIViewAdditions.h"
#import "LJKLineLayoutModel.h"
#import "LJKLinePCH.pch"
#import "LJDrawModel.h"
#import "NSString+JKSize.h"

#import "LJKLineModel.h"
#import "LJKLineCandleModel.h"
#import "LJKLineMAModel.h"
#import "LJKLineEMAModel.h"
#import "LJKLineBOLLModel.h"
#import "LJKLineMVModel.h"
#import "LJKLineMACDModel.h"
#import "LJKLineKDJModel.h"
#import "LJKLineRSIModel.h"

#import "LJKLineCandleKPIModel.h"
#import "LJKLineMAKPIModel.h"
#import "LJKLineEMAKPIModel.h"
#import "LJKLineBOLLKPIModel.h"
#import "LJKLineMVKPIModel.h"
#import "LJKLineMACDKPIModel.h"
#import "LJKLineKDJKPIModel.h"
#import "LJKLineRSIKPIModel.h"

//趋势指标
typedef NS_ENUM(NSInteger, LJ_ENUM_KLineQSType)
{
    LJ_KLine_QS_K_Type = 100000,
    LJ_KLine_QS_MA_Type,
    LJ_KLine_QS_EMA_Type,
    LJ_KLine_QS_BOLL_Type
};
//量仓指标
typedef NS_ENUM(NSInteger, LJ_ENUM_KLineLCType)
{
    LJ_KLine_LC_MV_Type = 200000
};
//摆动指标
typedef NS_ENUM(NSInteger, LJ_ENUM_KLineBDType)
{
    LJ_KLine_BD_MACD_Type = 300000,
    LJ_KLine_BD_KDJ_Type,
    LJ_KLine_BD_RSI_Type
};

@protocol LJKLineChartViewDelegate <NSObject>

//十字架移动
@optional
- (void)lj_kLineTicksMove:(LJKLineModel *)chartModel idx:(NSInteger)idx x:(CGFloat)x y:(CGFloat)y;

//结束移动 回调
@optional
- (void)lj_kLineTicksEnd;

//K线图右滑分页
@optional
- (void)lj_kLineRightMovePage;

//已经缩放最小了
@optional
- (void)lj_kLineZoomMin;
//暂无更多数据
@optional
- (void)lj_kLineNotMoreData;

//KPI高度修改回调
@optional
- (void)lj_kLineUpdateKPIHeight;

@end

@interface LJKLineChartView : UIView


//长按事件
@property (nonatomic ,retain) UILongPressGestureRecognizer *longGesture;
//单击事件
@property (nonatomic ,retain) UITapGestureRecognizer *tapGesture;
//平移事件
@property (nonatomic ,retain) UIPanGestureRecognizer *panGesture;
//缩放
@property (nonatomic ,retain) UIPinchGestureRecognizer *pinchGesture;

//趋势
@property (nonatomic,strong) LJKLineLayoutModel *qsLayout;
@property (nonatomic,strong) LJKLineKPIBaseModel *qsKPIModel;
//量仓
@property (nonatomic,strong) LJKLineLayoutModel *lcLayout;
@property (nonatomic,strong) LJKLineKPIBaseModel *lcKPIModel;
//摆动
@property (nonatomic,strong) LJKLineLayoutModel *bdLayout;
@property (nonatomic,strong) LJKLineKPIBaseModel *bdKPIModel;

//bar的宽度
@property (nonatomic,assign) float kLineWidth;
//K线之间的空隙
@property (nonatomic ,assign) float kLineInterval;

//bar之间的空隙
@property (nonatomic ,assign) float barInterval;
//趋势指标横线数量
@property (nonatomic ,assign) NSInteger kLineHorCount;
@property (nonatomic ,assign) NSInteger kLineVerCount;
//是否允许右滑分页,用户控制重复发起请求
@property (nonatomic,assign) BOOL isRightMovePage;
//下一页是否有数据
@property (nonatomic,assign) BOOL isNextPage;

//合约小数位
@property (nonatomic ,assign) NSInteger decimal;
//十字架当前选中的索引
@property (nonatomic,strong) LJKLineModel *selectPointModel;
@property (nonatomic ,assign) NSInteger selectIdx;
//右边箭头
@property (nonatomic ,strong) UIImageView *rightArrowImage;
//到计时数量
@property (nonatomic,assign) NSInteger intervalCount;
@property (nonatomic,strong) UILabel *intervalLabel;

//格式化 | 划线字体大小
@property (nonatomic ,strong) NSString *format;
@property (nonatomic ,strong) NSDictionary *attribute;
@property (nonatomic ,assign) NSInteger attfontSize;
//横竖屏切换时十字架控制
@property (nonatomic,assign) BOOL isLandscapeUpdate;
//合约ID
@property (nonatomic,strong) NSString *instrumentId;
//合约周期
@property (nonatomic,strong) NSString *instrumentPeriod;


//K线基础数据集合 - 时间所在的Index
@property (nonatomic,strong) NSMutableDictionary *indexChartDictionary;
//K线绘制数据集合 - 时间所在的Index
@property (nonatomic,strong) NSMutableDictionary *drawChartDictionary;

//K线基础数据列表
@property (nonatomic ,strong) NSMutableArray *kLineChartArray;
//绘制数据
@property (nonatomic ,strong) NSMutableArray *drawChartArray;

//CGContextRef Array
@property (nonatomic,strong) NSMutableArray *drawRectArray;
@property (nonatomic,strong) NSMutableArray *kLineLayoutArray;
@property (nonatomic,strong) NSMutableArray *kpiLayoutArray;


//初始化
- (void)initialize;

- (void)addKLineChartArray:(NSMutableArray *)chartArray;
//加载图形
- (void)reloadView:(NSMutableArray *)tempDrawChartArray;
//更新视图绘制
- (void)updateDraw;
//主动清空数据
- (void)releaseView;
//隐藏十字架
- (void)hideTicks;

//delegate
@property (weak ,nonatomic) id<LJKLineChartViewDelegate> delegate;

/**
 根据索引获取model，并移动十字架
 */
-(LJKLineModel *)getkLineIndexMoveTick:(NSInteger)index;



@end
